'use client'

import { useEffect, useState } from 'react'

export type Platform = 'mac' | 'other'

/**
 * Платформа пользователя для подписей горячих клавиш (⌘ или Ctrl).
 * На сервере и при первой отрисовке — 'other': определение в эффекте исключает
 * расхождение разметки при гидратации.
 */
export function usePlatform(): Platform {
  const [platform, setPlatform] = useState<Platform>('other')

  useEffect(() => {
    if (/Mac|iPhone|iPad|iPod/i.test(navigator.userAgent)) setPlatform('mac')
  }, [])

  return platform
}

export function modifierLabel(platform: Platform): string {
  return platform === 'mac' ? '⌘' : 'Ctrl'
}
