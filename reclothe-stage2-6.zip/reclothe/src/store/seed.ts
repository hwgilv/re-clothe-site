import { MASTER_IDS, STOCK_ITEMS, getBaseService } from '@/lib/domain/catalog'
import { buildOrderView, buildPayoutDraft } from '@/lib/domain/derive'
import { addDaysToDateString, toDateString } from '@/lib/date'
import { calcPricing, emptyOptions } from '@/lib/domain/pricing'
import { reducer, type Action } from '@/store/reducer'
import type {
  Adjustment,
  AppState,
  Client,
  ComplexityId,
  Expense,
  Lead,
  MaterialId,
  Master,
  MessengerId,
  Order,
  OrderOptions,
  Payment,
  StockMovement,
} from '@/lib/domain/types'

/**
 * Демо-данные. Генерируются ОТНОСИТЕЛЬНО текущей даты — в день защиты сроки, платежи
 * и графики выглядят свежо, а не «прошлым октябрём». Это именно данные (ввод),
 * а не показатели: цены, ЗП, остатки, статусы карт и графики по ним считает `deriveAll`.
 */

const MS_PER_DAY = 86_400_000

export const STATE_VERSION = 1 as const

export function createEmptyState(): AppState {
  return {
    version: STATE_VERSION,
    rev: 1,
    clients: [],
    leads: [],
    orders: [],
    masters: createMasters(),
    payouts: [],
    expenses: [],
    stockMovements: [],
    serviceOverrides: {},
    counters: { order: 0, donor: 0, act: 0 },
  }
}

function createMasters(): Master[] {
  return [
    {
      id: MASTER_IDS.timofey,
      name: 'Тимофей Аркадьевич',
      role: 'Верхняя одежда',
      capacity: 6,
      contractNo: 'ГПХ № 11/2026',
      contractDate: '2026-09-01',
      color: '#4f7cc0',
    },
    {
      id: MASTER_IDS.roman,
      name: 'Лозовой Роман',
      role: 'Корсеты и деним',
      capacity: 5,
      contractNo: 'ГПХ № 12/2026',
      contractDate: '2026-09-01',
      color: '#ff5500',
    },
    {
      id: MASTER_IDS.artem,
      name: 'Федоров Артем',
      role: 'Трикотаж',
      capacity: 7,
      contractNo: 'ГПХ № 13/2026',
      contractDate: '2026-09-15',
      color: '#2fb07f',
    },
  ]
}

/* -------------------------------------------------------------------- клиенты */

interface ClientSpec {
  id: string
  last: string
  first: string
  middle: string
  contact: MessengerId
  /** Дней назад зарегистрирован. */
  ago: number
  source: 'site' | 'admin'
}

const CLIENT_SPECS: readonly ClientSpec[] = [
  { id: 'c-01', last: 'Иванова', first: 'Мария', middle: 'Петровна', contact: 'telegram', ago: 80, source: 'admin' },
  { id: 'c-02', last: 'Смирнов', first: 'Алексей', middle: 'Игоревич', contact: 'whatsapp', ago: 76, source: 'site' },
  { id: 'c-03', last: 'Кузнецова', first: 'Анна', middle: 'Сергеевна', contact: 'vk', ago: 75, source: 'site' },
  { id: 'c-04', last: 'Морозов', first: 'Дмитрий', middle: 'Андреевич', contact: 'telegram', ago: 72, source: 'admin' },
  { id: 'c-05', last: 'Волкова', first: 'Екатерина', middle: 'Олеговна', contact: 'whatsapp', ago: 71, source: 'site' },
  { id: 'c-06', last: 'Соколов', first: 'Павел', middle: 'Викторович', contact: 'call', ago: 65, source: 'admin' },
  { id: 'c-07', last: 'Лебедева', first: 'Ольга', middle: 'Николаевна', contact: 'vk', ago: 66, source: 'site' },
  { id: 'c-08', last: 'Новикова', first: 'Елена', middle: 'Александровна', contact: 'telegram', ago: 0, source: 'site' },
  { id: 'c-09', last: 'Павлов', first: 'Игорь', middle: 'Сергеевич', contact: 'whatsapp', ago: 0, source: 'site' },
  { id: 'c-10', last: 'Орлова', first: 'Дарья', middle: 'Максимовна', contact: 'telegram', ago: 1, source: 'site' },
]

/** Номера заведомо вымышленные (000), чтобы демо не набирало чужих людей. */
function phoneFor(index: number): string {
  return `+7 913 000-00-${String(index + 1).padStart(2, '0')}`
}

const EMAILS: Record<string, string> = {
  'c-01': 'maria.ivanova@example.com',
  'c-02': 'a.smirnov@example.com',
  'c-03': 'anna.kuznetsova@example.com',
  'c-04': 'd.morozov@example.com',
  'c-05': 'volkova.kate@example.com',
  'c-06': 'p.sokolov@example.com',
  'c-07': 'olga.lebedeva@example.com',
  'c-08': 'elena.novikova@example.com',
  'c-09': 'igor.pavlov@example.com',
  'c-10': 'darya.orlova@example.com',
}

/* --------------------------------------------------------------------- заказы */

interface OrderSpec {
  client: string
  service: string
  complexity?: ComplexityId
  material?: MaterialId
  options?: Partial<OrderOptions>
  master?: string
  /** Дней назад создан. */
  ago: number
  /** Срок: смещение от СЕГОДНЯ в днях (отрицательное — уже прошёл). */
  due: number
  stage: number
  progress?: number
  /** Платежи: [дней назад, доля от цены]. */
  pay: readonly (readonly [number, number])[]
  /** Дней назад закрыт (если дошёл до «Готово»). */
  doneAgo?: number
  adj?: readonly string[]
  cancelled?: boolean
  /** Ключ выплаты: заказы с одним ключом входят в акты одной даты (по одному акту на мастера). */
  payout?: string
  comment?: string
}

const ORDER_SPECS: readonly OrderSpec[] = [
  { client: 'c-05', service: '2.1', material: 'knit', master: MASTER_IDS.artem, ago: 70, due: -56, stage: 8, doneAgo: 58, pay: [[70, 0.5], [58, 0.5]], adj: ['b-otk'], payout: 'A', comment: 'Хотела акцент на рукавах из рубашки.' },
  { client: 'c-07', service: '5.3', master: MASTER_IDS.roman, ago: 66, due: -58, stage: 8, doneAgo: 60, pay: [[66, 1]], adj: ['b-review'] },
  { client: 'c-01', service: '1.2', complexity: 'medium', options: { ops: { insulation: 1, eyelet: 10, 'pocket-flap': 4, 'zip-double': 1 }, urgency: '48h' }, master: MASTER_IDS.timofey, ago: 62, due: -40, stage: 8, doneAgo: 45, pay: [[62, 0.5], [45, 0.5]], adj: ['b-early-1', 'b-otk'], payout: 'B', comment: 'Пэчворк из пяти пар джинсов, асимметричный подол.' },
  { client: 'c-03', service: '1.10', complexity: 'medium', options: { ops: { 'zip-regular': 2, 'pocket-zip': 2, snap: 8 } }, master: MASTER_IDS.timofey, ago: 58, due: -38, stage: 8, doneAgo: 42, pay: [[58, 0.5], [42, 0.5]], adj: ['b-review'], payout: 'B' },
  { client: 'c-04', service: '1.8', complexity: 'high', options: { ops: { insulation: 1, 'zip-double': 1, 'pocket-inner': 2 }, lining: true }, master: MASTER_IDS.timofey, ago: 55, due: -30, stage: 8, doneAgo: 30, pay: [[55, 0.5], [30, 0.5]], adj: ['b-otk', 'b-early-2'] },
  { client: 'c-04', service: '1.4', complexity: 'high', options: { ops: { rivet: 40, 'zip-regular': 3, carabiner: 2 }, art: { distress: 1, holes: 3 } }, master: MASTER_IDS.timofey, ago: 48, due: -22, stage: 8, doneAgo: 20, pay: [[48, 0.5], [20, 0.5]], adj: ['p-late-1'] },
  { client: 'c-03', service: '3.8', complexity: 'high', options: { corset: true, lining: true, ops: { eyelet: 14, lacing: 1 }, art: { 'emb-complex': 1 } }, master: MASTER_IDS.roman, ago: 44, due: -26, stage: 8, doneAgo: 25, pay: [[44, 0.5], [25, 0.5]], adj: ['p-otk-2'] },
  { client: 'c-02', service: '4.1', complexity: 'medium', options: { ops: { 'pocket-patch': 4, 'zip-regular': 1 } }, master: MASTER_IDS.roman, ago: 40, due: -24, stage: 8, doneAgo: 22, pay: [[40, 1]], adj: ['b-fitting'] },
  { client: 'c-06', service: '3.3', master: MASTER_IDS.roman, ago: 38, due: -18, stage: 8, doneAgo: 15, pay: [[38, 0.5], [15, 0.5]] },
  { client: 'c-01', service: '2.5', master: MASTER_IDS.artem, ago: 35, due: -17, stage: 8, doneAgo: 14, pay: [[35, 0.5], [14, 0.5]], adj: ['b-fitting', 'b-repeat'] },
  { client: 'c-04', service: '1.7', complexity: 'medium', options: { lining: true, ops: { 'pocket-welt': 2, snap: 6 } }, master: MASTER_IDS.timofey, ago: 33, due: -12, stage: 8, doneAgo: 10, pay: [[33, 0.5], [10, 0.5]] },
  { client: 'c-03', service: '1.9', complexity: 'medium', options: { ops: { 'zip-double': 1, 'pocket-patch': 4, fleece: 1 } }, master: MASTER_IDS.timofey, ago: 30, due: -10, stage: 8, doneAgo: 8, pay: [[30, 0.5], [8, 0.5]], adj: ['b-otk'] },
  { client: 'c-05', service: '6.2', master: MASTER_IDS.artem, ago: 28, due: -12, stage: 8, doneAgo: 18, pay: [[28, 1]] },
  { client: 'c-04', service: '1.5', complexity: 'medium', options: { ops: { insulation: 1, 'zip-regular': 1 } }, master: MASTER_IDS.timofey, ago: 26, due: -4, stage: 8, doneAgo: 4, pay: [[26, 0.5]], comment: 'Остаток клиент оплатит при выдаче.' },

  // История: старые закрытые заказы, чтобы у карт лояльности и графиков была глубина.
  { client: 'c-04', service: '1.10', complexity: 'medium', options: { ops: { 'zip-regular': 2, snap: 6, 'pocket-inner': 2 }, lining: true }, master: MASTER_IDS.timofey, ago: 168, due: -148, stage: 8, doneAgo: 150, pay: [[168, 0.5], [150, 0.5]], adj: ['b-otk'], payout: 'P1' },
  { client: 'c-04', service: '1.2', complexity: 'medium', options: { ops: { insulation: 1, 'pocket-flap': 4, eyelet: 8 } }, master: MASTER_IDS.timofey, ago: 150, due: -132, stage: 8, doneAgo: 133, pay: [[150, 0.5], [133, 0.5]], payout: 'P1' },
  { client: 'c-03', service: '3.9', complexity: 'medium', options: { ops: { 'zip-concealed': 1, 'pocket-patch': 2 } }, master: MASTER_IDS.roman, ago: 140, due: -125, stage: 8, doneAgo: 132, pay: [[140, 0.5], [132, 0.5]], payout: 'P1' },
  { client: 'c-04', service: '1.8', complexity: 'medium', options: { ops: { insulation: 1, 'zip-double': 1 }, lining: true }, master: MASTER_IDS.timofey, ago: 135, due: -112, stage: 8, doneAgo: 118, pay: [[135, 0.5], [118, 0.5]], adj: ['b-review'], payout: 'P2' },
  { client: 'c-04', service: '1.2', complexity: 'medium', options: { ops: { insulation: 1, 'pocket-flap': 4, 'zip-double': 1 } }, master: MASTER_IDS.timofey, ago: 125, due: -108, stage: 8, doneAgo: 108, pay: [[125, 0.5], [108, 0.5]], payout: 'P3' },
  { client: 'c-04', service: '1.4', complexity: 'medium', options: { ops: { rivet: 30, 'zip-regular': 2 }, art: { distress: 1 } }, master: MASTER_IDS.timofey, ago: 128, due: -106, stage: 8, doneAgo: 105, pay: [[128, 0.5], [105, 0.5]], payout: 'P3' },
  { client: 'c-04', service: '3.8', complexity: 'medium', options: { corset: true, ops: { eyelet: 12 } }, master: MASTER_IDS.roman, ago: 120, due: -104, stage: 8, doneAgo: 102, pay: [[120, 0.5], [102, 0.5]], adj: ['b-otk'], payout: 'P3' },
  { client: 'c-03', service: '1.8', complexity: 'medium', options: { ops: { insulation: 1, 'zip-double': 1 } }, master: MASTER_IDS.timofey, ago: 118, due: -100, stage: 8, doneAgo: 101, pay: [[118, 0.5], [101, 0.5]], payout: 'P3' },
  { client: 'c-01', service: '1.9', complexity: 'medium', options: { ops: { 'zip-double': 1, 'pocket-patch': 4 } }, master: MASTER_IDS.timofey, ago: 110, due: -92, stage: 8, doneAgo: 90, pay: [[110, 0.5], [90, 0.5]], payout: 'P4' },
  { client: 'c-04', service: '5.1', complexity: 'medium', options: { ops: { 'zip-regular': 2 }, lining: true }, master: MASTER_IDS.roman, ago: 100, due: -84, stage: 8, doneAgo: 82, pay: [[100, 0.5], [82, 0.5]], payout: 'P4' },
  { client: 'c-03', service: '1.7', complexity: 'medium', options: { lining: true, ops: { snap: 6 } }, master: MASTER_IDS.timofey, ago: 96, due: -80, stage: 8, doneAgo: 80, pay: [[96, 0.5], [80, 0.5]], payout: 'P4' },
  { client: 'c-04', service: '1.5', complexity: 'medium', options: { ops: { insulation: 1 } }, master: MASTER_IDS.timofey, ago: 90, due: -76, stage: 8, doneAgo: 75, pay: [[90, 0.5], [75, 0.5]], payout: 'P4' },
  { client: 'c-02', service: '2.5', master: MASTER_IDS.artem, ago: 85, due: -72, stage: 8, doneAgo: 74, pay: [[85, 0.5], [74, 0.5]], payout: 'P4' },
  { client: 'c-04', service: '1.3', complexity: 'medium', options: { ops: { 'zip-regular': 1, snap: 6 } }, master: MASTER_IDS.timofey, ago: 80, due: -68, stage: 8, doneAgo: 73, pay: [[80, 0.5], [73, 0.5]], payout: 'P4' },

  { client: 'c-01', service: '3.2', complexity: 'medium', options: { lining: true, ops: { 'pocket-patch': 2 } }, master: MASTER_IDS.roman, ago: 18, due: 5, stage: 5, progress: 40, pay: [[18, 0.5]] },
  { client: 'c-02', service: '1.6', master: MASTER_IDS.timofey, ago: 12, due: 9, stage: 4, progress: 50, pay: [[12, 0.5]], comment: 'Нужны накладные карманы с клапанами.' },
  { client: 'c-03', service: '1.1', options: { ops: { 'pocket-flap': 2, bias: 3 } }, master: MASTER_IDS.timofey, ago: 9, due: 14, stage: 3, progress: 30, pay: [[9, 0.3]] },
  { client: 'c-06', service: '3.8', complexity: 'high', options: { corset: true, ops: { eyelet: 12 } }, master: MASTER_IDS.roman, ago: 21, due: 2, stage: 6, progress: 70, pay: [[21, 0.5]] },
  { client: 'c-07', service: '2.2', master: MASTER_IDS.artem, ago: 4, due: 12, stage: 2, progress: 20, pay: [] },
  { client: 'c-04', service: '5.1', complexity: 'medium', options: { ops: { 'zip-regular': 2, snap: 4 }, lining: true }, master: MASTER_IDS.roman, ago: 24, due: -3, stage: 5, progress: 60, pay: [[24, 0.5]], comment: 'Задержка: ждём ремни для лямок.' },
  { client: 'c-05', service: '7.5', master: MASTER_IDS.artem, ago: 13, due: 1, stage: 7, progress: 50, pay: [[13, 0.5]] },
  { client: 'c-01', service: '4.2', master: MASTER_IDS.roman, ago: 1, due: 20, stage: 1, progress: 0, pay: [] },
  { client: 'c-02', service: '1.3', complexity: 'medium', options: { ops: { 'zip-regular': 1, snap: 6 } }, master: MASTER_IDS.timofey, ago: 6, due: 16, stage: 3, progress: 60, pay: [[6, 0.5]] },
  { client: 'c-06', service: '6.4', master: MASTER_IDS.artem, ago: 30, due: -20, stage: 1, progress: 0, pay: [], cancelled: true, comment: 'Клиент передумал.' },
]

const EXPENSE_SPECS: readonly { ago: number; title: string; category: Expense['category']; amount: number }[] = [
  { ago: 166, title: 'Аренда мастерской (апрель)', category: 'rent', amount: 6000 },
  { ago: 136, title: 'Аренда мастерской (май)', category: 'rent', amount: 6000 },
  { ago: 106, title: 'Аренда мастерской (июнь)', category: 'rent', amount: 6000 },
  { ago: 150, title: 'Реклама ВКонтакте', category: 'marketing', amount: 2500 },
  { ago: 110, title: 'Реклама ВКонтакте', category: 'marketing', amount: 3000 },
  { ago: 130, title: 'Электричество и интернет', category: 'utilities', amount: 1400 },
  { ago: 100, title: 'Электричество и интернет', category: 'utilities', amount: 1450 },
  { ago: 70, title: 'Электричество и интернет', category: 'utilities', amount: 1500 },
  { ago: 76, title: 'Аренда мастерской (сентябрь)', category: 'rent', amount: 6000 },
  { ago: 46, title: 'Аренда мастерской (октябрь)', category: 'rent', amount: 6000 },
  { ago: 16, title: 'Аренда мастерской (ноябрь)', category: 'rent', amount: 6000 },
  { ago: 60, title: 'Реклама ВКонтакте', category: 'marketing', amount: 3000 },
  { ago: 26, title: 'Реклама ВКонтакте + блогер', category: 'marketing', amount: 3500 },
  { ago: 40, title: 'Электричество и интернет', category: 'utilities', amount: 1500 },
  { ago: 8, title: 'Электричество и интернет', category: 'utilities', amount: 1600 },
  { ago: 55, title: 'Иглы, лапки, масло для машин', category: 'equipment', amount: 2500 },
]

/** Закупки: сколько и когда. Часть позиций к «сегодня» остаётся впритык — для демо предупреждений. */
const STOCK_PURCHASES: readonly { ago: number; note: string; items: Record<string, number> }[] = [
  {
    ago: 175,
    note: 'Начальная закупка',
    items: {
      synthetic: 12, fleece: 8, lining: 12, bias: 25, 'zip-regular': 20, 'zip-concealed': 8,
      'zip-double': 4, eyelet: 120, snap: 60, rivet: 100, pulley: 20, boning: 4, patch: 12,
      carabiner: 10, cord: 10, beads: 3, paint: 400, bleach: 500, 'emb-thread': 14, thread: 45,
    },
  },
  {
    ago: 95,
    note: 'Пополнение запасов',
    items: {
      synthetic: 8, lining: 6, 'zip-regular': 10, 'zip-double': 3, eyelet: 60, snap: 30, rivet: 40,
      boning: 2, thread: 25, bias: 10,
    },
  },
  {
    ago: 40,
    note: 'Пополнение запасов',
    items: { synthetic: 8, fleece: 4, 'zip-regular': 10, eyelet: 40, rivet: 40, thread: 16, 'emb-thread': 6 },
  },
]

function isoDaysAgo(now: Date, days: number): string {
  return new Date(now.getTime() - days * MS_PER_DAY).toISOString()
}

/** Дни выплат: ключ из спецификации заказа → сколько дней назад был подписан акт. */
const PAYOUT_DAYS: Record<string, number> = { P1: 128, P2: 112, P3: 95, P4: 66, A: 50, B: 38 }

/** Собирает демо-состояние относительно момента `now`. */
export function createSeed(now: Date = new Date()): AppState {
  const today = toDateString(now)
  const masters = createMasters()

  const clients: Client[] = CLIENT_SPECS.map((spec, index) => ({
    id: spec.id,
    lastName: spec.last,
    firstName: spec.first,
    middleName: spec.middle,
    phone: phoneFor(index),
    email: EMAILS[spec.id] ?? '',
    contact: spec.contact,
    createdAt: isoDaysAgo(now, spec.ago),
    source: spec.source,
    tierOverride: null,
  }))

  const leads: Lead[] = [
    { id: 'l-08', clientId: 'c-08', createdAt: new Date(now.getTime() - 35 * 60_000).toISOString(), status: 'new', contactedAt: null },
    { id: 'l-09', clientId: 'c-09', createdAt: new Date(now.getTime() - 3 * 3_600_000).toISOString(), status: 'new', contactedAt: null },
    { id: 'l-10', clientId: 'c-10', createdAt: isoDaysAgo(now, 1), status: 'contacted', contactedAt: isoDaysAgo(now, 0.8) },
  ]

  let paymentSeq = 0
  let adjustmentSeq = 0
  let donorSeq = 0
  // Номера заказов идут по времени создания: сначала самые старые.
  const chronological = [...ORDER_SPECS].sort((a, b) => b.ago - a.ago)
  const payoutTags: { orderId: string; key: string }[] = []

  const orders: Order[] = chronological.map((spec, index) => {
    const service = getBaseService(spec.service)
    if (!service) throw new RangeError(`Seed: нет услуги ${spec.service}`)
    const complexityId = spec.complexity ?? service.defaultComplexity
    const materialId = spec.material ?? service.donor.materialId
    const options: OrderOptions = { ...emptyOptions(), ...spec.options }
    const price = calcPricing({ service, complexityId, materialId, options }).clientTotal

    const payments: Payment[] = spec.pay.map(([ago, fraction], paymentIndex) => ({
      id: `pay-seed-${(paymentSeq += 1)}`,
      amount: Math.round(price * fraction),
      kind: paymentIndex === 0 && fraction < 1 ? 'advance' : 'payment',
      at: isoDaysAgo(now, ago),
      note: '',
    }))

    const adjustments: Adjustment[] = (spec.adj ?? []).map((code) => ({
      id: `adj-seed-${(adjustmentSeq += 1)}`,
      kind: code.startsWith('b-') ? 'bonus' : 'penalty',
      code,
      qty: 1,
      customAmount: null,
      at: isoDaysAgo(now, spec.doneAgo ?? 0),
    }))

    const deadline = addDaysToDateString(today, spec.due)
    const sequence = index + 1
    const id = `o-${String(sequence).padStart(2, '0')}`
    if (spec.payout) payoutTags.push({ orderId: id, key: spec.payout })

    return {
      id,
      number: `RC-${today.slice(0, 4)}-${String(sequence).padStart(4, '0')}`,
      clientId: spec.client,
      serviceId: spec.service,
      tariff: { masterRate: service.masterRate, clientPrice: service.clientPrice },
      complexityId,
      materialId,
      options,
      donors: [
        {
          id: `d-${(donorSeq += 1)}`,
          code: `DN-${String(donorSeq).padStart(4, '0')}`,
          title: service.donor.title,
          materialId: service.donor.materialId,
          weightKg: service.donor.weightKg,
          note: '',
        },
      ],
      masterId: spec.master ?? service.defaultMasterId,
      createdAt: isoDaysAgo(now, spec.ago),
      deadline,
      requestedDeadline: deadline,
      apsShiftDays: 0,
      stage: spec.stage,
      stageProgress: spec.stage === 8 ? 100 : (spec.progress ?? 0),
      state: spec.cancelled ? 'cancelled' : 'active',
      completedAt: spec.doneAgo !== undefined ? isoDaysAgo(now, spec.doneAgo) : null,
      payments,
      adjustments,
      comment: spec.comment ?? '',
      payoutId: null,
    }
  })

  const expenses: Expense[] = EXPENSE_SPECS.map((spec, index) => ({
    id: `e-seed-${index + 1}`,
    at: isoDaysAgo(now, spec.ago),
    title: spec.title,
    category: spec.category,
    amount: spec.amount,
  }))

  let movementSeq = 0
  const stockMovements: StockMovement[] = STOCK_PURCHASES.flatMap((purchase) =>
    STOCK_ITEMS.flatMap((item) => {
      const qty = purchase.items[item.id]
      if (!qty) return []
      return [
        {
          id: `s-seed-${(movementSeq += 1)}`,
          itemId: item.id,
          qty,
          cost: Math.round(qty * item.unitCost),
          at: isoDaysAgo(now, purchase.ago),
          note: purchase.note,
        },
      ]
    }),
  )

  let state: AppState = {
    version: STATE_VERSION,
    rev: 1,
    clients,
    leads,
    orders,
    masters,
    payouts: [],
    expenses,
    stockMovements,
    serviceOverrides: {},
    counters: { order: orders.length, donor: donorSeq, act: 0 },
  }

  // Выплаты проводим через настоящий редьюсер — акты получаются такими же, как в бою.
  // Идём от старых к новым, чтобы номера актов росли вместе с датой.
  const keys = Object.keys(PAYOUT_DAYS).sort((a, b) => (PAYOUT_DAYS[b] ?? 0) - (PAYOUT_DAYS[a] ?? 0))
  for (const key of keys) {
    const ago = PAYOUT_DAYS[key] ?? 0
    const ids = new Set(payoutTags.filter((tag) => tag.key === key).map((tag) => tag.orderId))
    for (const master of masters) {
      const views = state.orders
        .filter((order) => ids.has(order.id) && order.masterId === master.id)
        .map((order) => buildOrderView(state, order, today))
      if (views.length === 0) continue
      const draft = buildPayoutDraft(master.id, views)
      const action: Action = {
        type: 'PAY_MASTER',
        payoutId: `payout-seed-${key}-${master.id}`,
        masterId: master.id,
        lines: draft.lines,
        at: isoDaysAgo(now, ago),
      }
      state = reducer(state, action)
    }
  }

  return { ...state, rev: 1 }
}
