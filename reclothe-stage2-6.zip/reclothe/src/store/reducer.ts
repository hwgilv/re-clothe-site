import { FINAL_STAGE } from '@/lib/domain/catalog'
import { sumPayoutLines } from '@/lib/domain/derive'
import { formatDonorCode, formatOrderNumber, snapshotTariff } from '@/lib/domain/orders'
import { toggleAdjustment } from '@/lib/domain/payroll'
import { clampPercent, clampStage } from '@/lib/domain/stages'
import type {
  Adjustment,
  AppState,
  Client,
  Expense,
  Lead,
  LeadStatus,
  LoyaltyTierId,
  Master,
  Order,
  OrderDonor,
  Payment,
  PayoutLine,
  ServiceOverride,
  StockMovement,
} from '@/lib/domain/types'

/** Заказ при создании: номер, складские коды и служебные поля присваивает редьюсер. */
export type NewOrder = Omit<
  Order,
  'number' | 'donors' | 'payoutId' | 'completedAt' | 'state' | 'stage' | 'stageProgress' | 'adjustments' | 'tariff'
> & {
  donors: Omit<OrderDonor, 'code'>[]
  payments: Payment[]
}

/** Поля заказа, доступные для редактирования. */
export type OrderPatch = Partial<
  Pick<
    Order,
    | 'serviceId'
    | 'complexityId'
    | 'materialId'
    | 'options'
    | 'masterId'
    | 'deadline'
    | 'requestedDeadline'
    | 'apsShiftDays'
    | 'comment'
  >
> & { donors?: (Omit<OrderDonor, 'code'> & { code?: string })[] }

export type Action =
  | { type: 'REPLACE_STATE'; state: AppState }
  | { type: 'REGISTER_CLIENT'; client: Client; lead: Lead | null }
  | { type: 'UPSERT_CLIENT'; client: Client }
  | { type: 'SET_TIER_OVERRIDE'; clientId: string; tier: LoyaltyTierId | null }
  | { type: 'SET_LEAD_STATUS'; leadId: string; status: LeadStatus; at: string }
  | { type: 'CREATE_ORDER'; order: NewOrder; leadId?: string }
  | { type: 'UPDATE_ORDER'; orderId: string; patch: OrderPatch }
  | { type: 'SET_ORDER_STATE'; orderId: string; state: 'active' | 'cancelled' }
  | { type: 'SET_STAGE'; orderId: string; stage: number; progress: number; at: string }
  | { type: 'SET_STAGE_PROGRESS'; orderId: string; progress: number }
  | { type: 'ADD_PAYMENT'; orderId: string; payment: Payment }
  | { type: 'REMOVE_PAYMENT'; orderId: string; paymentId: string }
  | { type: 'TOGGLE_ADJUSTMENT'; orderId: string; adjustment: Adjustment }
  | { type: 'REMOVE_ADJUSTMENT'; orderId: string; adjustmentId: string }
  | { type: 'PAY_MASTER'; payoutId: string; masterId: string; lines: PayoutLine[]; at: string }
  | { type: 'ADD_EXPENSE'; expense: Expense }
  | { type: 'REMOVE_EXPENSE'; expenseId: string }
  | { type: 'ADD_STOCK_MOVEMENT'; movement: StockMovement }
  | { type: 'UPDATE_MASTER'; masterId: string; patch: Partial<Pick<Master, 'capacity' | 'name' | 'role'>> }
  | { type: 'SET_SERVICE_OVERRIDE'; serviceId: string; override: ServiceOverride | null }

function mapOrder(state: AppState, orderId: string, update: (order: Order) => Order): AppState {
  let changed = false
  const orders = state.orders.map((order) => {
    if (order.id !== orderId) return order
    const next = update(order)
    if (next !== order) changed = true
    return next
  })
  return changed ? { ...state, orders } : state
}

function sanitizeWeight(value: number): number {
  if (!Number.isFinite(value) || value < 0) return 0
  return Math.round(value * 1000) / 1000
}

/** Присваивает складские коды вещам-донорам, у которых их ещё нет. */
function withDonorCodes(
  donors: readonly (Omit<OrderDonor, 'code'> & { code?: string })[],
  nextSequence: number,
): { donors: OrderDonor[]; nextSequence: number } {
  let sequence = nextSequence
  const result = donors.map((donor): OrderDonor => {
    const code = donor.code && donor.code.length > 0 ? donor.code : formatDonorCode(sequence++)
    return { ...donor, code, weightKg: sanitizeWeight(donor.weightKg) }
  })
  return { donors: result, nextSequence: sequence }
}

function tariffField(serviceId: string, state: AppState): Pick<Order, 'tariff'> | Record<string, never> {
  const tariff = snapshotTariff(serviceId, state.serviceOverrides)
  return tariff ? { tariff } : {}
}

export function reducer(state: AppState, action: Action): AppState {
  const next = reduce(state, action)
  if (next === state) return state
  // REPLACE_STATE приносит собственный rev (из другой вкладки или из сброса).
  return action.type === 'REPLACE_STATE' ? next : { ...next, rev: state.rev + 1 }
}

function reduce(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'REPLACE_STATE':
      return action.state

    case 'REGISTER_CLIENT': {
      const exists = state.clients.some((client) => client.id === action.client.id)
      const clients = exists
        ? state.clients.map((client) =>
            client.id === action.client.id ? { ...client, ...action.client } : client,
          )
        : [...state.clients, action.client]
      const leads = action.lead ? [...state.leads, action.lead] : state.leads
      return { ...state, clients, leads }
    }

    case 'UPSERT_CLIENT': {
      const exists = state.clients.some((client) => client.id === action.client.id)
      return {
        ...state,
        clients: exists
          ? state.clients.map((client) => (client.id === action.client.id ? action.client : client))
          : [...state.clients, action.client],
      }
    }

    case 'SET_TIER_OVERRIDE':
      return {
        ...state,
        clients: state.clients.map((client) =>
          client.id === action.clientId ? { ...client, tierOverride: action.tier } : client,
        ),
      }

    case 'SET_LEAD_STATUS':
      return {
        ...state,
        leads: state.leads.map((lead) =>
          lead.id === action.leadId
            ? {
                ...lead,
                status: action.status,
                contactedAt: action.status === 'contacted' ? action.at : lead.contactedAt,
              }
            : lead,
        ),
      }

    case 'CREATE_ORDER': {
      const sequence = state.counters.order + 1
      const { donors, nextSequence } = withDonorCodes(action.order.donors, state.counters.donor + 1)
      const order: Order = {
        ...action.order,
        number: formatOrderNumber(action.order.createdAt, sequence),
        donors,
        stage: 1,
        stageProgress: 0,
        state: 'active',
        completedAt: null,
        adjustments: [],
        payoutId: null,
        ...tariffField(action.order.serviceId, state),
      }
      const leads = action.leadId
        ? state.leads.map((lead) =>
            lead.id === action.leadId ? { ...lead, status: 'converted' as const } : lead,
          )
        : state.leads
      return {
        ...state,
        orders: [...state.orders, order],
        leads,
        counters: { ...state.counters, order: sequence, donor: nextSequence - 1 },
      }
    }

    case 'UPDATE_ORDER': {
      const order = state.orders.find((item) => item.id === action.orderId)
      if (!order) return state
      const { donors: patchDonors, ...rest } = action.patch
      let counters = state.counters
      let donors = order.donors
      if (patchDonors) {
        const coded = withDonorCodes(patchDonors, state.counters.donor + 1)
        donors = coded.donors
        counters = { ...counters, donor: coded.nextSequence - 1 }
      }
      // Смена услуги — новое соглашение с клиентом, тариф фиксируется заново.
      const reprice =
        rest.serviceId !== undefined && rest.serviceId !== order.serviceId
          ? tariffField(rest.serviceId, state)
          : {}
      return {
        ...mapOrder(state, action.orderId, (current) => ({ ...current, ...rest, ...reprice, donors })),
        counters,
      }
    }

    case 'SET_ORDER_STATE':
      return mapOrder(state, action.orderId, (order) =>
        order.state === action.state ? order : { ...order, state: action.state },
      )

    case 'SET_STAGE':
      return mapOrder(state, action.orderId, (order) => {
        if (order.state !== 'active') return order
        const stage = clampStage(action.stage)
        // Выплаченный заказ нельзя «откатить»: акт по нему уже подписан.
        if (order.payoutId !== null && stage < FINAL_STAGE) return order
        const completedAt =
          stage === FINAL_STAGE ? (order.completedAt ?? action.at) : null
        return {
          ...order,
          stage,
          stageProgress: stage === FINAL_STAGE ? 100 : clampPercent(action.progress),
          completedAt,
        }
      })

    case 'SET_STAGE_PROGRESS':
      return mapOrder(state, action.orderId, (order) =>
        order.state !== 'active' || order.stage >= FINAL_STAGE
          ? order
          : { ...order, stageProgress: clampPercent(action.progress) },
      )

    case 'ADD_PAYMENT': {
      const amount = Math.round(action.payment.amount)
      if (!Number.isFinite(amount) || amount <= 0) return state
      return mapOrder(state, action.orderId, (order) => ({
        ...order,
        payments: [...order.payments, { ...action.payment, amount }],
      }))
    }

    case 'REMOVE_PAYMENT':
      return mapOrder(state, action.orderId, (order) => ({
        ...order,
        payments: order.payments.filter((payment) => payment.id !== action.paymentId),
      }))

    case 'TOGGLE_ADJUSTMENT':
      return mapOrder(state, action.orderId, (order) =>
        order.payoutId !== null
          ? order
          : { ...order, adjustments: toggleAdjustment(order.adjustments, action.adjustment) },
      )

    case 'REMOVE_ADJUSTMENT':
      return mapOrder(state, action.orderId, (order) =>
        order.payoutId !== null
          ? order
          : {
              ...order,
              adjustments: order.adjustments.filter((item) => item.id !== action.adjustmentId),
            },
      )

    case 'PAY_MASTER': {
      // В выплату берём только закрытые и ещё не выплаченные заказы этого мастера.
      const eligible = new Set(
        state.orders
          .filter(
            (order) =>
              order.masterId === action.masterId &&
              order.state === 'active' &&
              order.completedAt !== null &&
              order.payoutId === null,
          )
          .map((order) => order.id),
      )
      const lines = action.lines.filter((line) => eligible.has(line.orderId))
      if (lines.length === 0) return state

      const actNo = state.counters.act + 1
      const totals = sumPayoutLines(lines)
      const paidIds = new Set(lines.map((line) => line.orderId))
      return {
        ...state,
        orders: state.orders.map((order) =>
          paidIds.has(order.id) ? { ...order, payoutId: action.payoutId } : order,
        ),
        payouts: [
          ...state.payouts,
          { id: action.payoutId, masterId: action.masterId, at: action.at, actNo, lines, ...totals },
        ],
        counters: { ...state.counters, act: actNo },
      }
    }

    case 'ADD_EXPENSE':
      return { ...state, expenses: [...state.expenses, action.expense] }

    case 'REMOVE_EXPENSE':
      return { ...state, expenses: state.expenses.filter((item) => item.id !== action.expenseId) }

    case 'ADD_STOCK_MOVEMENT':
      return { ...state, stockMovements: [...state.stockMovements, action.movement] }

    case 'UPDATE_MASTER':
      return {
        ...state,
        masters: state.masters.map((master) =>
          master.id === action.masterId
            ? {
                ...master,
                ...action.patch,
                capacity:
                  action.patch.capacity === undefined
                    ? master.capacity
                    : Math.max(1, Math.round(action.patch.capacity)),
              }
            : master,
        ),
      }

    case 'SET_SERVICE_OVERRIDE': {
      const overrides = { ...state.serviceOverrides }
      if (action.override === null) delete overrides[action.serviceId]
      else overrides[action.serviceId] = action.override
      return { ...state, serviceOverrides: overrides }
    }
  }
}
