import { STATE_VERSION, createEmptyState } from '@/store/seed'
import { snapshotTariff } from '@/lib/domain/orders'
import type { AppState } from '@/lib/domain/types'

export const STATE_STORAGE_KEY = 'reclothe.state.v1'

/**
 * Разбирает JSON из localStorage. Возвращает null, если данные повреждены или
 * принадлежат другой версии схемы, — тогда приложение начнёт с демо-данных.
 * Недостающие поля добавляются пустыми значениями (мягкая миграция).
 */
export function parseState(raw: string | null): AppState | null {
  if (!raw) return null
  try {
    const data: unknown = JSON.parse(raw)
    if (typeof data !== 'object' || data === null) return null
    const record = data as Partial<AppState>
    if (record.version !== STATE_VERSION) return null
    const base = createEmptyState()
    const list = <T,>(value: T[] | undefined, fallback: T[]): T[] =>
      Array.isArray(value) ? value : fallback
    return {
      version: STATE_VERSION,
      rev: typeof record.rev === 'number' ? record.rev : 1,
      clients: list(record.clients, base.clients),
      leads: list(record.leads, base.leads),
      orders: list(record.orders, base.orders).map((order) => ({
        ...order,
        // Старые записи без зафиксированного тарифа получают его по текущей сетке.
        ...(order.tariff
          ? {}
          : (() => {
              const tariff = snapshotTariff(order.serviceId, record.serviceOverrides ?? {})
              return tariff ? { tariff } : {}
            })()),
        donors: Array.isArray(order.donors) ? order.donors : [],
        payments: Array.isArray(order.payments) ? order.payments : [],
        adjustments: Array.isArray(order.adjustments) ? order.adjustments : [],
      })),
      masters: list(record.masters, base.masters),
      payouts: list(record.payouts, base.payouts),
      expenses: list(record.expenses, base.expenses),
      stockMovements: list(record.stockMovements, base.stockMovements),
      serviceOverrides:
        record.serviceOverrides && typeof record.serviceOverrides === 'object'
          ? record.serviceOverrides
          : {},
      counters: { ...base.counters, ...(record.counters ?? {}) },
    }
  } catch {
    return null
  }
}

export function serializeState(state: AppState): string {
  return JSON.stringify(state)
}

export function readStoredState(): AppState | null {
  try {
    return parseState(window.localStorage.getItem(STATE_STORAGE_KEY))
  } catch {
    return null
  }
}

/** Возвращает false, если записать не удалось (приватный режим, переполнение). */
export function writeStoredState(json: string): boolean {
  try {
    window.localStorage.setItem(STATE_STORAGE_KEY, json)
    return true
  } catch {
    return false
  }
}
