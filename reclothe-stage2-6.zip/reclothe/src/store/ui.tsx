'use client'

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'

/**
 * Состояние интерфейса (не данных): свёрнутый сайдбар, мобильное меню, палитра команд,
 * окно «+ Новый заказ». Контекст + useState — без внешних библиотек.
 */

const SIDEBAR_KEY = 'reclothe.ui.sidebar-collapsed'

/** Запрос на открытие окна заказа: новый (возможно, для клиента/лида) или редактирование. */
export interface OrderModalRequest {
  clientId?: string
  leadId?: string
  editOrderId?: string
}

interface UIContextValue {
  sidebarCollapsed: boolean
  toggleSidebar: () => void
  mobileNavOpen: boolean
  setMobileNavOpen: (open: boolean) => void
  paletteOpen: boolean
  setPaletteOpen: (open: boolean) => void
  togglePalette: () => void
  orderModal: OrderModalRequest | null
  openOrderModal: (request?: OrderModalRequest) => void
  closeOrderModal: () => void
}

const UIContext = createContext<UIContextValue | null>(null)

export function UIProvider({ children }: { children: React.ReactNode }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const [paletteOpen, setPaletteOpen] = useState(false)
  const [orderModal, setOrderModal] = useState<OrderModalRequest | null>(null)

  // Сохранённое значение подтягиваем после гидратации — иначе разметка сервера и клиента разойдётся.
  useEffect(() => {
    try {
      if (window.localStorage.getItem(SIDEBAR_KEY) === '1') setSidebarCollapsed(true)
    } catch {
      // без хранилища сайдбар просто начинает развёрнутым
    }
  }, [])

  const toggleSidebar = useCallback(() => {
    setSidebarCollapsed((current) => {
      const next = !current
      try {
        window.localStorage.setItem(SIDEBAR_KEY, next ? '1' : '0')
      } catch {
        // не критично
      }
      return next
    })
  }, [])

  const togglePalette = useCallback(() => setPaletteOpen((open) => !open), [])
  const openOrderModal = useCallback(
    (request: OrderModalRequest = {}) => setOrderModal(request),
    [],
  )
  const closeOrderModal = useCallback(() => setOrderModal(null), [])

  const value = useMemo<UIContextValue>(
    () => ({
      sidebarCollapsed,
      toggleSidebar,
      mobileNavOpen,
      setMobileNavOpen,
      paletteOpen,
      setPaletteOpen,
      togglePalette,
      orderModal,
      openOrderModal,
      closeOrderModal,
    }),
    [
      sidebarCollapsed,
      toggleSidebar,
      mobileNavOpen,
      paletteOpen,
      togglePalette,
      orderModal,
      openOrderModal,
      closeOrderModal,
    ],
  )

  return <UIContext.Provider value={value}>{children}</UIContext.Provider>
}

export function useUI(): UIContextValue {
  const value = useContext(UIContext)
  if (!value) throw new Error('useUI должен вызываться внутри <UIProvider>')
  return value
}
