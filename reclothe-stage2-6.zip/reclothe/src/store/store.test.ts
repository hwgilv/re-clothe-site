import { describe, expect, it } from 'vitest'

import { MASTER_IDS } from '@/lib/domain/catalog'
import { buildPayoutDraft, computePayrollSummary, deriveAll } from '@/lib/domain/derive'
import { emptyOptions } from '@/lib/domain/pricing'
import type { AppState } from '@/lib/domain/types'
import { reducer, type Action, type NewOrder } from '@/store/reducer'
import { createEmptyState, createSeed } from '@/store/seed'
import { parseState, serializeState } from '@/store/storage'

const NOW = new Date('2026-10-18T05:00:00Z')

function run(state: AppState, ...actions: Action[]): AppState {
  return actions.reduce(reducer, state)
}

function newOrder(overrides: Partial<NewOrder> = {}): NewOrder {
  return {
    id: 'o-new',
    clientId: 'c-08',
    serviceId: '1.2',
    complexityId: 'high',
    materialId: 'denim',
    options: { ...emptyOptions(), ops: { insulation: 1, eyelet: 10 } },
    donors: [{ id: 'd-new-1', title: 'Джинсы (5 пар)', materialId: 'denim', weightKg: 3.5, note: '' }],
    masterId: MASTER_IDS.artem,
    createdAt: NOW.toISOString(),
    deadline: '2026-11-10',
    requestedDeadline: '2026-11-10',
    apsShiftDays: 0,
    comment: 'тест',
    payments: [],
    ...overrides,
  }
}

describe('seed', () => {
  const state = createSeed(NOW)
  const derived = deriveAll(state, NOW.getTime())

  it('демо-данные согласованы и представляют все пять статусов карты', () => {
    const tiers = new Set(derived.clients.filter((c) => c.orders.length > 0).map((c) => c.tier.id))
    for (const id of ['bronze', 'silver', 'gold', 'platinum', 'diamond']) expect(tiers.has(id as never)).toBe(true)
  })

  it('номера заказов идут по порядку создания, без дублей', () => {
    const numbers = state.orders.map((order) => order.number)
    expect(new Set(numbers).size).toBe(numbers.length)
    const sorted = [...state.orders].sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1))
    expect(sorted.map((order) => order.number)).toEqual([...numbers].sort())
  })

  it('есть новые лиды, просрочка, перегруженный мастер и низкий остаток', () => {
    expect(derived.newLeads.length).toBe(2)
    expect(derived.orders.some((view) => view.status === 'overdue')).toBe(true)
    expect(derived.masters.some((master) => master.load >= 80)).toBe(true)
    expect(derived.stock.some((item) => item.balance.status !== 'ok')).toBe(true)
  })

  it('выплаченные заказы не попадают в баланс мастера', () => {
    for (const master of derived.masters) {
      const manual = master.unpaid.reduce((total, view) => total + view.payroll.total, 0)
      expect(master.balance).toBe(manual)
      for (const view of master.unpaid) expect(view.order.payoutId).toBeNull()
    }
    expect(state.payouts.length).toBeGreaterThan(0)
  })

  it('акты нумеруются по порядку', () => {
    const numbers = state.payouts.map((payout) => payout.actNo)
    expect(numbers).toEqual([...numbers].sort((a, b) => a - b))
    expect(state.counters.act).toBe(Math.max(...numbers))
  })

  it('сохранение и загрузка состояния без потерь', () => {
    expect(parseState(serializeState(state))).toEqual(state)
  })
})

describe('создание заказа', () => {
  const base = createSeed(NOW)
  const before = deriveAll(base, NOW.getTime())

  it('присваивает номер, коды доноров и этап 1', () => {
    const after = run(base, { type: 'CREATE_ORDER', order: newOrder() })
    const created = after.orders.find((order) => order.id === 'o-new')
    expect(created?.number).toBe(`RC-2026-${String(base.counters.order + 1).padStart(4, '0')}`)
    expect(created?.donors[0]?.code).toBe(`DN-${String(base.counters.donor + 1).padStart(4, '0')}`)
    expect(created?.stage).toBe(1)
    expect(after.counters.order).toBe(base.counters.order + 1)
  })

  it('вещь-донор сразу попадает на склад доноров, вес — в эко-счётчик клиента', () => {
    const after = run(base, { type: 'CREATE_ORDER', order: newOrder() })
    const derived = deriveAll(after, NOW.getTime())
    const view = derived.orderById.get('o-new')
    expect(view?.weightKg).toBe(3.5)
    expect(derived.clientById.get('c-08')?.eco.waterSavedLiters).toBe(9450)
    expect(derived.eco.textileSavedKg).toBeCloseTo(before.eco.textileSavedKg + 3.5, 5)
  })

  it('складские остатки уменьшаются на расход заказа', () => {
    const after = run(base, { type: 'CREATE_ORDER', order: newOrder() })
    const derived = deriveAll(after, NOW.getTime())
    const was = before.stockById.get('synthetic')?.balance.balance ?? 0
    const now = derived.stockById.get('synthetic')?.balance.balance ?? 0
    expect(Math.round((was - now) * 100) / 100).toBe(2)
    const eyelets = (before.stockById.get('eyelet')?.balance.balance ?? 0) - (derived.stockById.get('eyelet')?.balance.balance ?? 0)
    expect(eyelets).toBe(10)
  })

  it('отмена заказа возвращает материалы и убирает оплату из выручки', () => {
    const paid = newOrder({
      payments: [{ id: 'p1', amount: 3000, kind: 'advance', at: NOW.toISOString(), note: '' }],
    })
    const created = run(base, { type: 'CREATE_ORDER', order: paid })
    const withOrder = deriveAll(created, NOW.getTime())
    const cancelled = deriveAll(run(created, { type: 'SET_ORDER_STATE', orderId: 'o-new', state: 'cancelled' }), NOW.getTime())
    expect(withOrder.finance.current.revenue - cancelled.finance.current.revenue).toBe(3000)
    expect(cancelled.stockById.get('synthetic')?.balance.balance).toBe(before.stockById.get('synthetic')?.balance.balance)
  })

  it('заказ из лида переводит лид в «конвертирован»', () => {
    const after = run(base, { type: 'CREATE_ORDER', order: newOrder(), leadId: 'l-08' })
    expect(after.leads.find((lead) => lead.id === 'l-08')?.status).toBe('converted')
  })
})

describe('платежи и карта клиента', () => {
  const base = createSeed(NOW)

  it('аванс и доплата пересчитывают остаток, процент оплаты и статус карты', () => {
    let state = run(base, { type: 'CREATE_ORDER', order: newOrder() })
    let derived = deriveAll(state, NOW.getTime())
    const price = derived.orderById.get('o-new')?.pricing.clientTotal ?? 0
    expect(derived.clientById.get('c-08')?.tier.id).toBe('bronze')

    state = run(state, {
      type: 'ADD_PAYMENT',
      orderId: 'o-new',
      payment: { id: 'p1', amount: Math.round(price / 2), kind: 'advance', at: NOW.toISOString(), note: '' },
    })
    derived = deriveAll(state, NOW.getTime())
    const view = derived.orderById.get('o-new')
    expect(view?.paymentStatus).toBe('advance')
    expect(view?.remaining).toBe(price - Math.round(price / 2))
    expect(derived.clientById.get('c-08')?.coins).toBe(Math.floor(Math.round(price / 2) / 10))

    state = run(state, {
      type: 'ADD_PAYMENT',
      orderId: 'o-new',
      payment: { id: 'p2', amount: price - Math.round(price / 2), kind: 'payment', at: NOW.toISOString(), note: '' },
    })
    derived = deriveAll(state, NOW.getTime())
    expect(derived.orderById.get('o-new')?.paymentStatus).toBe('paid')
    expect(derived.orderById.get('o-new')?.paidPercent).toBe(100)
  })

  it('платёж до 10 000 ₽ — Бронзовая, больше — Серебряная', () => {
    let state = run(base, { type: 'CREATE_ORDER', order: newOrder() })
    const pay = (amount: number, id: string): Action => ({
      type: 'ADD_PAYMENT',
      orderId: 'o-new',
      payment: { id, amount, kind: 'payment', at: NOW.toISOString(), note: '' },
    })
    state = run(state, pay(10_000, 'p1'))
    expect(deriveAll(state, NOW.getTime()).clientById.get('c-08')?.tier.id).toBe('bronze')
    state = run(state, pay(1, 'p2'))
    expect(deriveAll(state, NOW.getTime()).clientById.get('c-08')?.tier.id).toBe('silver')
  })

  it('ручная смена статуса карты имеет приоритет и снимается', () => {
    let state = run(base, { type: 'SET_TIER_OVERRIDE', clientId: 'c-07', tier: 'diamond' })
    let view = deriveAll(state, NOW.getTime()).clientById.get('c-07')
    expect(view?.tier.id).toBe('diamond')
    expect(view?.tierOverridden).toBe(true)
    expect(view?.autoTier.id).toBe('bronze')
    state = run(state, { type: 'SET_TIER_OVERRIDE', clientId: 'c-07', tier: null })
    view = deriveAll(state, NOW.getTime()).clientById.get('c-07')
    expect(view?.tier.id).toBe('bronze')
  })

  it('нулевой и отрицательный платёж игнорируется', () => {
    const state = run(base, { type: 'CREATE_ORDER', order: newOrder() })
    const same = run(state, {
      type: 'ADD_PAYMENT',
      orderId: 'o-new',
      payment: { id: 'x', amount: 0, kind: 'payment', at: NOW.toISOString(), note: '' },
    })
    expect(same.orders.find((order) => order.id === 'o-new')?.payments).toHaveLength(0)
  })
})

describe('этапы производства', () => {
  const base = run(createSeed(NOW), { type: 'CREATE_ORDER', order: newOrder() })
  const at = NOW.toISOString()

  it('клик по этапу сразу меняет процент готовности', () => {
    const state = run(base, { type: 'SET_STAGE', orderId: 'o-new', stage: 4, progress: 50, at })
    expect(deriveAll(state, NOW.getTime()).orderById.get('o-new')?.progress).toBe(44)
  })

  it('дойти до «Готово» — закрыть заказ и добавить его мастеру к выплате', () => {
    const before = deriveAll(base, NOW.getTime()).masterById.get(MASTER_IDS.artem)
    const state = run(base, { type: 'SET_STAGE', orderId: 'o-new', stage: 8, progress: 0, at })
    const derived = deriveAll(state, NOW.getTime())
    const after = derived.masterById.get(MASTER_IDS.artem)
    const view = derived.orderById.get('o-new')
    expect(view?.status).toBe('ready')
    expect(view?.progress).toBe(100)
    expect((after?.balance ?? 0) - (before?.balance ?? 0)).toBe(view?.payroll.total)
    expect(after?.activeTasks).toBe((before?.activeTasks ?? 0) - 1)
  })

  it('возврат с «Готово» убирает заказ из выплаты', () => {
    let state = run(base, { type: 'SET_STAGE', orderId: 'o-new', stage: 8, progress: 0, at })
    state = run(state, { type: 'SET_STAGE', orderId: 'o-new', stage: 5, progress: 10, at })
    expect(state.orders.find((order) => order.id === 'o-new')?.completedAt).toBeNull()
  })
})

describe('бонусы, штрафы и выплата ЗП', () => {
  const at = NOW.toISOString()
  const adjustment = (code: string, id = `a-${code}`): Action => ({
    type: 'TOGGLE_ADJUSTMENT',
    orderId: 'o-new',
    adjustment: {
      id,
      kind: code.startsWith('b-') ? 'bonus' : 'penalty',
      code,
      qty: 1,
      customAmount: null,
      at,
    },
  })
  const closed = run(
    createSeed(NOW),
    { type: 'CREATE_ORDER', order: newOrder() },
    { type: 'SET_STAGE', orderId: 'o-new', stage: 8, progress: 0, at },
  )

  it('кнопка бонуса мгновенно пересчитывает ЗП по заказу и баланс мастера', () => {
    const before = deriveAll(closed, NOW.getTime())
    const base = before.orderById.get('o-new')?.payroll.base ?? 0
    const after = deriveAll(run(closed, adjustment('b-otk')), NOW.getTime())
    const view = after.orderById.get('o-new')
    expect(view?.payroll.bonusTotal).toBe(Math.round(base * 0.05))
    expect((after.masterById.get(MASTER_IDS.artem)?.balance ?? 0) - (before.masterById.get(MASTER_IDS.artem)?.balance ?? 0)).toBe(
      Math.round(base * 0.05),
    )
  })

  it('штраф уменьшает баланс и попадает в «удержано за брак»', () => {
    const state = run(closed, adjustment('p-minor-defect'))
    const derived = deriveAll(state, NOW.getTime())
    const base = derived.orderById.get('o-new')?.payroll.base ?? 0
    expect(derived.orderById.get('o-new')?.payroll.penaltyTotal).toBe(Math.round(base * 0.1))
    const summary = computePayrollSummary(derived.masters, state.payouts, null)
    const reference = computePayrollSummary(deriveAll(closed, NOW.getTime()).masters, closed.payouts, null)
    expect(summary.withheld - reference.withheld).toBe(Math.round(base * 0.1))
  })

  it('«Выплатить ЗП» обнуляет баланс, переносит сумму в «Выплачено» и создаёт акт', () => {
    const state = run(closed, adjustment('b-otk'))
    const derived = deriveAll(state, NOW.getTime())
    const master = derived.masterById.get(MASTER_IDS.artem)
    expect(master?.unpaid.length).toBeGreaterThan(0)
    const draft = buildPayoutDraft(MASTER_IDS.artem, master?.unpaid ?? [])
    const summaryBefore = computePayrollSummary(derived.masters, state.payouts, null)

    const paid = run(state, {
      type: 'PAY_MASTER',
      payoutId: 'payout-new',
      masterId: MASTER_IDS.artem,
      lines: draft.lines,
      at,
    })
    const after = deriveAll(paid, NOW.getTime())
    const summaryAfter = computePayrollSummary(after.masters, paid.payouts, null)

    expect(after.masterById.get(MASTER_IDS.artem)?.balance).toBe(0)
    expect(summaryAfter.paid - summaryBefore.paid).toBe(draft.total)
    expect(summaryAfter.balance).toBe(summaryBefore.balance - draft.total)
    expect(paid.payouts[paid.payouts.length - 1]?.actNo).toBe(state.counters.act + 1)
    expect(after.finance.transactions.some((t) => t.id === 'payout-payout-new')).toBe(true)
    expect(paid.orders.find((order) => order.id === 'o-new')?.payoutId).toBe('payout-new')
  })

  it('повторная выплата тех же заказов ничего не меняет', () => {
    const derived = deriveAll(closed, NOW.getTime())
    const draft = buildPayoutDraft(MASTER_IDS.artem, derived.masterById.get(MASTER_IDS.artem)?.unpaid ?? [])
    const action: Action = { type: 'PAY_MASTER', payoutId: 'p-a', masterId: MASTER_IDS.artem, lines: draft.lines, at }
    const once = run(closed, action)
    const twice = run(once, { ...action, payoutId: 'p-b' })
    expect(twice).toBe(once)
  })

  it('после выплаты бонусы/штрафы и откат этапа заблокированы (акт подписан)', () => {
    const derived = deriveAll(closed, NOW.getTime())
    const draft = buildPayoutDraft(MASTER_IDS.artem, derived.masterById.get(MASTER_IDS.artem)?.unpaid ?? [])
    const paid = run(closed, { type: 'PAY_MASTER', payoutId: 'p-a', masterId: MASTER_IDS.artem, lines: draft.lines, at })
    const tried = run(paid, adjustment('p-tz'), { type: 'SET_STAGE', orderId: 'o-new', stage: 3, progress: 0, at })
    const order = tried.orders.find((item) => item.id === 'o-new')
    expect(order?.adjustments).toHaveLength(0)
    expect(order?.stage).toBe(8)
  })

  it('выплачивать можно только заказы этого мастера', () => {
    const derived = deriveAll(closed, NOW.getTime())
    const draft = buildPayoutDraft(MASTER_IDS.artem, derived.masterById.get(MASTER_IDS.artem)?.unpaid ?? [])
    const state = run(closed, { type: 'PAY_MASTER', payoutId: 'p-x', masterId: MASTER_IDS.roman, lines: draft.lines, at })
    expect(state).toBe(closed)
  })
})

describe('финансы, склад и настройки', () => {
  const base = createSeed(NOW)
  const at = NOW.toISOString()

  it('новый расход и приход материала пересчитывают P&L', () => {
    const before = deriveAll(base, NOW.getTime()).finance.current
    const state = run(
      base,
      { type: 'ADD_EXPENSE', expense: { id: 'e1', at, title: 'Аренда', category: 'rent', amount: 5000 } },
      { type: 'ADD_STOCK_MOVEMENT', movement: { id: 's1', itemId: 'zip-double', qty: 10, cost: 1200, at, note: '' } },
    )
    const derived = deriveAll(state, NOW.getTime())
    expect(derived.finance.current.expenses - before.expenses).toBe(5000)
    expect(derived.finance.current.materials - before.materials).toBe(1200)
    expect(derived.finance.current.profit).toBe(before.profit - 6200)
    expect(derived.stockById.get('zip-double')?.balance.balance).toBe(10)
  })

  it('налог НПД — 4% от выручки месяца', () => {
    const month = deriveAll(base, NOW.getTime()).finance.current
    expect(month.tax).toBe(Math.round(month.revenue * 0.04))
  })

  it('правка тарифа не меняет цену, выручку и ЗП уже созданных заказов', () => {
    const before = deriveAll(base, NOW.getTime())
    const state = run(base, { type: 'SET_SERVICE_OVERRIDE', serviceId: '2.1', override: { clientPrice: 5000, masterRate: 3000 } })
    const after = deriveAll(state, NOW.getTime())
    const old = state.orders.filter((item) => item.serviceId === '2.1')
    expect(old.length).toBeGreaterThan(0)
    for (const order of old) {
      expect(order.tariff).toBeDefined()
      expect(after.orderById.get(order.id)?.pricing.clientTotal).toBe(before.orderById.get(order.id)?.pricing.clientTotal)
      expect(after.orderById.get(order.id)?.payroll.total).toBe(before.orderById.get(order.id)?.payroll.total)
    }
    expect(after.finance.totals.revenue).toBe(before.finance.totals.revenue)
    expect(after.finance.totals.payroll).toBe(before.finance.totals.payroll)
  })

  it('новый заказ после правки тарифа считается по новой цене и фиксирует её', () => {
    const plain = run(base, { type: 'CREATE_ORDER', order: newOrder({ serviceId: '2.1', options: emptyOptions() }) })
    const edited = run(
      base,
      { type: 'SET_SERVICE_OVERRIDE', serviceId: '2.1', override: { clientPrice: 5000 } },
      { type: 'CREATE_ORDER', order: newOrder({ serviceId: '2.1', options: emptyOptions() }) },
    )
    const a = deriveAll(plain, NOW.getTime()).orderById.get('o-new')
    const b = deriveAll(edited, NOW.getTime()).orderById.get('o-new')
    expect(b?.service.clientPrice).toBe(5000)
    expect(b?.order.tariff?.clientPrice).toBe(5000)
    expect(a?.order.tariff?.clientPrice).not.toBe(5000)
    // Сброс тарифа не возвращает «старую» цену задним числом — заказ хранит свою.
    const reset = run(edited, { type: 'SET_SERVICE_OVERRIDE', serviceId: '2.1', override: null })
    expect(deriveAll(reset, NOW.getTime()).orderById.get('o-new')?.service.clientPrice).toBe(5000)
  })

  it('данные из старой версии без тарифа в заказе получают его при загрузке', () => {
    const legacy = JSON.parse(serializeState(base)) as { orders: Array<Record<string, unknown>> }
    for (const order of legacy.orders) delete order.tariff
    const parsed = parseState(JSON.stringify(legacy))
    expect(parsed).not.toBeNull()
    expect(parsed?.orders.every((order) => order.tariff !== undefined)).toBe(true)
  })

  it('ёмкость мастера меняет загрузку', () => {
    const before = deriveAll(base, NOW.getTime()).masterById.get(MASTER_IDS.roman)?.load ?? 0
    const state = run(base, { type: 'UPDATE_MASTER', masterId: MASTER_IDS.roman, patch: { capacity: 10 } })
    const after = deriveAll(state, NOW.getTime()).masterById.get(MASTER_IDS.roman)?.load ?? 0
    expect(after).toBeLessThan(before)
  })

  it('rev растёт при каждом изменении, REPLACE_STATE приносит свой', () => {
    const state = run(base, { type: 'ADD_EXPENSE', expense: { id: 'e1', at, title: 'x', category: 'other', amount: 1 } })
    expect(state.rev).toBe(base.rev + 1)
    const replaced = run(state, { type: 'REPLACE_STATE', state: { ...base, rev: 42 } })
    expect(replaced.rev).toBe(42)
  })

  it('пустое состояние считается без ошибок', () => {
    const derived = deriveAll(createEmptyState(), NOW.getTime())
    expect(derived.orders).toHaveLength(0)
    expect(derived.finance.current.revenue).toBe(0)
    expect(derived.averageCheck).toBe(0)
    expect(derived.masters).toHaveLength(3)
  })
})

describe('регистрация клиента и лиды', () => {
  const base = createSeed(NOW)
  const client = {
    id: 'c-new',
    lastName: 'Тестова',
    firstName: 'Анна',
    middleName: '',
    phone: '+7 913 111-22-33',
    email: 'a@test.ru',
    contact: 'telegram' as const,
    createdAt: NOW.toISOString(),
    source: 'site' as const,
    tierOverride: null,
  }

  it('новый клиент с сайта создаёт заявку в «Новых лидах»', () => {
    const state = run(base, {
      type: 'REGISTER_CLIENT',
      client,
      lead: { id: 'l-new', clientId: 'c-new', createdAt: NOW.toISOString(), status: 'new', contactedAt: null },
    })
    const derived = deriveAll(state, NOW.getTime())
    expect(derived.newLeads.length).toBe(3)
    expect(derived.newLeads[0]?.name).toBe('Тестова Анна')
  })

  it('связь с клиентом помечает лид как обработанный и убирает из новых', () => {
    const state = run(base, { type: 'SET_LEAD_STATUS', leadId: 'l-08', status: 'contacted', at: NOW.toISOString() })
    const derived = deriveAll(state, NOW.getTime())
    expect(derived.newLeads.map((item) => item.lead.id)).toEqual(['l-09'])
    expect(state.leads.find((lead) => lead.id === 'l-08')?.contactedAt).toBe(NOW.toISOString())
  })
})
