'use client'

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  useState,
} from 'react'

import { deriveAll, buildPayoutDraft, type Derived } from '@/lib/domain/derive'
import { getAdjustmentDef } from '@/lib/domain/catalog'
import { isValidEmail, normalizeEmail, phoneDigits, formatPhone } from '@/lib/domain/client'
import type {
  AppState,
  Client,
  ComplexityId,
  Expense,
  ExpenseCategory,
  LeadStatus,
  LoyaltyTierId,
  MaterialId,
  MessengerId,
  Master,
  OrderOptions,
  Payout,
  ServiceOverride,
  StockMovement,
} from '@/lib/domain/types'
import { reducer, type Action, type OrderPatch } from '@/store/reducer'
import { createEmptyState, createSeed } from '@/store/seed'
import {
  STATE_STORAGE_KEY,
  parseState,
  readStoredState,
  serializeState,
  writeStoredState,
} from '@/store/storage'

/* ------------------------------------------------------------------ вспомогательное */

export function newId(prefix: string): string {
  const random =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID().replace(/-/g, '').slice(0, 10)
      : Math.random().toString(36).slice(2, 12)
  return `${prefix}-${random}`
}

/* -------------------------------------------------------------------------- действия */

export interface ClientInput {
  lastName: string
  firstName: string
  middleName: string
  phone: string
  email: string
  contact: MessengerId
}

export interface OrderInput {
  clientId: string
  serviceId: string
  complexityId: ComplexityId
  materialId: MaterialId
  options: OrderOptions
  donors: { title: string; materialId: MaterialId; weightKg: number; note: string }[]
  masterId: string
  requestedDeadline: string
  deadline: string
  apsShiftDays: number
  comment: string
  /** Аванс при создании, ₽ (0 — без аванса). */
  advance: number
  leadId?: string
}

export interface AdjustmentInput {
  code: string
  qty?: number
  customAmount?: number
}

export interface Actions {
  registerClient: (input: ClientInput) => { clientId: string; created: boolean }
  saveClient: (client: Client) => void
  setTierOverride: (clientId: string, tier: LoyaltyTierId | null) => void
  setLeadStatus: (leadId: string, status: LeadStatus) => void
  createOrder: (input: OrderInput) => string
  updateOrder: (orderId: string, patch: OrderPatch) => void
  cancelOrder: (orderId: string) => void
  restoreOrder: (orderId: string) => void
  setStage: (orderId: string, stage: number, progress?: number) => void
  setStageProgress: (orderId: string, progress: number) => void
  addPayment: (orderId: string, amount: number, note?: string) => void
  removePayment: (orderId: string, paymentId: string) => void
  toggleAdjustment: (orderId: string, input: AdjustmentInput) => void
  removeAdjustment: (orderId: string, adjustmentId: string) => void
  /** Выплатить ЗП мастеру за все закрытые заказы. Возвращает проведённую выплату. */
  payMaster: (masterId: string) => Payout | null
  addExpense: (input: { title: string; category: ExpenseCategory; amount: number; at?: string }) => void
  removeExpense: (expenseId: string) => void
  receiveStock: (input: { itemId: string; qty: number; cost: number; note?: string }) => void
  writeOffStock: (input: { itemId: string; qty: number; note?: string }) => void
  updateMaster: (masterId: string, patch: Partial<Pick<Master, 'capacity' | 'name' | 'role'>>) => void
  setServiceOverride: (serviceId: string, override: ServiceOverride | null) => void
  resetDemo: () => void
  clearAll: () => void
  /** Загрузить состояние из JSON-файла резервной копии. false — файл не подошёл. */
  importState: (json: string) => boolean
}

interface AppContextValue {
  state: AppState
  derived: Derived
  actions: Actions
  /** Данные из localStorage загружены. */
  ready: boolean
  /** Последняя запись в localStorage не удалась. */
  persistFailed: boolean
  /** «Сейчас» — обновляется раз в минуту, от него считаются сроки. */
  now: number
}

const AppContext = createContext<AppContextValue | null>(null)

export function useApp(): AppContextValue {
  const value = useContext(AppContext)
  if (!value) throw new Error('useApp должен вызываться внутри <AppProvider>')
  return value
}

export function useActions(): Actions {
  return useApp().actions
}

export function useDerived(): Derived {
  return useApp().derived
}

/* ------------------------------------------------------------------------ провайдер */

export function AppProvider({ children }: { children: React.ReactNode }) {
  // На сервере и при первой отрисовке клиента состояние пустое; реальное подтягивается
  // в эффекте ниже. Иначе разметка сервера и клиента разошлась бы.
  const [state, dispatch] = useReducer(reducer, undefined, createEmptyState)
  const [ready, setReady] = useState(false)
  const [persistFailed, setPersistFailed] = useState(false)
  const [now, setNow] = useState(() => Date.now())

  const stateRef = useRef(state)
  stateRef.current = state
  /** Последний JSON, который эта вкладка записала или получила из хранилища. */
  const lastJson = useRef<string | null>(null)

  // Загрузка при старте: либо сохранённое состояние, либо демо-данные.
  useEffect(() => {
    const stored = readStoredState()
    const initial = stored ?? createSeed(new Date())
    const json = serializeState(initial)
    lastJson.current = json
    if (!stored) setPersistFailed(!writeStoredState(json))
    dispatch({ type: 'REPLACE_STATE', state: initial })
    setReady(true)
  }, [])

  // Сохранение при любом изменении.
  useEffect(() => {
    if (!ready) return
    const json = serializeState(state)
    if (json === lastJson.current) return
    lastJson.current = json
    setPersistFailed(!writeStoredState(json))
  }, [state, ready])

  // Синхронизация между вкладками: изменили в одной — обновились все.
  useEffect(() => {
    const onStorage = (event: StorageEvent): void => {
      if (event.key !== STATE_STORAGE_KEY || event.newValue === null) return
      if (event.newValue === lastJson.current) return
      const next = parseState(event.newValue)
      if (!next) return
      lastJson.current = event.newValue
      dispatch({ type: 'REPLACE_STATE', state: next })
    }
    window.addEventListener('storage', onStorage)
    return () => window.removeEventListener('storage', onStorage)
  }, [])

  // Часы: раз в минуту, чтобы «просрочен» и «сегодня» обновлялись без перезагрузки.
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 60_000)
    return () => window.clearInterval(timer)
  }, [])

  const derived = useMemo(() => deriveAll(state, now), [state, now])
  const derivedRef = useRef(derived)
  derivedRef.current = derived

  const actions = useMemo<Actions>(() => {
    const send = (action: Action): void => dispatch(action)
    const iso = (): string => new Date().toISOString()

    return {
      registerClient: (input) => {
        const current = stateRef.current
        const digits = phoneDigits(input.phone)
        const email = normalizeEmail(input.email)
        const existing = current.clients.find(
          (client) =>
            phoneDigits(client.phone) === digits ||
            (isValidEmail(email) && normalizeEmail(client.email) === email),
        )
        const fields = {
          lastName: input.lastName.trim(),
          firstName: input.firstName.trim(),
          middleName: input.middleName.trim(),
          phone: formatPhone(input.phone),
          email,
          contact: input.contact,
        }
        if (existing) {
          send({ type: 'REGISTER_CLIENT', client: { ...existing, ...fields }, lead: null })
          return { clientId: existing.id, created: false }
        }
        const at = iso()
        const client: Client = {
          id: newId('c'),
          ...fields,
          createdAt: at,
          source: 'site',
          tierOverride: null,
        }
        send({
          type: 'REGISTER_CLIENT',
          client,
          lead: { id: newId('l'), clientId: client.id, createdAt: at, status: 'new', contactedAt: null },
        })
        return { clientId: client.id, created: true }
      },

      saveClient: (client) => send({ type: 'UPSERT_CLIENT', client }),
      setTierOverride: (clientId, tier) => send({ type: 'SET_TIER_OVERRIDE', clientId, tier }),
      setLeadStatus: (leadId, status) => send({ type: 'SET_LEAD_STATUS', leadId, status, at: iso() }),

      createOrder: (input) => {
        const id = newId('o')
        const at = iso()
        const advance = Math.round(input.advance)
        send({
          type: 'CREATE_ORDER',
          leadId: input.leadId,
          order: {
            id,
            clientId: input.clientId,
            serviceId: input.serviceId,
            complexityId: input.complexityId,
            materialId: input.materialId,
            options: input.options,
            donors: input.donors.map((donor) => ({ ...donor, id: newId('d') })),
            masterId: input.masterId,
            createdAt: at,
            deadline: input.deadline,
            requestedDeadline: input.requestedDeadline,
            apsShiftDays: input.apsShiftDays,
            comment: input.comment,
            payments:
              advance > 0
                ? [{ id: newId('pay'), amount: advance, kind: 'advance', at, note: 'Аванс при оформлении' }]
                : [],
          },
        })
        return id
      },

      updateOrder: (orderId, patch) => send({ type: 'UPDATE_ORDER', orderId, patch }),
      cancelOrder: (orderId) => send({ type: 'SET_ORDER_STATE', orderId, state: 'cancelled' }),
      restoreOrder: (orderId) => send({ type: 'SET_ORDER_STATE', orderId, state: 'active' }),
      setStage: (orderId, stage, progress = 0) =>
        send({ type: 'SET_STAGE', orderId, stage, progress, at: iso() }),
      setStageProgress: (orderId, progress) => send({ type: 'SET_STAGE_PROGRESS', orderId, progress }),

      addPayment: (orderId, amount, note = '') => {
        const order = stateRef.current.orders.find((item) => item.id === orderId)
        if (!order) return
        send({
          type: 'ADD_PAYMENT',
          orderId,
          payment: {
            id: newId('pay'),
            amount,
            // Первый платёж по заказу — аванс, дальнейшие — оплата.
            kind: order.payments.length === 0 ? 'advance' : 'payment',
            at: iso(),
            note,
          },
        })
      },
      removePayment: (orderId, paymentId) => send({ type: 'REMOVE_PAYMENT', orderId, paymentId }),

      toggleAdjustment: (orderId, input) => {
        const def = getAdjustmentDef(input.code)
        if (!def) return
        send({
          type: 'TOGGLE_ADJUSTMENT',
          orderId,
          adjustment: {
            id: newId('adj'),
            kind: def.kind,
            code: input.code,
            qty: input.qty ?? 1,
            customAmount: input.customAmount ?? null,
            at: iso(),
          },
        })
      },
      removeAdjustment: (orderId, adjustmentId) =>
        send({ type: 'REMOVE_ADJUSTMENT', orderId, adjustmentId }),

      payMaster: (masterId) => {
        const view = derivedRef.current.masterById.get(masterId)
        if (!view || view.unpaid.length === 0 || view.balance <= 0) return null
        const draft = buildPayoutDraft(masterId, view.unpaid)
        const payoutId = newId('payout')
        const at = iso()
        send({ type: 'PAY_MASTER', payoutId, masterId, lines: draft.lines, at })
        return {
          id: payoutId,
          masterId,
          at,
          // Номер акта присваивает редьюсер; для превью берём следующий по счётчику.
          actNo: stateRef.current.counters.act + 1,
          lines: draft.lines,
          base: draft.base,
          bonuses: draft.bonuses,
          penalties: draft.penalties,
          total: draft.total,
        }
      },

      addExpense: ({ title, category, amount, at }) => {
        const value = Math.round(amount)
        if (!Number.isFinite(value) || value <= 0) return
        const expense: Expense = { id: newId('e'), at: at ?? iso(), title: title.trim() || 'Расход', category, amount: value }
        send({ type: 'ADD_EXPENSE', expense })
      },
      removeExpense: (expenseId) => send({ type: 'REMOVE_EXPENSE', expenseId }),

      receiveStock: ({ itemId, qty, cost, note = '' }) => {
        if (!Number.isFinite(qty) || qty <= 0) return
        const movement: StockMovement = {
          id: newId('s'),
          itemId,
          qty: Math.round(qty * 100) / 100,
          cost: Math.max(0, Math.round(cost)),
          at: iso(),
          note: note || 'Приход',
        }
        send({ type: 'ADD_STOCK_MOVEMENT', movement })
      },
      writeOffStock: ({ itemId, qty, note = '' }) => {
        if (!Number.isFinite(qty) || qty <= 0) return
        const movement: StockMovement = {
          id: newId('s'),
          itemId,
          qty: -Math.round(qty * 100) / 100,
          cost: 0,
          at: iso(),
          note: note || 'Списание',
        }
        send({ type: 'ADD_STOCK_MOVEMENT', movement })
      },

      updateMaster: (masterId, patch) => send({ type: 'UPDATE_MASTER', masterId, patch }),
      setServiceOverride: (serviceId, override) =>
        send({ type: 'SET_SERVICE_OVERRIDE', serviceId, override }),

      resetDemo: () =>
        send({
          type: 'REPLACE_STATE',
          state: { ...createSeed(new Date()), rev: stateRef.current.rev + 1 },
        }),
      clearAll: () =>
        send({
          type: 'REPLACE_STATE',
          state: { ...createEmptyState(), rev: stateRef.current.rev + 1 },
        }),
      importState: (json) => {
        const parsed = parseState(json)
        if (!parsed) return false
        send({ type: 'REPLACE_STATE', state: { ...parsed, rev: stateRef.current.rev + 1 } })
        return true
      },
    }
  }, [])

  const value = useMemo<AppContextValue>(
    () => ({ state, derived, actions, ready, persistFailed, now }),
    [state, derived, actions, ready, persistFailed, now],
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}
