import type { Metadata, Viewport } from 'next'
import '@fontsource-variable/inter'
import '@fontsource-variable/jetbrains-mono'

import './globals.css'

import { Providers } from '@/components/common/Providers'
import { APP_NAME } from '@/config/app'

export const metadata: Metadata = {
  title: { default: `${APP_NAME} — CRM для апсайклинг-студии`, template: `%s · ${APP_NAME}` },
  description: 'CRM, ERP и трекер производства для студии апсайклинга одежды RE:clothe.',
  // Внутренний инструмент студии: закрываем от индексации.
  robots: { index: false, follow: false },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  // Матовый графит — цвет фона интерфейса (только тёмная тема).
  themeColor: '#1A1A1A',
  colorScheme: 'dark',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" className="dark">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
