'use client'

import { useEffect } from 'react'
import Link from 'next/link'
import { TriangleAlert } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

interface DashboardErrorProps {
  error: Error & { digest?: string }
  reset: () => void
}

/** Ошибка внутри раздела: оболочка (сайдбар, топбар) остаётся на месте, меняется только контент. */
export default function DashboardError({ error, reset }: DashboardErrorProps) {
  useEffect(() => {
    // Этап 6: отправка в систему мониторинга (Sentry и т.п.).
    console.error(error)
  }, [error])

  return (
    <Card role="alert" className="mx-auto mt-10 max-w-lg">
      <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
        <TriangleAlert className="size-8 text-destructive-text" aria-hidden="true" />
        <h1 className="text-lg font-semibold">Что-то пошло не так</h1>
        <p className="text-sm text-muted-foreground">
          Не удалось загрузить раздел. Попробуйте ещё раз — данные не потеряны.
        </p>
        {error.digest && (
          <p className="font-mono text-xs text-muted-foreground">Код ошибки: {error.digest}</p>
        )}
        <div className="mt-2 flex gap-2">
          <Button onClick={reset}>Повторить</Button>
          <Button asChild variant="outline">
            <Link href="/">На дашборд</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
