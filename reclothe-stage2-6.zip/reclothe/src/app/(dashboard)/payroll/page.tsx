import type { Metadata } from 'next'

import { PayrollView } from '@/components/payroll/PayrollView'

export const metadata: Metadata = { title: 'Бухгалтерия и ЗП' }

export default function PayrollPage() {
  return <PayrollView />
}
