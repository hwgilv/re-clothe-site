import type { Metadata } from 'next'

import { ProductionView } from '@/components/production/ProductionView'

export const metadata: Metadata = { title: 'Производство' }

export default function ProductionPage() {
  return <ProductionView />
}
