import type { Metadata } from 'next'

import { InventoryView } from '@/components/inventory/InventoryView'

export const metadata: Metadata = { title: 'Склад' }

export default function InventoryPage() {
  return <InventoryView />
}
