import type { Metadata } from 'next'

import { FinanceView } from '@/components/finance/FinanceView'

export const metadata: Metadata = { title: 'Финансы' }

export default function FinancePage() {
  return <FinanceView />
}
