import type { Metadata } from 'next'
import { Suspense } from 'react'

import { PageSkeleton } from '@/components/common/PageSkeleton'
import { OrdersView } from '@/components/orders/OrdersView'

export const metadata: Metadata = { title: 'Заказы' }

export default function OrdersPage() {
  // useSearchParams (вкладка ?tab=leads) требует Suspense при статической сборке.
  return (
    <Suspense fallback={<PageSkeleton />}>
      <OrdersView />
    </Suspense>
  )
}
