import type { Metadata } from 'next'

import { OrderDetailView } from '@/components/orders/OrderDetailView'

export const metadata: Metadata = { title: 'Заказ' }

export default function OrderPage({ params }: { params: { id: string } }) {
  return <OrderDetailView orderKey={params.id} />
}
