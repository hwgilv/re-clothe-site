'use client'

import { useEffect } from 'react'

import './globals.css'

import { Button } from '@/components/ui/button'

/**
 * Последний рубеж: ошибка в корневом layout. Заменяет весь документ, поэтому
 * провайдеры темы здесь недоступны — фиксируем тёмную тему классом.
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    console.error(error)
  }, [error])

  return (
    <html lang="ru" className="dark">
      <body>
        <main
          role="alert"
          className="flex min-h-dvh flex-col items-center justify-center gap-3 px-4 text-center"
        >
          <h1 className="text-lg font-semibold">Приложение не смогло загрузиться</h1>
          <p className="text-sm text-muted-foreground">Попробуйте перезагрузить страницу.</p>
          {error.digest && (
            <p className="font-mono text-xs text-muted-foreground">Код ошибки: {error.digest}</p>
          )}
          <Button onClick={reset}>Повторить</Button>
        </main>
      </body>
    </html>
  )
}
