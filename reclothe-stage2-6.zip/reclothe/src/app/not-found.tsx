import type { Metadata } from 'next'
import Link from 'next/link'

import { Logo } from '@/components/common/Logo'
import { Button } from '@/components/ui/button'

export const metadata: Metadata = { title: 'Страница не найдена' }

export default function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-4 px-4 text-center">
      <Logo />
      <p className="font-mono text-6xl font-bold text-primary-text">404</p>
      <h1 className="text-lg font-semibold">Страница не найдена</h1>
      <p className="max-w-sm text-sm text-muted-foreground">
        Возможно, ссылка устарела или раздел ещё не готов.
      </p>
      <Button asChild>
        <Link href="/">На дашборд</Link>
      </Button>
    </main>
  )
}
