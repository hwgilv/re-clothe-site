/**
 * Одна админская сессия на браузер. Вкладка, вошедшая как администратор, пишет в
 * localStorage «замок» с отметкой времени и обновляет её каждые 1,5 секунды.
 * Другая вкладка видит свежий замок и показывает «Доступ ограничен, сессия активна».
 * Если вкладку закрыли аварийно, замок просто протухает через несколько секунд.
 */

export const LOCK_STORAGE_KEY = 'reclothe.admin.lock.v1'
export const LOCK_HEARTBEAT_MS = 1_500
export const LOCK_STALE_MS = 5_000

export interface AdminLock {
  tab: string
  ts: number
}

export type LockVerdict = 'free' | 'mine' | 'taken'

/** Чистая логика: кому принадлежит замок в момент `now`. */
export function evaluateLock(lock: AdminLock | null, tabId: string, now: number): LockVerdict {
  if (!lock) return 'free'
  if (lock.tab === tabId) return 'mine'
  if (now - lock.ts > LOCK_STALE_MS || lock.ts - now > LOCK_STALE_MS) return 'free'
  return 'taken'
}

export function parseLock(raw: string | null): AdminLock | null {
  if (!raw) return null
  try {
    const data = JSON.parse(raw) as Partial<AdminLock>
    if (typeof data.tab === 'string' && typeof data.ts === 'number') {
      return { tab: data.tab, ts: data.ts }
    }
    return null
  } catch {
    return null
  }
}

function readLock(): AdminLock | null {
  try {
    return parseLock(window.localStorage.getItem(LOCK_STORAGE_KEY))
  } catch {
    return null
  }
}

/** Идентификатор вкладки: живёт, пока открыта страница (при перезагрузке меняется). */
let cachedTabId: string | null = null

export function getTabId(): string {
  if (cachedTabId) return cachedTabId
  const random =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID()
      : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`
  cachedTabId = random
  return random
}

export function isAdminLockTaken(now: number = Date.now()): boolean {
  return evaluateLock(readLock(), getTabId(), now) === 'taken'
}

/** Пытается занять замок. false — админ уже работает в другой вкладке. */
export function acquireAdminLock(now: number = Date.now()): boolean {
  const verdict = evaluateLock(readLock(), getTabId(), now)
  if (verdict === 'taken') return false
  try {
    window.localStorage.setItem(LOCK_STORAGE_KEY, JSON.stringify({ tab: getTabId(), ts: now }))
    return true
  } catch {
    // Хранилище недоступно — блокировать нечем, пускаем (одна вкладка всё равно одна).
    return true
  }
}

/** Продлевает замок. false — замок перехватила другая вкладка. */
export function refreshAdminLock(now: number = Date.now()): boolean {
  const verdict = evaluateLock(readLock(), getTabId(), now)
  if (verdict === 'taken') return false
  return acquireAdminLock(now)
}

export function releaseAdminLock(): void {
  try {
    const lock = readLock()
    if (lock && lock.tab === getTabId()) window.localStorage.removeItem(LOCK_STORAGE_KEY)
  } catch {
    // ничего: замок протухнет сам
  }
}
