/**
 * Роль текущей вкладки. Хранится в sessionStorage: она живёт, пока открыта вкладка,
 * и не «перетекает» в другие — поэтому админ и клиент могут работать в разных вкладках.
 */

export const SESSION_STORAGE_KEY = 'reclothe.session.v1'

export type Session = { role: 'admin' } | { role: 'client'; clientId: string }

export function readSession(): Session | null {
  try {
    const raw = window.sessionStorage.getItem(SESSION_STORAGE_KEY)
    if (!raw) return null
    const data = JSON.parse(raw) as { role?: string; clientId?: unknown }
    if (data.role === 'admin') return { role: 'admin' }
    if (data.role === 'client' && typeof data.clientId === 'string') {
      return { role: 'client', clientId: data.clientId }
    }
    return null
  } catch {
    return null
  }
}

export function writeSession(session: Session | null): void {
  try {
    if (session) window.sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session))
    else window.sessionStorage.removeItem(SESSION_STORAGE_KEY)
  } catch {
    // без sessionStorage роль живёт только в памяти вкладки
  }
}
