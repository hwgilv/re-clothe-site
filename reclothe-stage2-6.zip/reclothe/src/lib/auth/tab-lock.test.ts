import { describe, expect, it } from 'vitest'

import { LOCK_STALE_MS, evaluateLock, parseLock } from '@/lib/auth/tab-lock'

describe('evaluateLock', () => {
  const now = 1_000_000
  it('нет замка — свободно', () => {
    expect(evaluateLock(null, 'a', now)).toBe('free')
  })
  it('свой замок — мой', () => {
    expect(evaluateLock({ tab: 'a', ts: now }, 'a', now)).toBe('mine')
  })
  it('чужой свежий замок — занято («Доступ ограничен, сессия активна»)', () => {
    expect(evaluateLock({ tab: 'b', ts: now - 1_000 }, 'a', now)).toBe('taken')
  })
  it('чужой протухший замок — свободно', () => {
    expect(evaluateLock({ tab: 'b', ts: now - LOCK_STALE_MS - 1 }, 'a', now)).toBe('free')
  })
  it('замок «из будущего» (сбитые часы) не блокирует навсегда', () => {
    expect(evaluateLock({ tab: 'b', ts: now + LOCK_STALE_MS + 1 }, 'a', now)).toBe('free')
  })
})

describe('parseLock', () => {
  it('разбирает корректный JSON и отбрасывает мусор', () => {
    expect(parseLock('{"tab":"x","ts":5}')).toEqual({ tab: 'x', ts: 5 })
    expect(parseLock('не json')).toBeNull()
    expect(parseLock('{"tab":1}')).toBeNull()
    expect(parseLock(null)).toBeNull()
  })
})
