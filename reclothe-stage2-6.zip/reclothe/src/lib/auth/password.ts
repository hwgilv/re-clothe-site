/**
 * Мастер-пароль администратора. Хранится в localStorage НАВСЕГДА (отдельным ключом —
 * сброс демо-данных его не трогает). В localStorage лежит не сам пароль, а соль и хэш.
 *
 * ВАЖНО: это защита уровня «чужой не зайдёт по ошибке», а не настоящая безопасность:
 * всё, что хранится в браузере, может быть прочитано или стёрто его владельцем.
 * Настоящая авторизация (сервер, сессии, роли) появится вместе с базой данных.
 */

export const PASSWORD_STORAGE_KEY = 'reclothe.admin.pw.v1'

export const MIN_PASSWORD_LENGTH = 3

interface StoredPassword {
  v: 1
  alg: 'pbkdf2-sha256' | 'fnv1a'
  salt: string
  hash: string
}

const PBKDF2_ITERATIONS = 100_000

function toHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('')
}

function randomSalt(): string {
  const bytes = new Uint8Array(16)
  if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
    crypto.getRandomValues(bytes)
  } else {
    for (let index = 0; index < bytes.length; index += 1) bytes[index] = Math.floor(Math.random() * 256)
  }
  return toHex(bytes)
}

/** Запасной хэш для небезопасных контекстов (http не на localhost), где нет crypto.subtle. */
function fnv1a(text: string): string {
  let hash = 0x811c9dc5
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index)
    hash = Math.imul(hash, 0x01000193) >>> 0
  }
  return hash.toString(16).padStart(8, '0')
}

async function hashPassword(
  password: string,
  salt: string,
  alg: StoredPassword['alg'],
): Promise<string> {
  if (alg === 'fnv1a') return fnv1a(`${salt}:${password}`)
  const encoder = new TextEncoder()
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, [
    'deriveBits',
  ])
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', hash: 'SHA-256', salt: encoder.encode(salt), iterations: PBKDF2_ITERATIONS },
    key,
    256,
  )
  return toHex(new Uint8Array(bits))
}

function hasSubtle(): boolean {
  return typeof crypto !== 'undefined' && typeof crypto.subtle !== 'undefined'
}

function readStored(): StoredPassword | null {
  try {
    const raw = window.localStorage.getItem(PASSWORD_STORAGE_KEY)
    if (!raw) return null
    const data = JSON.parse(raw) as Partial<StoredPassword>
    if (data.v !== 1 || typeof data.salt !== 'string' || typeof data.hash !== 'string') return null
    if (data.alg !== 'pbkdf2-sha256' && data.alg !== 'fnv1a') return null
    return { v: 1, alg: data.alg, salt: data.salt, hash: data.hash }
  } catch {
    return null
  }
}

export function hasAdminPassword(): boolean {
  return readStored() !== null
}

/** Сохраняет пароль. Возвращает false, если браузер не дал записать. */
export async function setAdminPassword(password: string): Promise<boolean> {
  const alg: StoredPassword['alg'] = hasSubtle() ? 'pbkdf2-sha256' : 'fnv1a'
  const salt = randomSalt()
  const hash = await hashPassword(password, salt, alg)
  try {
    window.localStorage.setItem(
      PASSWORD_STORAGE_KEY,
      JSON.stringify({ v: 1, alg, salt, hash } satisfies StoredPassword),
    )
    return readStored() !== null
  } catch {
    return false
  }
}

export async function verifyAdminPassword(password: string): Promise<boolean> {
  const stored = readStored()
  if (!stored) return false
  // Хэш, созданный через subtle, на устройстве без subtle проверить нельзя.
  if (stored.alg === 'pbkdf2-sha256' && !hasSubtle()) return false
  const hash = await hashPassword(password, stored.salt, stored.alg)
  return constantTimeEqual(hash, stored.hash)
}

function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false
  let diff = 0
  for (let index = 0; index < a.length; index += 1) diff |= a.charCodeAt(index) ^ b.charCodeAt(index)
  return diff === 0
}
