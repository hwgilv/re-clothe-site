import { describe, expect, it } from 'vitest'

import {
  formatDate,
  formatMonthYear,
  formatNumber,
  formatPercent,
  formatRub,
  formatRubCompact,
  formatSignedPercent,
  formatTimeAgo,
} from './format'

/** Intl вставляет неразрывные пробелы — приводим к обычным, чтобы сравнение было читаемым. */
const normalize = (value: string) => value.replace(/\s/g, ' ')

describe('formatRub', () => {
  it('форматирует рубли без копеек', () => {
    expect(normalize(formatRub(245_000))).toBe('245 000 ₽')
    expect(normalize(formatRub(8283.33))).toBe('8 283 ₽')
  })
})

describe('formatNumber', () => {
  it('использует запятую как десятичный разделитель', () => {
    expect(normalize(formatNumber(1283.5, 1))).toBe('1 283,5')
  })
})

describe('formatPercent', () => {
  it('принимает долю, а не проценты', () => {
    expect(normalize(formatPercent(0.724, 1))).toBe('72,4 %')
    expect(normalize(formatPercent(0.83))).toBe('83 %')
  })
})

describe('formatSignedPercent', () => {
  it('ставит знак у ненулевых значений', () => {
    expect(normalize(formatSignedPercent(0.12))).toBe('+12 %')
    expect(formatSignedPercent(-0.05).replace('−', '-')).toMatch(/^-5\s%$/)
  })

  it('ноль — без знака', () => {
    expect(normalize(formatSignedPercent(0))).toBe('0 %')
  })
})

describe('formatRubCompact', () => {
  it('сокращает тысячи и миллионы для оси графика', () => {
    expect(normalize(formatRubCompact(150_000))).toBe('150 тыс. ₽')
    expect(normalize(formatRubCompact(1_200_000))).toBe('1,2 млн ₽')
  })
})

describe('formatMonthYear', () => {
  it('название месяца и год', () => {
    expect(formatMonthYear(new Date(Date.UTC(2026, 9, 1)))).toContain('октябрь 2026')
  })
})

describe('formatDate', () => {
  it('использует часовой пояс студии', () => {
    // 20:00 UTC — в Новокузнецке уже следующий день
    expect(formatDate(new Date('2026-10-17T20:00:00Z'))).toBe('18.10.2026')
  })
})

describe('formatTimeAgo', () => {
  const now = new Date('2026-10-17T12:00:00Z')

  it('«только что» для менее чем 45 секунд', () => {
    expect(formatTimeAgo(new Date(now.getTime() - 10_000), now)).toBe('только что')
  })

  it('часы и сутки', () => {
    expect(formatTimeAgo(new Date(now.getTime() - 2 * 3_600_000), now)).toBe('2 часа назад')
    expect(formatTimeAgo(new Date(now.getTime() - 26 * 3_600_000), now)).toBe('вчера')
  })
})
