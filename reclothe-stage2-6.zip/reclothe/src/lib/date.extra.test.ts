import { describe, expect, it } from 'vitest'

import {
  addDaysToDateString,
  addMonthsToKey,
  daysBetweenDateStrings,
  formatDateString,
  formatMonthKey,
  isDateString,
  monthKey,
  toDateString,
} from '@/lib/date'

describe('строки дат', () => {
  it('дата в поясе студии (UTC+7), а не UTC', () => {
    expect(toDateString(new Date('2026-10-17T20:30:00Z'))).toBe('2026-10-18')
    expect(toDateString(new Date('2026-10-17T10:00:00Z'))).toBe('2026-10-17')
  })
  it('сложение суток через границы месяца и года', () => {
    expect(addDaysToDateString('2026-10-31', 1)).toBe('2026-11-01')
    expect(addDaysToDateString('2026-12-31', 1)).toBe('2027-01-01')
    expect(addDaysToDateString('2026-03-01', -1)).toBe('2026-02-28')
  })
  it('разница в сутках', () => {
    expect(daysBetweenDateStrings('2026-10-18', '2026-10-20')).toBe(2)
    expect(daysBetweenDateStrings('2026-10-20', '2026-10-18')).toBe(-2)
  })
  it('формат и проверка', () => {
    expect(formatDateString('2026-10-18')).toBe('18.10.2026')
    expect(isDateString('2026-10-18')).toBe(true)
    expect(isDateString('18.10.2026')).toBe(false)
    expect(() => addDaysToDateString('мусор', 1)).toThrow(RangeError)
  })
})

describe('ключи месяцев', () => {
  it('monthKey для строки и ISO', () => {
    expect(monthKey('2026-10-18')).toBe('2026-10')
    expect(monthKey('2026-09-30T20:00:00Z')).toBe('2026-10')
  })
  it('сдвиг через год', () => {
    expect(addMonthsToKey('2026-01', -1)).toBe('2025-12')
    expect(addMonthsToKey('2026-11', 3)).toBe('2027-02')
  })
  it('подпись месяца', () => {
    expect(formatMonthKey('2026-10', 'long')).toContain('октябр')
  })
})
