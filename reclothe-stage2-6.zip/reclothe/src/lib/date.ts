import { STUDIO_TIME_ZONE } from '@/config/app'

const MS_PER_DAY = 86_400_000

export interface ZonedDateParts {
  year: number
  /** 1–12 */
  month: number
  day: number
}

/** Календарная дата (год/месяц/день) момента времени в заданном часовом поясе. */
export function getZonedDateParts(date: Date, timeZone: string = STUDIO_TIME_ZONE): ZonedDateParts {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone,
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  }).formatToParts(date)

  const read = (type: 'year' | 'month' | 'day'): number => {
    const value = Number(parts.find((part) => part.type === type)?.value)
    if (!Number.isFinite(value)) {
      throw new RangeError(`Не удалось получить "${type}" для даты ${date.toISOString()}`)
    }
    return value
  }

  return { year: read('year'), month: read('month'), day: read('day') }
}

/**
 * Сколько календарных суток от `from` до `to` в часовом поясе `timeZone`.
 * Положительное — `to` позже; 0 — тот же календарный день; отрицательное — раньше.
 * Время суток не учитывается: 23:59 и 00:01 следующего дня — это 1 день.
 */
export function calendarDaysBetween(
  from: Date,
  to: Date,
  timeZone: string = STUDIO_TIME_ZONE,
): number {
  const a = getZonedDateParts(from, timeZone)
  const b = getZonedDateParts(to, timeZone)
  const utcA = Date.UTC(a.year, a.month - 1, a.day)
  const utcB = Date.UTC(b.year, b.month - 1, b.day)
  return Math.round((utcB - utcA) / MS_PER_DAY)
}

/** Прибавляет n суток (по 24 ч). Для пояса студии без перехода на летнее время это корректно. */
export function addDays(date: Date, days: number): Date {
  return new Date(date.getTime() + days * MS_PER_DAY)
}

/* ------------------------------------------------------------------ строки дат */

/**
 * Календарные даты в приложении хранятся строками «YYYY-MM-DD» в поясе студии:
 * так дедлайн не «плывёт» на сутки при смене часового пояса устройства.
 */
export type DateString = string

const DATE_STRING_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/

function pad(value: number): string {
  return String(value).padStart(2, '0')
}

/** Дата момента времени в поясе студии: «2026-10-18». */
export function toDateString(date: Date, timeZone: string = STUDIO_TIME_ZONE): DateString {
  const { year, month, day } = getZonedDateParts(date, timeZone)
  return `${year}-${pad(month)}-${pad(day)}`
}

function parseDateString(value: DateString): number {
  const match = DATE_STRING_PATTERN.exec(value)
  if (!match) throw new RangeError(`Ожидалась дата в формате YYYY-MM-DD, получено: ${value}`)
  return Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]))
}

export function isDateString(value: string): boolean {
  return DATE_STRING_PATTERN.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`))
}

/** Прибавляет n календарных суток к «YYYY-MM-DD». */
export function addDaysToDateString(value: DateString, days: number): DateString {
  const next = new Date(parseDateString(value) + days * MS_PER_DAY)
  return `${next.getUTCFullYear()}-${pad(next.getUTCMonth() + 1)}-${pad(next.getUTCDate())}`
}

/** Сколько суток от `from` до `to` (положительное — `to` позже). */
export function daysBetweenDateStrings(from: DateString, to: DateString): number {
  return Math.round((parseDateString(to) - parseDateString(from)) / MS_PER_DAY)
}

/** «2026-10-18» → «18.10.2026». */
export function formatDateString(value: DateString): string {
  const match = DATE_STRING_PATTERN.exec(value)
  if (!match) return value
  return `${match[3]}.${match[2]}.${match[1]}`
}

/** «2026-10» из любой даты/момента ISO — ключ месяца для группировки. */
export function monthKey(value: string, timeZone: string = STUDIO_TIME_ZONE): string {
  const date = DATE_STRING_PATTERN.test(value) ? new Date(`${value}T12:00:00Z`) : new Date(value)
  const { year, month } = getZonedDateParts(date, timeZone)
  return `${year}-${pad(month)}`
}

/** Ключ месяца, смещённый на n месяцев: addMonthsToKey('2026-10', -1) → '2026-09'. */
export function addMonthsToKey(key: string, months: number): string {
  const [yearText, monthText] = key.split('-')
  const index = Number(yearText) * 12 + (Number(monthText) - 1) + months
  return `${Math.floor(index / 12)}-${pad((index % 12) + 1)}`
}

/** «окт. 2026» по ключу месяца. */
export function formatMonthKey(key: string, style: 'short' | 'long' = 'short'): string {
  const [yearText, monthText] = key.split('-')
  const date = new Date(Date.UTC(Number(yearText), Number(monthText) - 1, 1))
  return new Intl.DateTimeFormat('ru-RU', {
    month: style === 'long' ? 'long' : 'short',
    year: 'numeric',
    timeZone: 'UTC',
  })
    .format(date)
    .replace(' г.', '')
}
