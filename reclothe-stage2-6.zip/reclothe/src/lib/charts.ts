/** Вспомогательные расчёты для графиков: «красивая» шкала и сокращённые подписи. */

export interface NiceScale {
  min: number
  max: number
  ticks: number[]
}

/** Шаг из ряда 1·2·5·10^n — так оси получаются «круглыми». */
function niceStep(rough: number): number {
  if (rough <= 0) return 1
  const power = 10 ** Math.floor(Math.log10(rough))
  const fraction = rough / power
  const nice = fraction <= 1 ? 1 : fraction <= 2 ? 2 : fraction <= 5 ? 5 : 10
  return nice * power
}

/** Шкала, включающая 0 и все значения; 4–6 отметок. */
export function niceScale(values: readonly number[], targetTicks = 4): NiceScale {
  const lo = Math.min(0, ...values)
  const hi = Math.max(0, ...values)
  if (hi === lo) return { min: 0, max: 1, ticks: [0, 1] }
  const step = niceStep((hi - lo) / targetTicks)
  const min = Math.floor(lo / step) * step
  const max = Math.ceil(hi / step) * step
  const ticks: number[] = []
  for (let value = min; value <= max + step / 2; value += step) ticks.push(Math.round(value * 100) / 100)
  return { min, max, ticks }
}

/** 0 / 15 тыс. / 1,2 млн — компактная подпись оси, без знака валюты. */
export function formatAxisValue(value: number): string {
  const abs = Math.abs(value)
  const sign = value < 0 ? '−' : ''
  if (abs >= 1_000_000) return `${sign}${(abs / 1_000_000).toLocaleString('ru-RU', { maximumFractionDigits: 1 })} млн`
  if (abs >= 1_000) return `${sign}${(abs / 1_000).toLocaleString('ru-RU', { maximumFractionDigits: 1 })} тыс.`
  return `${sign}${abs.toLocaleString('ru-RU')}`
}
