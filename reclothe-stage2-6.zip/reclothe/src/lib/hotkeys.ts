/**
 * Буква из физического кода клавиши: «KeyG» → «g», остальное → null.
 * Используем event.code, а не event.key: при русской раскладке key даёт «п»,
 * а горячие клавиши должны работать независимо от раскладки.
 */
export function keyLetterFromCode(code: string): string | null {
  const match = /^Key([A-Z])$/.exec(code)
  return match?.[1] ? match[1].toLowerCase() : null
}

/** Фокус в поле ввода — горячие клавиши без модификатора не должны срабатывать. */
export function isEditableTarget(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false
  if (target.isContentEditable) return true
  return target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT'
}
