import { z } from 'zod'

import { isValidEmail, isValidPhone } from '@/lib/domain/client'

/** Форма входа клиента (модуль 1): ФИО, телефон, e-mail, способ связи. */
export const clientFormSchema = z.object({
  lastName: z
    .string()
    .trim()
    .min(2, 'Введите фамилию')
    .max(60, 'Слишком длинно')
    .regex(/^[\p{L}\s'’-]+$/u, 'Только буквы'),
  firstName: z
    .string()
    .trim()
    .min(2, 'Введите имя')
    .max(60, 'Слишком длинно')
    .regex(/^[\p{L}\s'’-]+$/u, 'Только буквы'),
  middleName: z
    .string()
    .trim()
    .max(60, 'Слишком длинно')
    .regex(/^[\p{L}\s'’-]*$/u, 'Только буквы'),
  phone: z.string().trim().refine(isValidPhone, 'Введите номер в формате +7 900 000-00-00'),
  email: z.string().trim().refine(isValidEmail, 'Введите корректный e-mail'),
  contact: z.enum(['telegram', 'vk', 'whatsapp', 'call']),
})

export type ClientFormValues = z.infer<typeof clientFormSchema>

export type ClientFormErrors = Partial<Record<keyof ClientFormValues, string>>

/** Возвращает либо проверенные значения, либо ошибки по полям. */
export function validateClientForm(
  values: Record<keyof ClientFormValues, string>,
): { ok: true; values: ClientFormValues } | { ok: false; errors: ClientFormErrors } {
  const result = clientFormSchema.safeParse(values)
  if (result.success) return { ok: true, values: result.data }
  const errors: ClientFormErrors = {}
  for (const issue of result.error.issues) {
    const key = issue.path[0]
    if (typeof key === 'string' && !(key in errors)) {
      errors[key as keyof ClientFormValues] = issue.message
    }
  }
  return { ok: false, errors }
}
