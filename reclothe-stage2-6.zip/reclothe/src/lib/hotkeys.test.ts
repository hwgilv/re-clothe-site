import { describe, expect, it } from 'vitest'

import { keyLetterFromCode } from './hotkeys'

describe('keyLetterFromCode', () => {
  it('достаёт букву из кода клавиши независимо от раскладки', () => {
    expect(keyLetterFromCode('KeyG')).toBe('g')
    expect(keyLetterFromCode('KeyK')).toBe('k')
  })

  it('не-буквенные клавиши дают null', () => {
    expect(keyLetterFromCode('Escape')).toBeNull()
    expect(keyLetterFromCode('Digit1')).toBeNull()
    expect(keyLetterFromCode('')).toBeNull()
  })
})
