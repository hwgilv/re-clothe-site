import { FINAL_STAGE, STAGES } from '@/lib/domain/catalog'
import type { StageInfo } from '@/lib/domain/catalog'

const TOTAL_WEIGHT = STAGES.reduce((total, stage) => total + stage.weight, 0)

export function getStage(n: number): StageInfo {
  const stage = STAGES.find((item) => item.n === n)
  if (!stage) throw new RangeError(`Нет этапа №${n}`)
  return stage
}

export function clampStage(n: number): number {
  if (!Number.isFinite(n)) return 1
  return Math.min(FINAL_STAGE, Math.max(1, Math.round(n)))
}

export function clampPercent(value: number): number {
  if (!Number.isFinite(value)) return 0
  return Math.min(100, Math.max(0, Math.round(value)))
}

/**
 * Процент готовности заказа: завершённые этапы (по весу в часах) плюс доля текущего.
 * Последний этап — «Готово» — это 100%.
 */
export function orderProgress(stage: number, stageProgress: number): number {
  const current = clampStage(stage)
  if (current === FINAL_STAGE) return 100

  const done = STAGES.filter((item) => item.n < current).reduce(
    (total, item) => total + item.weight,
    0,
  )
  const inCurrent = (getStage(current).weight * clampPercent(stageProgress)) / 100
  return Math.round(((done + inCurrent) / TOTAL_WEIGHT) * 100)
}
