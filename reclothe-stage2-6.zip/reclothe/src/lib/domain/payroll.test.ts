import { describe, expect, it } from 'vitest'

import { calcOrderPayroll, toggleAdjustment } from '@/lib/domain/payroll'
import type { Adjustment } from '@/lib/domain/types'

function adj(code: string, extra: Partial<Adjustment> = {}): Adjustment {
  return {
    id: `a-${code}`,
    kind: code.startsWith('b-') ? 'bonus' : 'penalty',
    code,
    qty: 1,
    customAmount: null,
    at: '2026-10-18T00:00:00Z',
    ...extra,
  }
}

describe('calcOrderPayroll', () => {
  it('без позиций — только база', () => {
    const result = calcOrderPayroll(6048, [])
    expect(result.total).toBe(6048)
    expect(result.bonusTotal).toBe(0)
  })

  it('пример акта из 7.9: досрочно (+10%) от 6 048 = 605 ₽', () => {
    const result = calcOrderPayroll(6048, [adj('b-early-1')])
    expect(result.bonusTotal).toBe(605)
    expect(result.total).toBe(6653)
  })

  it('пример акта из 7.9: замечания ОТК (−5%) от 2 640 = 132 ₽', () => {
    const result = calcOrderPayroll(2640, [adj('p-otk-2')])
    expect(result.penaltyTotal).toBe(132)
    expect(result.total).toBe(2508)
  })

  it('фиксированные и «за единицу» позиции', () => {
    const result = calcOrderPayroll(1000, [
      adj('b-week-5'),
      adj('b-month-10'),
      adj('b-mentor', { qty: 2 }),
      adj('p-late-fitting'),
      adj('p-safety'),
    ])
    expect(result.bonusTotal).toBe(500 + 1000 + 600)
    expect(result.penaltyTotal).toBe(200 + 500)
  })

  it('произвольная сумма ограничивается пределами (новая техника 500–2 000)', () => {
    expect(calcOrderPayroll(0, [adj('b-innovation', { customAmount: 9_999 })]).bonusTotal).toBe(2000)
    expect(calcOrderPayroll(0, [adj('b-innovation', { customAmount: 100 })]).bonusTotal).toBe(500)
    expect(calcOrderPayroll(0, [adj('b-innovation', { customAmount: 1200 })]).bonusTotal).toBe(1200)
  })

  it('крупный брак: −100% оплаты плюс возмещение материалов', () => {
    const result = calcOrderPayroll(5000, [adj('p-major-defect'), adj('p-materials', { customAmount: 3000 })])
    expect(result.penaltyTotal).toBe(8000)
    expect(result.total).toBe(-3000)
  })

  it('«расторжение договора» — запись без денежной суммы', () => {
    const result = calcOrderPayroll(5000, [adj('p-systematic')])
    expect(result.penalties).toHaveLength(1)
    expect(result.penaltyTotal).toBe(0)
  })

  it('неизвестные коды игнорируются', () => {
    expect(calcOrderPayroll(100, [adj('b-unknown')]).total).toBe(100)
  })
})

describe('toggleAdjustment', () => {
  it('повторное нажатие снимает позицию', () => {
    const once = toggleAdjustment([], adj('b-otk'))
    expect(once).toHaveLength(1)
    expect(toggleAdjustment(once, adj('b-otk'))).toHaveLength(0)
  })

  it('взаимоисключающие позиции заменяют друг друга (просрочка 1 день → 4+ дня)', () => {
    const first = toggleAdjustment([], adj('p-late-1'))
    const second = toggleAdjustment(first, adj('p-late-4'))
    expect(second.map((item) => item.code)).toEqual(['p-late-4'])
  })

  it('независимые позиции складываются, а бонус и штраф из одной группы не конфликтуют', () => {
    let list = toggleAdjustment([], adj('b-otk'))
    list = toggleAdjustment(list, adj('p-otk-2'))
    list = toggleAdjustment(list, adj('b-review'))
    expect(list.map((item) => item.code)).toEqual(['b-otk', 'p-otk-2', 'b-review'])
  })

  it('позиция с количеством обновляется, а не снимается', () => {
    const first = toggleAdjustment([], adj('b-mentor', { qty: 1 }))
    const second = toggleAdjustment(first, adj('b-mentor', { qty: 3 }))
    expect(second).toHaveLength(1)
    expect(second[0]?.qty).toBe(3)
  })
})
