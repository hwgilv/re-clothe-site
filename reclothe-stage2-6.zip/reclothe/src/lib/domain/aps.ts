import { APS_OVERLOAD_THRESHOLD, APS_SHIFT_DAYS } from '@/lib/domain/catalog'
import type { Order } from '@/lib/domain/types'
import { addDaysToDateString, type DateString } from '@/lib/date'

/**
 * APS — планирование по загрузке мастера.
 * Загрузка = число активных задач мастера / его ёмкость (сколько задач он ведёт одновременно).
 * Если после добавления заказа загрузка выше 80%, срок сдвигается на +14 дней.
 */

export function isActiveOrder(order: Pick<Order, 'state' | 'completedAt'>): boolean {
  return order.state === 'active' && order.completedAt === null
}

export function countActiveTasks(
  masterId: string,
  orders: readonly Order[],
  excludeOrderId?: string,
): number {
  return orders.filter(
    (order) => order.masterId === masterId && order.id !== excludeOrderId && isActiveOrder(order),
  ).length
}

export function loadPercent(activeTasks: number, capacity: number): number {
  if (capacity <= 0) return activeTasks > 0 ? 100 : 0
  return Math.round((activeTasks / capacity) * 100)
}

export interface LoadAssessment {
  activeTasks: number
  /** Текущая загрузка без нового заказа. */
  currentLoad: number
  /** Загрузка после добавления заказа. */
  projectedLoad: number
  overloaded: boolean
  shiftDays: number
}

export function assessLoad(params: {
  masterId: string
  capacity: number
  orders: readonly Order[]
  /** При редактировании заказ уже учтён в загрузке — его нужно исключить. */
  excludeOrderId?: string
}): LoadAssessment {
  const activeTasks = countActiveTasks(params.masterId, params.orders, params.excludeOrderId)
  const projectedLoad = loadPercent(activeTasks + 1, params.capacity)
  const overloaded = projectedLoad > APS_OVERLOAD_THRESHOLD
  return {
    activeTasks,
    currentLoad: loadPercent(activeTasks, params.capacity),
    projectedLoad,
    overloaded,
    shiftDays: overloaded ? APS_SHIFT_DAYS : 0,
  }
}

export function applyShift(requested: DateString, shiftDays: number): DateString {
  return addDaysToDateString(requested, shiftDays)
}

/** Предлагаемый срок: рабочие часы заказа при 6 продуктивных часах в день + 5 дней на примерки и выдачу. */
export function suggestDeadline(today: DateString, hours: number, kComplexity: number): DateString {
  const workDays = Math.ceil((hours * Math.max(1, kComplexity)) / 6)
  return addDaysToDateString(today, workDays + 5)
}
