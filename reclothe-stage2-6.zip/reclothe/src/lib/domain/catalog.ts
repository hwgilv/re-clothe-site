import type {
  CategoryId,
  ComplexityId,
  LoyaltyTierId,
  MaterialId,
  MessengerId,
  Service,
  UrgencyId,
} from '@/lib/domain/types'

/**
 * Справочники студии. Источник — бизнес-план «Апсайклинг» (раздел 7) и ТЗ.
 * Это ТАРИФЫ и ПРАВИЛА, а не показатели: цифры отчётов считаются из состояния, а не берутся отсюда.
 */

/* ------------------------------------------------------------------ мастера */

export const MASTER_IDS = {
  timofey: 'm-timofey',
  roman: 'm-roman',
  artem: 'm-artem',
} as const

/* --------------------------------------------------------------- категории */

export interface CategoryInfo {
  id: CategoryId
  title: string
  defaultMasterId: string
}

export const CATEGORIES: readonly CategoryInfo[] = [
  { id: 'outerwear', title: 'Верхняя одежда', defaultMasterId: MASTER_IDS.timofey },
  { id: 'midlayer', title: 'Средняя одежда', defaultMasterId: MASTER_IDS.artem },
  { id: 'light', title: 'Лёгкая одежда', defaultMasterId: MASTER_IDS.roman },
  { id: 'bottoms', title: 'Брюки и джинсы', defaultMasterId: MASTER_IDS.roman },
  { id: 'accessories', title: 'Аксессуары', defaultMasterId: MASTER_IDS.roman },
  { id: 'headwear', title: 'Головные уборы', defaultMasterId: MASTER_IDS.artem },
  { id: 'kids', title: 'Детское', defaultMasterId: MASTER_IDS.artem },
  { id: 'pets', title: 'Животные', defaultMasterId: MASTER_IDS.artem },
]

const CATEGORY_BY_ID = new Map(CATEGORIES.map((category) => [category.id, category]))

export function getCategory(id: CategoryId): CategoryInfo {
  const category = CATEGORY_BY_ID.get(id)
  if (!category) throw new RangeError(`Неизвестная категория: ${id}`)
  return category
}

/* ------------------------------------------------------------------ услуги */

/**
 * Цены для клиента в плане НЕ указаны — там только ставки мастеров (табл. 7.3).
 * Три цены заданы заказчиком (1.2 → 6500, 2.1 → 4200, 3.8 → 5500); остальные выведены
 * правилом «ставка × 2,3, округление вверх до 100 ₽», которое совпадает с двумя из трёх
 * заданных цен. Все цены редактируются в «Настройки → Тарифная сетка».
 */
export const CLIENT_PRICE_MARKUP = 2.3

type ServiceRow = readonly [
  id: string,
  name: string,
  description: string,
  masterRate: number,
  clientPrice: number,
  hoursMin: number,
  hoursMax: number,
  donorTitle: string,
  donorMaterial: MaterialId,
  donorKg: number,
]

const SERVICE_ROWS: Record<CategoryId, readonly ServiceRow[]> = {
  outerwear: [
    ['1.1', 'Куртка джинсовая простая', 'Из 2-3 пар джинсов, простой крой', 2000, 4600, 8, 10, 'Джинсы (3 пары)', 'denim', 2.1],
    ['1.2', 'Куртка джинсовая сложная (пэчворк)', 'Из 4-5 пар джинсов, асимметрия, сложные узлы', 2800, 6500, 12, 16, 'Джинсы (5 пар)', 'denim', 3.5],
    ['1.3', 'Куртка-бомбер', 'Из худи + рубашки/куртки, трикотажные манжеты', 2500, 5800, 10, 12, 'Худи + рубашка', 'knit', 1.1],
    ['1.4', 'Куртка-косуха (имитация)', 'Из денима/кожи, молнии, заклёпки', 3000, 6900, 14, 18, 'Джинсы (2 пары) + кожаные вставки', 'denim', 1.8],
    ['1.5', 'Жилет утеплённый', 'Из куртки/плаща + утеплитель', 2200, 5100, 8, 10, 'Куртка или плащ', 'synthetic', 1.4],
    ['1.6', 'Жилет джинсовый', 'Из 1-2 пар джинсов, накладные карманы', 1800, 4200, 6, 8, 'Джинсы (2 пары)', 'denim', 1.4],
    ['1.7', 'Пальто укороченное', 'Из длинного пальто, перекрой силуэта', 2600, 6000, 10, 14, 'Длинное пальто', 'mixed', 1.6],
    ['1.8', 'Пуховик (трансформация)', 'Из куртки + замена/добавление утеплителя', 3500, 8100, 16, 20, 'Куртка с утеплителем', 'synthetic', 1.3],
    ['1.9', 'Парка/анорак', 'Из плаща/куртки, добавление капюшона', 2800, 6500, 12, 16, 'Плащ или куртка', 'synthetic', 1.1],
    ['1.10', 'Куртка кожаная', 'Из кожаной куртки, перекрой', 3500, 8100, 14, 18, 'Кожаная куртка', 'leather', 1.6],
  ],
  midlayer: [
    ['2.1', 'Худи гибридный', 'Из худи + рубашки/другой ткани', 1800, 4200, 8, 10, 'Худи + рубашка', 'knit', 0.9],
    ['2.2', 'Свитшот кастомный', 'Из свитшота, вставки, карманы', 1500, 3500, 6, 8, 'Свитшот', 'knit', 0.5],
    ['2.3', 'Бомбер лёгкий', 'Из ветровки/рубашки, трикотажные детали', 2000, 4600, 8, 10, 'Ветровка или рубашка', 'synthetic', 0.5],
    ['2.4', 'Кардиган-трансформер', 'Из свитера/кардигана, перекрой', 1600, 3700, 6, 8, 'Свитер или кардиган', 'knit', 0.5],
    ['2.5', 'Толстовка с капюшоном', 'Из 2-3 худи, пэчворк', 2000, 4600, 8, 12, 'Худи (3 шт.)', 'knit', 1.8],
    ['2.6', 'Лонгслив кастомный', 'Из футболки/лонгслива, вставки', 1200, 2800, 4, 6, 'Футболка или лонгслив', 'knit', 0.25],
  ],
  light: [
    ['3.1', 'Платье из рубашек', 'Из 2-3 рубашек, сложный крой', 2000, 4600, 8, 10, 'Рубашки (3 шт.)', 'cotton', 0.75],
    ['3.2', 'Платье из джинсов', 'Из 2-3 пар джинсов, подкладка', 2200, 5100, 10, 12, 'Джинсы (2 пары)', 'denim', 1.4],
    ['3.3', 'Юбка-макси из денима', 'Из 2-3 пар джинсов, клинья', 1500, 3500, 5, 7, 'Джинсы (3 пары)', 'denim', 2.1],
    ['3.4', 'Юбка-миди', 'Из джинсов/рубашек, простой крой', 1200, 2800, 4, 6, 'Джинсы или рубашки', 'denim', 0.7],
    ['3.5', 'Юбка-мини', 'Из джинсов/ткани, простая', 1000, 2300, 3, 4, 'Джинсы', 'denim', 0.7],
    ['3.6', 'Рубашка-трансформер', 'Из 2 рубашек, гибрид', 1500, 3500, 6, 8, 'Рубашки (2 шт.)', 'cotton', 0.5],
    ['3.7', 'Топ/боди', 'Из футболки/рубашки, сложный крой', 1200, 2800, 4, 6, 'Футболка или рубашка', 'cotton', 0.25],
    ['3.8', 'Корсет', 'Из джинсов/пиджака, косточки, люверсы', 2500, 5500, 10, 14, 'Джинсы или пиджак', 'denim', 0.9],
    ['3.9', 'Комбинезон летний', 'Из рубашек/брюк, сложный крой', 2400, 5600, 10, 14, 'Рубашки или брюки', 'cotton', 1.0],
    ['3.10', 'Сарафан', 'Из платья/рубашки, перекрой', 1600, 3700, 6, 8, 'Платье или рубашка', 'cotton', 0.4],
  ],
  bottoms: [
    ['4.1', 'Джинсы-трансформеры', 'Из 2 пар джинсов, вставки, пэчворк', 2000, 4600, 8, 10, 'Джинсы (2 пары)', 'denim', 1.4],
    ['4.2', 'Брюки-карго', 'Из брюк, добавление карманов', 1800, 4200, 6, 8, 'Брюки', 'cotton', 0.7],
    ['4.3', 'Шорты из джинсов', 'Простое укорачивание + обработка', 800, 1900, 2, 3, 'Джинсы', 'denim', 0.7],
    ['4.4', 'Шорты-карго', 'Из брюк/джинсов, накладные карманы', 1200, 2800, 4, 6, 'Брюки или джинсы', 'cotton', 0.7],
    ['4.5', 'Комбинезон из брюк', 'Из 2 пар брюк, соединение', 2200, 5100, 8, 12, 'Брюки (2 пары)', 'cotton', 1.3],
    ['4.6', 'Юбка из брюк', 'Трансформация брюк в юбку', 1500, 3500, 5, 7, 'Брюки', 'cotton', 0.65],
  ],
  accessories: [
    ['5.1', 'Рюкзак городской', 'Из куртки/джинсов, подкладка, лямки', 2000, 4600, 8, 10, 'Куртка или джинсы', 'denim', 1.0],
    ['5.2', 'Сумка-мессенджер', 'Из джинсов/куртки, ремень', 1500, 3500, 5, 7, 'Джинсы или куртка', 'denim', 0.7],
    ['5.3', 'Сумка-тоут (шоппер)', 'Из джинсов/ткани, простой крой', 1000, 2300, 3, 4, 'Джинсы или ткань', 'denim', 0.5],
    ['5.4', 'Клатч', 'Из кожи/ткани, молния, подкладка', 1200, 2800, 4, 6, 'Кожа или ткань', 'leather', 0.3],
    ['5.5', 'Косметичка', 'Из остатков/ткани, молния', 800, 1900, 2, 3, 'Остатки ткани', 'cotton', 0.15],
    ['5.6', 'Пояс/ремень', 'Из джинсов/кожи, фурнитура', 600, 1400, 2, 3, 'Джинсы или кожа', 'leather', 0.3],
    ['5.7', 'Чехол для телефона', 'Из кожи/ткани, простой крой', 500, 1200, 1, 2, 'Кожа или ткань', 'leather', 0.15],
    ['5.8', 'Кошелёк', 'Из кожи/джинсов, сложный крой', 1000, 2300, 3, 5, 'Кожа или джинсы', 'leather', 0.25],
    ['5.9', 'Обложка для документов', 'Из кожи/ткани, простой крой', 400, 1000, 1, 2, 'Кожа или ткань', 'leather', 0.12],
    ['5.10', 'Сумка-пояс (бананка)', 'Из джинсов/ткани, ремень', 1200, 2800, 4, 5, 'Джинсы или ткань', 'denim', 0.35],
  ],
  headwear: [
    ['6.1', 'Панама двухсторонняя', 'Из лоскутов/ткани, подкладка', 800, 1900, 2, 3, 'Лоскуты ткани', 'cotton', 0.15],
    ['6.2', 'Бейсболка', 'Из джинсов/ткани, козырёк', 1000, 2300, 3, 4, 'Джинсы или ткань', 'denim', 0.3],
    ['6.3', 'Шапка-бини', 'Из свитера/трикотажа', 600, 1400, 2, 3, 'Свитер или трикотаж', 'knit', 0.35],
    ['6.4', 'Бандана', 'Из рубашки/ткани, простой крой', 400, 1000, 1, 2, 'Рубашка или ткань', 'cotton', 0.15],
    ['6.5', 'Кепка с ушами', 'Из куртки/ткани, утепление', 1200, 2800, 4, 5, 'Куртка или ткань', 'synthetic', 0.35],
  ],
  kids: [
    ['7.1', 'Комбинезон детский', 'Из взрослой одежды, перекрой', 1800, 4200, 6, 8, 'Взрослая одежда', 'cotton', 0.8],
    ['7.2', 'Куртка детская', 'Из взрослой куртки, уменьшение', 1600, 3700, 6, 8, 'Взрослая куртка', 'synthetic', 1.0],
    ['7.3', 'Платье детское', 'Из рубашки/платья, перекрой', 1400, 3300, 5, 7, 'Рубашка или платье', 'cotton', 0.3],
    ['7.4', 'Штаны детские', 'Из взрослых джинсов, перекрой', 1200, 2800, 4, 6, 'Взрослые джинсы', 'denim', 0.7],
    ['7.5', 'Худи детское', 'Из взрослого худи, уменьшение', 1200, 2800, 4, 5, 'Взрослое худи', 'knit', 0.6],
  ],
  pets: [
    ['8.1', 'Комбинезон для собаки', 'Из рукавов свитера/худи', 1200, 2800, 4, 6, 'Рукава свитера или худи', 'knit', 0.4],
    ['8.2', 'Свитер для собаки', 'Из свитера, перекрой', 1000, 2300, 3, 4, 'Свитер', 'knit', 0.4],
    ['8.3', 'Бандана для собаки', 'Из ткани, простая', 400, 1000, 1, 2, 'Ткань', 'cotton', 0.1],
    ['8.4', 'Лежанка для питомца', 'Из куртки/подушки, сложная', 1500, 3500, 5, 7, 'Куртка или подушка', 'synthetic', 0.9],
  ],
}

/** Сложность по умолчанию — по примерам из таблицы 7.4.1 плана. */
const DEFAULT_COMPLEXITY: Partial<Record<string, ComplexityId>> = {
  '1.2': 'high',
  '1.3': 'medium',
  '1.4': 'high',
  '1.5': 'medium',
  '1.7': 'medium',
  '1.8': 'high',
  '1.9': 'medium',
  '1.10': 'medium',
  '2.1': 'low',
  '3.8': 'high',
  '3.9': 'high',
  '5.1': 'medium',
}

export const SERVICES: readonly Service[] = (
  Object.entries(SERVICE_ROWS) as [CategoryId, readonly ServiceRow[]][]
).flatMap(([categoryId, rows]) =>
  rows.map(
    ([id, name, description, masterRate, clientPrice, hoursMin, hoursMax, title, materialId, weightKg]): Service => ({
      id,
      categoryId,
      name,
      description,
      masterRate,
      clientPrice,
      hoursMin,
      hoursMax,
      defaultMasterId: getCategory(categoryId).defaultMasterId,
      defaultComplexity: DEFAULT_COMPLEXITY[id] ?? 'base',
      donor: { title, materialId, weightKg },
    }),
  ),
)

const SERVICE_BY_ID = new Map(SERVICES.map((service) => [service.id, service]))

export function getBaseService(id: string): Service | undefined {
  return SERVICE_BY_ID.get(id)
}

/* -------------------------------------------------------- К сложности (7.4) */

export interface ComplexityLevel {
  id: ComplexityId
  label: string
  k: number
  hint: string
}

export const COMPLEXITY_LEVELS: readonly ComplexityLevel[] = [
  { id: 'base', label: 'Базовая', k: 1.0, hint: 'Простой крой, стандартные операции' },
  { id: 'low', label: 'Низкая', k: 1.2, hint: 'Несколько доп. операций, простая подкладка' },
  { id: 'medium', label: 'Средняя', k: 1.5, hint: 'Сложные узлы, подкладка, утеплитель, фурнитура' },
  { id: 'high', label: 'Высокая', k: 1.8, hint: 'Асимметричный крой, много карманов, сложная фурнитура' },
  { id: 'very-high', label: 'Очень высокая', k: 2.0, hint: 'Кожа/мех, сложные конструкции, много ручной работы' },
  { id: 'extreme', label: 'Экстремальная', k: 2.5, hint: 'Уникальные дизайнерские решения, арт-объекты' },
]

/* ------------------------------------------------------- К материала (7.5) */

export interface MaterialInfo {
  id: MaterialId
  label: string
  k: number
}

export const MATERIALS: readonly MaterialInfo[] = [
  { id: 'cotton', label: 'Хлопок / лён / вискоза', k: 1.0 },
  { id: 'denim', label: 'Деним (джинса)', k: 1.2 },
  { id: 'flannel', label: 'Фланель / вельвет', k: 1.1 },
  { id: 'knit', label: 'Трикотаж (футер, кашкорсе)', k: 1.2 },
  { id: 'synthetic', label: 'Синтетика (нейлон, полиэстер)', k: 1.1 },
  { id: 'leather', label: 'Кожа натуральная', k: 1.5 },
  { id: 'eco-leather', label: 'Эко-кожа, винил', k: 1.3 },
  { id: 'suede', label: 'Замша', k: 1.4 },
  { id: 'fur', label: 'Мех натуральный', k: 1.6 },
  { id: 'faux-fur', label: 'Мех искусственный', k: 1.3 },
  { id: 'membrane', label: 'Мембрана, технические ткани', k: 1.4 },
  { id: 'silk', label: 'Шёлк / шифон', k: 1.3 },
  { id: 'mixed', label: 'Смешанные ткани', k: 1.1 },
]

/* ----------------------------------------------- доп. операции (табл. 7.6.1) */

export type OptionUnit = 'шт.' | 'м' | 'услуга'

export interface ExtraOption {
  id: string
  group: string
  label: string
  /** Доплата за единицу, ₽. */
  price: number
  unit: OptionUnit
  /** Время на единицу, мин. */
  minutes: number
}

export const OP_GROUPS = ['Утепление', 'Фурнитура', 'Карманы', 'Декор', 'Обработка краёв'] as const

export const EXTRA_OPS: readonly ExtraOption[] = [
  { id: 'insulation', group: 'Утепление', label: 'Утепление синтепоном / холлофайбером', price: 500, unit: 'услуга', minutes: 30 },
  { id: 'fleece', group: 'Утепление', label: 'Флисовая подкладка', price: 400, unit: 'услуга', minutes: 25 },
  { id: 'liner', group: 'Утепление', label: 'Съёмная подстёжка', price: 800, unit: 'услуга', minutes: 45 },

  { id: 'eyelet', group: 'Фурнитура', label: 'Люверс', price: 50, unit: 'шт.', minutes: 5 },
  { id: 'snap', group: 'Фурнитура', label: 'Кнопка', price: 50, unit: 'шт.', minutes: 5 },
  { id: 'rivet', group: 'Фурнитура', label: 'Хольнитен / заклёпка', price: 50, unit: 'шт.', minutes: 4 },
  { id: 'pulley', group: 'Фурнитура', label: 'Блочок', price: 30, unit: 'шт.', minutes: 3 },
  { id: 'zip-regular', group: 'Фурнитура', label: 'Молния обычная', price: 300, unit: 'шт.', minutes: 20 },
  { id: 'zip-concealed', group: 'Фурнитура', label: 'Молния потайная', price: 400, unit: 'шт.', minutes: 25 },
  { id: 'zip-double', group: 'Фурнитура', label: 'Молния двухзамковая', price: 500, unit: 'шт.', minutes: 30 },

  { id: 'pocket-patch', group: 'Карманы', label: 'Накладной карман', price: 200, unit: 'шт.', minutes: 15 },
  { id: 'pocket-flap', group: 'Карманы', label: 'Карман с клапаном', price: 300, unit: 'шт.', minutes: 20 },
  { id: 'pocket-welt', group: 'Карманы', label: 'Прорезной карман с листочкой', price: 500, unit: 'шт.', minutes: 35 },
  { id: 'pocket-zip', group: 'Карманы', label: 'Прорезной карман на молнии', price: 400, unit: 'шт.', minutes: 30 },
  { id: 'pocket-inner', group: 'Карманы', label: 'Внутренний карман', price: 250, unit: 'шт.', minutes: 20 },

  { id: 'patch', group: 'Декор', label: 'Патч / шеврон', price: 100, unit: 'шт.', minutes: 10 },
  { id: 'tape', group: 'Декор', label: 'Лента / стропа (10 см)', price: 50, unit: 'шт.', minutes: 5 },
  { id: 'carabiner', group: 'Декор', label: 'Карабин / D-кольцо', price: 100, unit: 'шт.', minutes: 10 },
  { id: 'lacing', group: 'Декор', label: 'Шнуровка (люверсы + шнурок)', price: 400, unit: 'услуга', minutes: 30 },
  { id: 'fringe', group: 'Декор', label: 'Бахрома', price: 600, unit: 'услуга', minutes: 40 },

  { id: 'bias', group: 'Обработка краёв', label: 'Окантовка косой бейкой', price: 200, unit: 'м', minutes: 15 },
  { id: 'zigzag', group: 'Обработка краёв', label: 'Обработка зигзагом', price: 100, unit: 'м', minutes: 10 },
  { id: 'hidden-hem', group: 'Обработка краёв', label: 'Подгибка потайным швом', price: 150, unit: 'м', minutes: 15 },
]

/* ----------------------------------------------- Art-опции (табл. 7.6.2) */

export interface ArtOption {
  id: string
  group: string
  label: string
  price: number
  unit: OptionUnit
  minutes: number
}

export const ART_GROUPS = ['Роспись', 'Вышивка', 'Деструкция', 'Аппликация'] as const

/** Для позиций с диапазоном цен в плане взята верхняя граница — так же, как в ТЗ заказчика. */
export const ART_OPTIONS: readonly ArtOption[] = [
  { id: 'paint-simple', group: 'Роспись', label: 'Роспись простая (1 элемент)', price: 500, unit: 'услуга', minutes: 30 },
  { id: 'paint-complex', group: 'Роспись', label: 'Сложная художественная композиция', price: 3000, unit: 'услуга', minutes: 240 },
  { id: 'stencil', group: 'Роспись', label: 'Трафаретная печать (1 цвет)', price: 300, unit: 'услуга', minutes: 20 },

  { id: 'emb-simple', group: 'Вышивка', label: 'Вышивка машинная простая', price: 400, unit: 'услуга', minutes: 20 },
  { id: 'emb-complex', group: 'Вышивка', label: 'Вышивка машинная сложная', price: 1500, unit: 'услуга', minutes: 90 },
  { id: 'emb-sashiko', group: 'Вышивка', label: 'Ручная вышивка Sashiko', price: 2500, unit: 'услуга', minutes: 180 },

  { id: 'holes', group: 'Деструкция', label: 'Художественные дыры', price: 200, unit: 'шт.', minutes: 15 },
  { id: 'distress', group: 'Деструкция', label: 'Потёртости шлифовкой', price: 300, unit: 'услуга', minutes: 20 },
  { id: 'fray', group: 'Деструкция', label: 'Махрение краёв', price: 200, unit: 'услуга', minutes: 15 },
  { id: 'bleach', group: 'Деструкция', label: 'Отбеливание Bleach Art', price: 1500, unit: 'услуга', minutes: 90 },

  { id: 'applique-simple', group: 'Аппликация', label: 'Аппликация простая', price: 300, unit: 'услуга', minutes: 20 },
  { id: 'applique-layered', group: 'Аппликация', label: 'Многослойная аппликация', price: 1500, unit: 'услуга', minutes: 90 },
]

/* ---------------------------------------- спец. доплаты (табл. 7.6.3) */

export interface UrgencyInfo {
  id: UrgencyId
  label: string
  /** Доля, на которую увеличивается стоимость. */
  fraction: number
}

export const URGENCY_LEVELS: readonly UrgencyInfo[] = [
  { id: 'none', label: 'Обычный срок', fraction: 0 },
  { id: '72h', label: '72 часа · +15%', fraction: 0.15 },
  { id: '48h', label: '48 часов · +30%', fraction: 0.3 },
  { id: '24h', label: '24 часа · +50%', fraction: 0.5 },
]

export const SPECIAL_SURCHARGES = {
  corset: { label: 'Корсетные изделия (косточки)', price: 800 },
  lining: { label: 'Изделие на подкладке', price: 600 },
  handSeamsPerMeter: { label: 'Ручные швы', price: 300 },
  beads: { label: 'Отделка бисером / стразами', price: 2000 },
} as const

/* ---------------------------------------- бонусы и штрафы (табл. 7.8) */

export type AdjustmentMode =
  /** Процент от оплаты по заказу. */
  | 'percent'
  /** Фиксированная сумма. */
  | 'fixed'
  /** Сумма за единицу (час, заказ) × количество. */
  | 'per-unit'
  /** Сумма вводит администратор в заданных пределах. */
  | 'custom'
  /** Без денежной суммы — запись в журнале (например, расторжение договора). */
  | 'info'

export interface AdjustmentDef {
  code: string
  kind: 'bonus' | 'penalty'
  label: string
  mode: AdjustmentMode
  /** Процент (для percent) или рубли (для fixed / per-unit). */
  value: number
  unitLabel?: string
  customMin?: number
  customMax?: number
  /** Позиции с одним `group` взаимоисключающие: новая заменяет прежнюю. */
  group?: string
  hint: string
}

export const BONUS_DEFS: readonly AdjustmentDef[] = [
  { code: 'b-otk', kind: 'bonus', label: 'ОТК без замечаний', mode: 'percent', value: 5, group: 'otk', hint: 'Идеальное исполнение' },
  { code: 'b-review', kind: 'bonus', label: 'Отзыв клиента', mode: 'percent', value: 10, hint: 'Эмоциональный отклик клиента' },
  { code: 'b-early-1', kind: 'bonus', label: 'Досрочно на 1 день', mode: 'percent', value: 10, group: 'early', hint: 'Без потери качества' },
  { code: 'b-early-2', kind: 'bonus', label: 'Досрочно на 2+ дня', mode: 'percent', value: 15, group: 'early', hint: 'Без потери качества' },
  { code: 'b-week-5', kind: 'bonus', label: '5+ заказов в неделю', mode: 'fixed', value: 500, hint: 'Стабильная загрузка' },
  { code: 'b-month-10', kind: 'bonus', label: '10+ заказов в месяц', mode: 'fixed', value: 1000, hint: 'Высокая продуктивность' },
  { code: 'b-innovation', kind: 'bonus', label: 'Новая техника (внедрение)', mode: 'custom', value: 500, customMin: 500, customMax: 2000, hint: '500–2 000 ₽ за улучшение процесса' },
  { code: 'b-mentor', kind: 'bonus', label: 'Наставничество / обучение', mode: 'per-unit', value: 300, unitLabel: 'час', hint: '300 ₽ за час обучения других портных' },
  { code: 'b-fitting', kind: 'bonus', label: 'Участие в примерке', mode: 'fixed', value: 200, hint: 'Коммуникация с клиентом' },
  { code: 'b-repeat', kind: 'bonus', label: 'Повторный заказ клиента', mode: 'fixed', value: 300, hint: 'Лояльность клиента' },
]

export const PENALTY_DEFS: readonly AdjustmentDef[] = [
  { code: 'p-minor-defect', kind: 'penalty', label: 'Мелкий брак (исправимый)', mode: 'percent', value: 10, group: 'defect', hint: 'Переделка за счёт портного' },
  { code: 'p-major-defect', kind: 'penalty', label: 'Крупный брак (неисправимый)', mode: 'percent', value: 100, group: 'defect', hint: 'Порча давальческого сырья: −100% оплаты' },
  { code: 'p-materials', kind: 'penalty', label: 'Возмещение материалов', mode: 'custom', value: 0, customMin: 0, customMax: 100000, hint: 'Сумма возмещения при крупном браке' },
  { code: 'p-systematic', kind: 'penalty', label: 'Систематический брак (3+ раза)', mode: 'info', value: 0, hint: 'Основание для расторжения договора ГПХ' },
  { code: 'p-late-1', kind: 'penalty', label: 'Просрочка на 1 день', mode: 'percent', value: 5, group: 'late', hint: 'Нарушение обязательств' },
  { code: 'p-late-3', kind: 'penalty', label: 'Просрочка на 2–3 дня', mode: 'percent', value: 10, group: 'late', hint: 'Серьёзное нарушение' },
  { code: 'p-late-4', kind: 'penalty', label: 'Просрочка на 4+ дня', mode: 'percent', value: 20, group: 'late', hint: 'Критическое нарушение' },
  { code: 'p-otk-2', kind: 'penalty', label: 'Замечания при ОТК (1–2)', mode: 'percent', value: 5, group: 'otk', hint: 'Необходимость доработки' },
  { code: 'p-otk-3', kind: 'penalty', label: 'Замечания при ОТК (3+)', mode: 'percent', value: 15, group: 'otk', hint: 'Низкое качество работы' },
  { code: 'p-rework', kind: 'penalty', label: 'Возврат клиента на доработку', mode: 'percent', value: 10, hint: 'Потеря времени и репутации' },
  { code: 'p-late-fitting', kind: 'penalty', label: 'Опоздание на примерку/сдачу', mode: 'fixed', value: 200, hint: 'Неуважение к клиенту' },
  { code: 'p-tz', kind: 'penalty', label: 'Несоответствие ТЗ', mode: 'percent', value: 10, hint: 'Невнимательность' },
  { code: 'p-safety', kind: 'penalty', label: 'Нарушение техники безопасности', mode: 'fixed', value: 500, hint: 'Риск травматизма' },
]

const ADJUSTMENT_BY_CODE = new Map([...BONUS_DEFS, ...PENALTY_DEFS].map((def) => [def.code, def]))

export function getAdjustmentDef(code: string): AdjustmentDef | undefined {
  return ADJUSTMENT_BY_CODE.get(code)
}

/* ------------------------------------------------ этапы производства */

export interface StageInfo {
  /** Номер 1…8. */
  n: number
  title: string
  /** Вес этапа (в часах типового заказа) — из него считается процент готовности. */
  weight: number
  /** Какому этапу плана (раздел 5) соответствует. */
  planStages: string
  zone: string
}

/** Восемь этапов для клиента; сведены из десяти этапов раздела 5 плана. */
export const STAGES: readonly StageInfo[] = [
  { n: 1, title: 'Приёмка и консультация', weight: 1, planStages: '1', zone: 'Front-office' },
  { n: 2, title: 'Дефектовка и дизайн', weight: 4, planStages: '2–3', zone: 'Creative Lab' },
  { n: 3, title: 'Стирка и деконструкция', weight: 8, planStages: '5–6', zone: 'Wet Zone / Deconstruction' },
  { n: 4, title: 'Раскрой', weight: 6, planStages: '7', zone: 'Pattern & Cutting' },
  { n: 5, title: 'Пошив и сборка', weight: 14, planStages: '8', zone: 'Assembly' },
  { n: 6, title: 'ВТО', weight: 1.5, planStages: '9', zone: 'Finishing' },
  { n: 7, title: 'ОТК и упаковка', weight: 1, planStages: '10', zone: 'QC & Packaging' },
  { n: 8, title: 'Готово', weight: 1, planStages: '—', zone: 'Выдача' },
]

export const FINAL_STAGE = STAGES.length

/* ------------------------------------------------ программа лояльности */

export interface TierInfo {
  id: LoyaltyTierId
  label: string
  /** Нижняя граница суммы покупок (не включительно), ₽. */
  above: number
  /** Верхняя граница (включительно); null — без верха. */
  upTo: number | null
  /** Цвета карты: градиент и свечение. */
  from: string
  to: string
  glow: string
  text: string
}

export const LOYALTY_TIERS: readonly TierInfo[] = [
  { id: 'bronze', label: 'Бронзовая', above: -1, upTo: 10_000, from: '#8a5a3c', to: '#3b2417', glow: '#cd7f32', text: '#f1c9a5' },
  { id: 'silver', label: 'Серебряная', above: 10_000, upTo: 25_000, from: '#9aa3ad', to: '#363b42', glow: '#c7ced6', text: '#eef1f4' },
  { id: 'gold', label: 'Золотая', above: 25_000, upTo: 50_000, from: '#c9962b', to: '#4a3411', glow: '#ffc83d', text: '#ffe9b0' },
  { id: 'platinum', label: 'Платиновая', above: 50_000, upTo: 100_000, from: '#7d98b3', to: '#1f2d3d', glow: '#9fd0ff', text: '#e3f1ff' },
  { id: 'diamond', label: 'Бриллиантовая', above: 100_000, upTo: null, from: '#2fd0d9', to: '#4b2a8a', glow: '#7df3ff', text: '#e8fdff' },
]

/** 1 RE-coin начисляется за каждые 10 ₽ в чеке. */
export const RUB_PER_COIN = 10

/* --------------------------------------------------- эко-коэффициенты */

export const ECO_WATER_LITERS_PER_KG = 2700
export const ECO_CO2_KG_PER_KG = 10

/* --------------------------------------------------------- мессенджеры */

export interface MessengerInfo {
  id: MessengerId
  label: string
}

export const MESSENGERS: readonly MessengerInfo[] = [
  { id: 'telegram', label: 'Telegram' },
  { id: 'vk', label: 'VK' },
  { id: 'whatsapp', label: 'WhatsApp' },
  { id: 'call', label: 'Звонок' },
]

export function messengerLabel(id: MessengerId): string {
  return MESSENGERS.find((messenger) => messenger.id === id)?.label ?? id
}

/* ------------------------------------------------------------ расходники */

export interface StockItemInfo {
  id: string
  name: string
  unit: string
  /** Ниже этого остатка — предупреждение «пора докупить». */
  min: number
  /** Цена за единицу, ₽ (для расчёта себестоимости заказа). */
  unitCost: number
  group: 'Утеплители и ткани' | 'Фурнитура' | 'Декор и арт' | 'Прочее'
}

export const STOCK_ITEMS: readonly StockItemInfo[] = [
  { id: 'synthetic', name: 'Синтепон / холлофайбер', unit: 'м', min: 6, unitCost: 300, group: 'Утеплители и ткани' },
  { id: 'fleece', name: 'Флис (подкладка)', unit: 'м', min: 4, unitCost: 250, group: 'Утеплители и ткани' },
  { id: 'lining', name: 'Подкладочная ткань', unit: 'м', min: 4, unitCost: 180, group: 'Утеплители и ткани' },
  { id: 'bias', name: 'Косая бейка', unit: 'м', min: 10, unitCost: 25, group: 'Утеплители и ткани' },
  { id: 'zip-regular', name: 'Молнии обычные', unit: 'шт.', min: 6, unitCost: 60, group: 'Фурнитура' },
  { id: 'zip-concealed', name: 'Молнии потайные', unit: 'шт.', min: 4, unitCost: 55, group: 'Фурнитура' },
  { id: 'zip-double', name: 'Молнии двухзамковые', unit: 'шт.', min: 3, unitCost: 120, group: 'Фурнитура' },
  { id: 'eyelet', name: 'Люверсы', unit: 'шт.', min: 40, unitCost: 4, group: 'Фурнитура' },
  { id: 'snap', name: 'Кнопки', unit: 'шт.', min: 30, unitCost: 6, group: 'Фурнитура' },
  { id: 'rivet', name: 'Хольнитены / заклёпки', unit: 'шт.', min: 40, unitCost: 5, group: 'Фурнитура' },
  { id: 'pulley', name: 'Блочки', unit: 'шт.', min: 10, unitCost: 3, group: 'Фурнитура' },
  { id: 'boning', name: 'Корсетные косточки (комплект)', unit: 'шт.', min: 2, unitCost: 220, group: 'Фурнитура' },
  { id: 'patch', name: 'Патчи / шевроны', unit: 'шт.', min: 5, unitCost: 60, group: 'Декор и арт' },
  { id: 'carabiner', name: 'Карабины / D-кольца', unit: 'шт.', min: 6, unitCost: 45, group: 'Декор и арт' },
  { id: 'cord', name: 'Шнуры / шнурки', unit: 'шт.', min: 4, unitCost: 30, group: 'Декор и арт' },
  { id: 'beads', name: 'Бисер / стразы (упаковка)', unit: 'шт.', min: 2, unitCost: 250, group: 'Декор и арт' },
  { id: 'paint', name: 'Акриловая краска', unit: 'мл', min: 200, unitCost: 2, group: 'Декор и арт' },
  { id: 'bleach', name: 'Отбеливатель для Bleach Art', unit: 'мл', min: 300, unitCost: 1.5, group: 'Декор и арт' },
  { id: 'emb-thread', name: 'Нить для вышивки (моток)', unit: 'шт.', min: 8, unitCost: 35, group: 'Декор и арт' },
  { id: 'thread', name: 'Нитки (катушки)', unit: 'шт.', min: 8, unitCost: 90, group: 'Прочее' },
]

const STOCK_ITEM_BY_ID = new Map(STOCK_ITEMS.map((item) => [item.id, item]))

export function getStockItem(id: string): StockItemInfo | undefined {
  return STOCK_ITEM_BY_ID.get(id)
}

/**
 * Сколько расходника уходит на ЕДИНИЦУ каждой опции. По этой карте остатки на складе
 * автоматически уменьшаются при создании заказа с этими опциями.
 */
export const OPTION_CONSUMPTION: Readonly<Record<string, Readonly<Record<string, number>>>> = {
  // Доп. операции
  insulation: { synthetic: 2 },
  fleece: { fleece: 1.5 },
  liner: { synthetic: 1.5, lining: 1.5 },
  eyelet: { eyelet: 1 },
  snap: { snap: 1 },
  rivet: { rivet: 1 },
  pulley: { pulley: 1 },
  'zip-regular': { 'zip-regular': 1 },
  'zip-concealed': { 'zip-concealed': 1 },
  'zip-double': { 'zip-double': 1 },
  'pocket-zip': { 'zip-regular': 1 },
  patch: { patch: 1 },
  carabiner: { carabiner: 1 },
  lacing: { eyelet: 8, cord: 1 },
  bias: { bias: 1.1 },
  // Арт-опции
  'paint-simple': { paint: 20 },
  'paint-complex': { paint: 100 },
  stencil: { paint: 15 },
  'emb-simple': { 'emb-thread': 1 },
  'emb-complex': { 'emb-thread': 3 },
  'emb-sashiko': { 'emb-thread': 4 },
  bleach: { bleach: 150 },
  // Спецдоплаты
  '@corset': { boning: 1, eyelet: 10 },
  '@lining': { lining: 1.5 },
  '@beads': { beads: 1 },
}

/** Одна катушка ниток на каждые 8 часов нормы времени услуги. */
export const THREAD_HOURS_PER_SPOOL = 8

/* ------------------------------------------------------ прочие правила */

/** Загрузка мастера выше этого порога сдвигает срок. */
export const APS_OVERLOAD_THRESHOLD = 80
/** На сколько дней сдвигается срок при перегрузке. */
export const APS_SHIFT_DAYS = 14

/** Ставки налога на профессиональный доход берутся из `npd.ts`. */
export const STUDIO = {
  name: 'RE:clothe',
  owner: 'Лозовой Роман Тарасович',
  ownerShort: 'Лозовой Р.',
  city: 'Новокузнецк',
  phone: '+7 903 909 57 63',
}
