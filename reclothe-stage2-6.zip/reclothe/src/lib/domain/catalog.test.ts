import { describe, expect, it } from 'vitest'

import {
  BONUS_DEFS,
  CATEGORIES,
  COMPLEXITY_LEVELS,
  MATERIALS,
  OPTION_CONSUMPTION,
  PENALTY_DEFS,
  SERVICES,
  STAGES,
  STOCK_ITEMS,
  EXTRA_OPS,
  ART_OPTIONS,
} from '@/lib/domain/catalog'

describe('каталог услуг (раздел 7.3)', () => {
  it('56 услуг в 8 категориях', () => {
    expect(SERVICES).toHaveLength(56)
    expect(CATEGORIES).toHaveLength(8)
    for (const category of CATEGORIES) {
      expect(SERVICES.filter((service) => service.categoryId === category.id).length).toBeGreaterThan(0)
    }
  })

  it('число услуг по категориям: 10 / 6 / 10 / 6 / 10 / 5 / 5 / 4', () => {
    const counts = CATEGORIES.map(
      (category) => SERVICES.filter((service) => service.categoryId === category.id).length,
    )
    expect(counts).toEqual([10, 6, 10, 6, 10, 5, 5, 4])
  })

  it('номера уникальны, ставки и цены положительны, часы упорядочены', () => {
    const ids = new Set(SERVICES.map((service) => service.id))
    expect(ids.size).toBe(SERVICES.length)
    for (const service of SERVICES) {
      expect(service.masterRate).toBeGreaterThan(0)
      expect(service.clientPrice).toBeGreaterThan(service.masterRate)
      expect(service.hoursMin).toBeGreaterThan(0)
      expect(service.hoursMax).toBeGreaterThanOrEqual(service.hoursMin)
      expect(service.donor.weightKg).toBeGreaterThan(0)
    }
  })

  it('ставки мастеров из таблицы 7.3', () => {
    const rate = (id: string) => SERVICES.find((service) => service.id === id)?.masterRate
    expect(rate('1.2')).toBe(2800)
    expect(rate('2.1')).toBe(1800)
    expect(rate('3.8')).toBe(2500)
    expect(rate('1.8')).toBe(3500)
    expect(rate('5.9')).toBe(400)
    expect(rate('8.4')).toBe(1500)
  })

  it('мастер по умолчанию существует в справочнике специализаций', () => {
    for (const service of SERVICES) expect(service.defaultMasterId.length).toBeGreaterThan(0)
  })
})

describe('коэффициенты', () => {
  it('К сложности: 1.0 · 1.2 · 1.5 · 1.8 · 2.0 · 2.5', () => {
    expect(COMPLEXITY_LEVELS.map((level) => level.k)).toEqual([1.0, 1.2, 1.5, 1.8, 2.0, 2.5])
  })

  it('К материала по таблице 7.5.1', () => {
    const k = (id: string) => MATERIALS.find((material) => material.id === id)?.k
    expect(k('cotton')).toBe(1.0)
    expect(k('denim')).toBe(1.2)
    expect(k('flannel')).toBe(1.1)
    expect(k('knit')).toBe(1.2)
    expect(k('leather')).toBe(1.5)
    expect(k('eco-leather')).toBe(1.3)
    expect(k('fur')).toBe(1.6)
    expect(k('faux-fur')).toBe(1.3)
    expect(k('silk')).toBe(1.3)
  })
})

describe('доплаты', () => {
  it('значения из ТЗ заказчика', () => {
    const op = (id: string) => EXTRA_OPS.find((item) => item.id === id)?.price
    expect(op('insulation')).toBe(500)
    expect(op('fleece')).toBe(400)
    expect(op('liner')).toBe(800)
    expect(op('pocket-patch')).toBe(200)
    expect(op('pocket-flap')).toBe(300)
    expect(op('pocket-welt')).toBe(500)
    expect(op('pocket-zip')).toBe(400)
    expect(op('bias')).toBe(200)
    expect(op('zigzag')).toBe(100)
    const art = (id: string) => ART_OPTIONS.find((item) => item.id === id)?.price
    expect(art('paint-simple')).toBe(500)
    expect(art('paint-complex')).toBe(3000)
    expect(art('emb-simple')).toBe(400)
    expect(art('emb-complex')).toBe(1500)
    expect(art('emb-sashiko')).toBe(2500)
    expect(art('holes')).toBe(200)
    expect(art('distress')).toBe(300)
    expect(art('bleach')).toBe(1500)
    expect(art('applique-layered')).toBe(1500)
  })

  it('id опций уникальны', () => {
    const ids = [...EXTRA_OPS, ...ART_OPTIONS].map((option) => option.id)
    expect(new Set(ids).size).toBe(ids.length)
  })
})

describe('бонусы и штрафы (табл. 7.8)', () => {
  it('10 бонусов и 13 штрафных позиций, коды уникальны', () => {
    expect(BONUS_DEFS).toHaveLength(10)
    expect(PENALTY_DEFS).toHaveLength(13)
    const codes = [...BONUS_DEFS, ...PENALTY_DEFS].map((def) => def.code)
    expect(new Set(codes).size).toBe(codes.length)
  })
})

describe('этапы производства', () => {
  it('8 этапов, четвёртый — «Раскрой»', () => {
    expect(STAGES).toHaveLength(8)
    expect(STAGES[3]?.title).toBe('Раскрой')
  })
})

describe('склад', () => {
  it('карта расхода ссылается только на существующие позиции склада', () => {
    const ids = new Set(STOCK_ITEMS.map((item) => item.id))
    for (const map of Object.values(OPTION_CONSUMPTION)) {
      for (const itemId of Object.keys(map)) expect(ids.has(itemId)).toBe(true)
    }
  })
})
