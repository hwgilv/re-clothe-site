import { getAdjustmentDef } from '@/lib/domain/catalog'
import type { AdjustmentDef } from '@/lib/domain/catalog'
import type { Adjustment } from '@/lib/domain/types'

export interface AdjustmentLine {
  id: string
  code: string
  kind: 'bonus' | 'penalty'
  label: string
  /** Всегда ≥ 0; знак определяет `kind`. */
  amount: number
  /** «+10%», «300 ₽ × 2 ч» — как получена сумма. */
  basis: string
}

export function adjustmentAmount(def: AdjustmentDef, adjustment: Adjustment, orderPay: number): number {
  switch (def.mode) {
    case 'percent':
      return Math.round((Math.max(0, orderPay) * def.value) / 100)
    case 'fixed':
      return def.value
    case 'per-unit':
      return Math.round(def.value * Math.max(0, adjustment.qty))
    case 'custom': {
      const raw = adjustment.customAmount ?? def.value
      const min = def.customMin ?? 0
      const max = def.customMax ?? Number.POSITIVE_INFINITY
      return Math.round(Math.min(max, Math.max(min, Number.isFinite(raw) ? raw : 0)))
    }
    case 'info':
      return 0
  }
}

function basisText(def: AdjustmentDef, adjustment: Adjustment): string {
  switch (def.mode) {
    case 'percent':
      return `${def.value}% от оплаты`
    case 'fixed':
      return 'фиксированная сумма'
    case 'per-unit':
      return `${def.value} ₽ × ${adjustment.qty} ${def.unitLabel ?? 'ед.'}`
    case 'custom':
      return 'произвольная сумма'
    case 'info':
      return 'без удержания'
  }
}

export interface OrderPayroll {
  /** Оплата по заказу до бонусов и штрафов. */
  base: number
  bonuses: AdjustmentLine[]
  penalties: AdjustmentLine[]
  bonusTotal: number
  penaltyTotal: number
  /** База + бонусы − штрафы. Может быть отрицательной при крупном браке с возмещением. */
  total: number
}

/** ЗП мастера по одному заказу: пересчитывается при каждом нажатии бонуса/штрафа. */
export function calcOrderPayroll(orderPay: number, adjustments: readonly Adjustment[]): OrderPayroll {
  const bonuses: AdjustmentLine[] = []
  const penalties: AdjustmentLine[] = []

  for (const adjustment of adjustments) {
    const def = getAdjustmentDef(adjustment.code)
    if (!def) continue
    const line: AdjustmentLine = {
      id: adjustment.id,
      code: adjustment.code,
      kind: def.kind,
      label: def.label,
      amount: adjustmentAmount(def, adjustment, orderPay),
      basis: basisText(def, adjustment),
    }
    if (def.kind === 'bonus') bonuses.push(line)
    else penalties.push(line)
  }

  const bonusTotal = bonuses.reduce((total, line) => total + line.amount, 0)
  const penaltyTotal = penalties.reduce((total, line) => total + line.amount, 0)
  return {
    base: orderPay,
    bonuses,
    penalties,
    bonusTotal,
    penaltyTotal,
    total: orderPay + bonusTotal - penaltyTotal,
  }
}

/**
 * Список позиций после нажатия кнопки: позиция из той же взаимоисключающей группы
 * заменяется, повторное нажатие на ту же позицию — снимает её (если она без количества).
 */
export function toggleAdjustment(
  current: readonly Adjustment[],
  next: Adjustment,
): Adjustment[] {
  const def = getAdjustmentDef(next.code)
  if (!def) return [...current]

  const sameCode = current.find((item) => item.code === next.code)
  const withoutConflicts = current.filter((item) => {
    if (item.code === next.code) return false
    if (!def.group) return true
    const other = getAdjustmentDef(item.code)
    return !(other && other.kind === def.kind && other.group === def.group)
  })

  const isToggle = def.mode === 'percent' || def.mode === 'fixed' || def.mode === 'info'
  if (sameCode && isToggle) return withoutConflicts
  return [...withoutConflicts, next]
}
