import { describe, expect, it } from 'vitest'

import {
  formatPhone,
  fullName,
  initialsOf,
  isValidEmail,
  isValidPhone,
  phoneDigits,
  shortName,
} from '@/lib/domain/client'

describe('имена', () => {
  const client = { lastName: 'Иванова', firstName: 'Мария', middleName: 'Петровна' }
  it('полное и краткое имя', () => {
    expect(fullName(client)).toBe('Иванова Мария Петровна')
    expect(shortName(client)).toBe('Иванова М. П.')
    expect(fullName({ ...client, middleName: '' })).toBe('Иванова Мария')
    expect(initialsOf('Иванова Мария')).toBe('ИМ')
  })
})

describe('телефон и email', () => {
  it('приводит к 7XXXXXXXXXX', () => {
    expect(phoneDigits('8 (913) 000-00-01')).toBe('79130000001')
    expect(phoneDigits('+7 913 000 00 01')).toBe('79130000001')
    expect(phoneDigits('9130000001')).toBe('79130000001')
  })
  it('проверка и форматирование', () => {
    expect(isValidPhone('+7 913 000-00-01')).toBe(true)
    expect(isValidPhone('12345')).toBe(false)
    expect(formatPhone('89039095763')).toBe('+7 903 909-57-63')
    expect(formatPhone('123')).toBe('123')
  })
  it('email', () => {
    expect(isValidEmail('a@b.ru')).toBe(true)
    expect(isValidEmail('a@b')).toBe(false)
    expect(isValidEmail('без собаки')).toBe(false)
  })
})
