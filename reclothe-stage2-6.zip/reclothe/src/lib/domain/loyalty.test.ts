import { describe, expect, it } from 'vitest'

import { coinsForSpend, getTier, tierForSpend, tierProgress } from '@/lib/domain/loyalty'

describe('tierForSpend — границы статусов карты', () => {
  it('Бронзовая ≤ 10 000', () => {
    expect(tierForSpend(0).id).toBe('bronze')
    expect(tierForSpend(10_000).id).toBe('bronze')
  })
  it('Серебряная 10 001–25 000', () => {
    expect(tierForSpend(10_001).id).toBe('silver')
    expect(tierForSpend(25_000).id).toBe('silver')
  })
  it('Золотая 25 001–50 000', () => {
    expect(tierForSpend(25_001).id).toBe('gold')
    expect(tierForSpend(50_000).id).toBe('gold')
  })
  it('Платиновая 50 001–100 000', () => {
    expect(tierForSpend(50_001).id).toBe('platinum')
    expect(tierForSpend(100_000).id).toBe('platinum')
  })
  it('Бриллиантовая > 100 000', () => {
    expect(tierForSpend(100_001).id).toBe('diamond')
    expect(tierForSpend(5_000_000).id).toBe('diamond')
  })
  it('мусорные значения считаются нулём', () => {
    expect(tierForSpend(Number.NaN).id).toBe('bronze')
    expect(tierForSpend(-50).id).toBe('bronze')
  })
})

describe('RE-coins', () => {
  it('1 балл за каждые полные 10 ₽', () => {
    expect(coinsForSpend(1_234)).toBe(123)
    expect(coinsForSpend(9)).toBe(0)
    expect(coinsForSpend(10)).toBe(1)
    expect(coinsForSpend(-5)).toBe(0)
  })
})

describe('tierProgress', () => {
  it('до следующего статуса — со следующего рубля после границы', () => {
    const progress = tierProgress(9_000)
    expect(progress.next?.id).toBe('silver')
    expect(progress.remaining).toBe(1_001)
  })
  it('у высшего статуса следующего нет', () => {
    const progress = tierProgress(150_000)
    expect(progress.next).toBeNull()
    expect(progress.fraction).toBe(1)
  })
  it('getTier возвращает статус по id', () => {
    expect(getTier('gold').label).toBe('Золотая')
  })
})
