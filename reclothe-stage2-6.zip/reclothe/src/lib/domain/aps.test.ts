import { describe, expect, it } from 'vitest'

import { applyShift, assessLoad, countActiveTasks, loadPercent, suggestDeadline } from '@/lib/domain/aps'
import type { Order } from '@/lib/domain/types'

function order(id: string, masterId: string, extra: Partial<Order> = {}): Order {
  return { id, masterId, state: 'active', completedAt: null, ...extra } as Order
}

describe('APS — загрузка мастера', () => {
  const orders = [
    order('1', 'm'),
    order('2', 'm'),
    order('3', 'm'),
    order('4', 'm', { completedAt: '2026-10-01T00:00:00Z' }),
    order('5', 'm', { state: 'cancelled' }),
    order('6', 'other'),
  ]

  it('считает только активные задачи мастера', () => {
    expect(countActiveTasks('m', orders)).toBe(3)
    expect(countActiveTasks('m', orders, '1')).toBe(2)
  })

  it('загрузка в процентах от ёмкости', () => {
    expect(loadPercent(3, 5)).toBe(60)
    expect(loadPercent(1, 0)).toBe(100)
  })

  it('до 80% включительно — срок не сдвигается', () => {
    const result = assessLoad({ masterId: 'm', capacity: 5, orders })
    expect(result.currentLoad).toBe(60)
    expect(result.projectedLoad).toBe(80)
    expect(result.overloaded).toBe(false)
    expect(result.shiftDays).toBe(0)
  })

  it('выше 80% — срок сдвигается на +14 дней', () => {
    const busy = [...orders, order('7', 'm')]
    const result = assessLoad({ masterId: 'm', capacity: 5, orders: busy })
    expect(result.projectedLoad).toBe(100)
    expect(result.overloaded).toBe(true)
    expect(result.shiftDays).toBe(14)
  })

  it('при редактировании заказ не учитывается дважды', () => {
    const busy = [...orders, order('7', 'm')]
    const result = assessLoad({ masterId: 'm', capacity: 5, orders: busy, excludeOrderId: '7' })
    expect(result.overloaded).toBe(false)
  })

  it('сдвиг срока и предложенный срок', () => {
    expect(applyShift('2026-10-20', 14)).toBe('2026-11-03')
    expect(applyShift('2026-12-25', 14)).toBe('2027-01-08')
    expect(suggestDeadline('2026-10-18', 12, 1.5)).toBe('2026-10-26')
  })
})
