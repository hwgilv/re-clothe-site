import {
  FINAL_STAGE,
  STOCK_ITEMS,
  getStockItem,
  type StageInfo,
  type StockItemInfo,
  type TierInfo,
} from '@/lib/domain/catalog'
import { countActiveTasks, isActiveOrder, loadPercent } from '@/lib/domain/aps'
import { fullName } from '@/lib/domain/client'
import { calcEcoMetrics, sumEcoMetrics, type EcoMetrics } from '@/lib/domain/eco'
import { coinsForSpend, getTier, tierForSpend, tierProgress, type TierProgress } from '@/lib/domain/loyalty'
import { NPD_RATES, getNpdLimitStatus, type NpdLimitStatus } from '@/lib/domain/npd'
import {
  orderStatus,
  paymentStatus,
  resolveService,
  totalPaid,
  type OrderStatus,
  type PaymentStatus,
} from '@/lib/domain/orders'
import { calcOrderPayroll, type OrderPayroll } from '@/lib/domain/payroll'
import { calcPricing, emptyOptions, type Pricing } from '@/lib/domain/pricing'
import { getStage, orderProgress } from '@/lib/domain/stages'
import { computeStock, consumptionCost, orderConsumption, stockStatus, type StockBalance } from '@/lib/domain/stock'
import type {
  AppState,
  Client,
  Lead,
  Master,
  Order,
  Payout,
  PayoutLine,
  Service,
} from '@/lib/domain/types'
import {
  addMonthsToKey,
  daysBetweenDateStrings,
  monthKey,
  toDateString,
} from '@/lib/date'

/**
 * Единая точка расчёта всей аналитики.
 * Принимает ПЕРВИЧНОЕ состояние и момент времени, возвращает всё, что показывают экраны.
 * Ни одна цифра на экранах не хранится — любое действие меняет состояние, и эта функция
 * пересчитывает цены, ЗП, остатки, графики и статусы карт.
 */

/* ------------------------------------------------------------------ виды */

export interface OrderView {
  order: Order
  client: Client | undefined
  clientName: string
  service: Service
  master: Master | undefined
  pricing: Pricing
  paid: number
  remaining: number
  /** Доля оплаты от цены, 0…100. */
  paidPercent: number
  paymentStatus: PaymentStatus
  status: OrderStatus
  stage: StageInfo
  /** Готовность производства, 0…100. */
  progress: number
  payroll: OrderPayroll
  consumption: Record<string, number>
  materialsCost: number
  weightKg: number
  /** Дней до срока: отрицательное — просрочка. */
  daysLeft: number
  /** Ожидаемая прибыль по заказу: цена − ЗП мастера − материалы − налог. */
  expectedProfit: number
  /** ЗП по заказу уже выплачена (заказ вошёл в акт). */
  payrollLocked: boolean
}

export interface ClientView {
  client: Client
  name: string
  orders: OrderView[]
  /** Оплачено по заказам (без отменённых), ₽. */
  spent: number
  coins: number
  autoTier: TierInfo
  tier: TierInfo
  tierOverridden: boolean
  tierProgress: TierProgress
  eco: EcoMetrics
  activeOrders: number
  /** Сумма цен всех заказов (без отменённых). */
  orderedTotal: number
  lastOrderAt: string | null
}

export interface LeadView {
  lead: Lead
  client: Client | undefined
  name: string
}

export interface MasterView {
  master: Master
  activeTasks: number
  load: number
  overloaded: boolean
  /** Все закрытые заказы мастера (дошли до «Готово»). */
  closed: OrderView[]
  /** Закрытые заказы, по которым ЗП ещё не выплачена. */
  unpaid: OrderView[]
  /** К выплате: база + бонусы − штрафы по невыплаченным заказам. */
  balance: number
  unpaidBase: number
  unpaidBonuses: number
  unpaidPenalties: number
  paidTotal: number
}

export interface StockView {
  info: StockItemInfo
  balance: StockBalance
}

export interface FinanceMonth {
  key: string
  revenue: number
  payroll: number
  materials: number
  expenses: number
  tax: number
  profit: number
}

export interface Transaction {
  id: string
  at: string
  kind: 'income' | 'expense'
  category: string
  title: string
  amount: number
  orderId?: string
}

export interface Finance {
  months: FinanceMonth[]
  /** Показатели за текущий календарный месяц. */
  current: FinanceMonth
  previous: FinanceMonth
  /** Показатели за всё время. */
  totals: Omit<FinanceMonth, 'key'>
  transactions: Transaction[]
  yearIncome: number
  npd: NpdLimitStatus
  receivables: number
}

export type NotificationTone = 'info' | 'warning' | 'danger' | 'success'

export interface AppNotification {
  id: string
  tone: NotificationTone
  title: string
  detail: string
  href: string
}

export interface Derived {
  today: string
  currentMonth: string
  orders: OrderView[]
  orderById: ReadonlyMap<string, OrderView>
  clients: ClientView[]
  clientById: ReadonlyMap<string, ClientView>
  masters: MasterView[]
  masterById: ReadonlyMap<string, MasterView>
  leads: LeadView[]
  newLeads: LeadView[]
  stock: StockView[]
  stockById: ReadonlyMap<string, StockView>
  finance: Finance
  notifications: AppNotification[]
  eco: EcoMetrics
  /** Заказы в работе по этапам (индекс = номер этапа − 1). */
  pipeline: number[]
  activeOrders: OrderView[]
  averageCheck: number
}

/* ------------------------------------------------------------ вспомогательное */

const UNKNOWN_MASTER_NAME = 'Не назначен'

function placeholderService(id: string): Service {
  return {
    id,
    categoryId: 'accessories',
    name: `Услуга ${id} (нет в каталоге)`,
    description: '',
    masterRate: 0,
    clientPrice: 0,
    hoursMin: 0,
    hoursMax: 0,
    defaultMasterId: '',
    defaultComplexity: 'base',
    donor: { title: '', materialId: 'cotton', weightKg: 0 },
  }
}

export function buildOrderView(state: AppState, order: Order, today: string): OrderView {
  const client = state.clients.find((item) => item.id === order.clientId)
  const current = resolveService(order.serviceId, state.serviceOverrides) ?? placeholderService(order.serviceId)
  // Цена и ставка берутся из тарифа, зафиксированного при создании заказа.
  const service = order.tariff
    ? { ...current, masterRate: order.tariff.masterRate, clientPrice: order.tariff.clientPrice }
    : current
  const pricing = calcPricing({
    service,
    complexityId: order.complexityId,
    materialId: order.materialId,
    options: order.options ?? emptyOptions(),
  })
  const paid = totalPaid(order.payments)
  const price = pricing.clientTotal
  const payroll = calcOrderPayroll(pricing.masterTotal, order.adjustments)
  const consumption = orderConsumption(order, service.hoursMax)
  const materialsCost = consumptionCost(consumption)
  const weightKg =
    Math.round(order.donors.reduce((total, donor) => total + donor.weightKg, 0) * 1000) / 1000
  const tax = Math.round(price * NPD_RATES.individual)

  return {
    order,
    client,
    clientName: client ? fullName(client) : 'Клиент удалён',
    service,
    master: state.masters.find((item) => item.id === order.masterId),
    pricing,
    paid,
    remaining: Math.max(0, price - paid),
    paidPercent: price > 0 ? Math.min(100, Math.round((paid / price) * 100)) : 0,
    paymentStatus: paymentStatus(paid, price),
    status: orderStatus(order, today),
    stage: getStage(order.stage),
    progress: orderProgress(order.stage, order.stageProgress),
    payroll,
    consumption,
    materialsCost,
    weightKg,
    daysLeft: daysBetweenDateStrings(today, order.deadline),
    expectedProfit: price - payroll.total - materialsCost - tax,
    payrollLocked: order.payoutId !== null,
  }
}

/* ------------------------------------------------------------------- финансы */

function emptyMonth(key: string): FinanceMonth {
  return { key, revenue: 0, payroll: 0, materials: 0, expenses: 0, tax: 0, profit: 0 }
}

function finalizeMonth(month: FinanceMonth): FinanceMonth {
  const tax = Math.round(month.revenue * NPD_RATES.individual)
  return {
    ...month,
    tax,
    profit: month.revenue - month.payroll - month.materials - month.expenses - tax,
  }
}

function computeFinance(state: AppState, orders: readonly OrderView[], today: string): Finance {
  const currentKey = monthKey(today)
  const buckets = new Map<string, FinanceMonth>()
  const bucket = (key: string): FinanceMonth => {
    let entry = buckets.get(key)
    if (!entry) {
      entry = emptyMonth(key)
      buckets.set(key, entry)
    }
    return entry
  }

  const transactions: Transaction[] = []

  for (const view of orders) {
    // Отмена заказа считается возвратом оплаты: деньги в выручку не попадают.
    if (view.order.state === 'cancelled') continue
    for (const payment of view.order.payments) {
      bucket(monthKey(payment.at)).revenue += payment.amount
      transactions.push({
        id: `pay-${payment.id}`,
        at: payment.at,
        kind: 'income',
        category: payment.kind === 'advance' ? 'Аванс' : 'Оплата заказа',
        title: `${view.order.number} · ${view.clientName}`,
        amount: payment.amount,
        orderId: view.order.id,
      })
    }
  }

  for (const payout of state.payouts) {
    bucket(monthKey(payout.at)).payroll += payout.total
    const master = state.masters.find((item) => item.id === payout.masterId)
    transactions.push({
      id: `payout-${payout.id}`,
      at: payout.at,
      kind: 'expense',
      category: 'Зарплата',
      title: `Выплата ЗП · ${master?.name ?? UNKNOWN_MASTER_NAME} · акт №${payout.actNo}`,
      amount: payout.total,
    })
  }

  for (const expense of state.expenses) {
    bucket(monthKey(expense.at)).expenses += expense.amount
    transactions.push({
      id: `exp-${expense.id}`,
      at: expense.at,
      kind: 'expense',
      category: EXPENSE_CATEGORY_LABELS[expense.category],
      title: expense.title,
      amount: expense.amount,
    })
  }

  for (const movement of state.stockMovements) {
    if (movement.qty <= 0 || movement.cost <= 0) continue
    bucket(monthKey(movement.at)).materials += movement.cost
    transactions.push({
      id: `stock-${movement.id}`,
      at: movement.at,
      kind: 'expense',
      category: 'Материалы',
      title: `Закупка: ${getStockItem(movement.itemId)?.name ?? movement.itemId}`,
      amount: movement.cost,
    })
  }

  transactions.sort((a, b) => (a.at < b.at ? 1 : a.at > b.at ? -1 : 0))

  // Последние 6 месяцев, включая текущий.
  const months: FinanceMonth[] = []
  for (let offset = -5; offset <= 0; offset += 1) {
    const key = addMonthsToKey(currentKey, offset)
    months.push(finalizeMonth(bucket(key)))
  }

  const totalsRaw = [...buckets.values()].reduce<FinanceMonth>((total, month) => ({
    key: 'total',
    revenue: total.revenue + month.revenue,
    payroll: total.payroll + month.payroll,
    materials: total.materials + month.materials,
    expenses: total.expenses + month.expenses,
    tax: 0,
    profit: 0,
  }), emptyMonth('total'))
  const grand = finalizeMonth(totalsRaw)
  const totals = {
    revenue: grand.revenue,
    payroll: grand.payroll,
    materials: grand.materials,
    expenses: grand.expenses,
    tax: grand.tax,
    profit: grand.profit,
  }

  const year = currentKey.slice(0, 4)
  const yearIncome = [...buckets.values()]
    .filter((month) => month.key.startsWith(year))
    .reduce((total, month) => total + month.revenue, 0)

  const receivables = orders
    .filter((view) => view.order.state === 'active')
    .reduce((total, view) => total + view.remaining, 0)

  return {
    months,
    current: months[months.length - 1] ?? emptyMonth(currentKey),
    previous: months[months.length - 2] ?? emptyMonth(addMonthsToKey(currentKey, -1)),
    totals,
    transactions,
    yearIncome,
    npd: getNpdLimitStatus(yearIncome),
    receivables,
  }
}

export const EXPENSE_CATEGORY_LABELS = {
  rent: 'Аренда',
  marketing: 'Маркетинг',
  utilities: 'Коммунальные',
  equipment: 'Оборудование',
  other: 'Прочее',
} as const

/* --------------------------------------------------------------- уведомления */

function buildNotifications(
  newLeads: readonly LeadView[],
  orders: readonly OrderView[],
  stock: readonly StockView[],
  masters: readonly MasterView[],
): AppNotification[] {
  const result: AppNotification[] = []

  for (const item of newLeads) {
    result.push({
      id: `lead-${item.lead.id}`,
      tone: 'info',
      title: `Новая заявка: ${item.name}`,
      detail: 'Свяжитесь с клиентом и согласуйте консультацию.',
      href: '/orders?tab=leads',
    })
  }

  for (const view of orders) {
    if (view.status === 'overdue') {
      result.push({
        id: `overdue-${view.order.id}`,
        tone: 'danger',
        title: `${view.order.number} просрочен на ${Math.abs(view.daysLeft)} дн.`,
        detail: `${view.service.name} · ${view.clientName}`,
        href: `/orders/${view.order.id}`,
      })
    } else if (view.status === 'ready' && view.remaining > 0 && view.order.state === 'active') {
      result.push({
        id: `unpaid-${view.order.id}`,
        tone: 'warning',
        title: `${view.order.number} готов, остаток не оплачен`,
        detail: `Принять оплату: ${view.remaining.toLocaleString('ru-RU')} ₽`,
        href: `/orders/${view.order.id}`,
      })
    }
  }

  for (const item of stock) {
    if (item.balance.status === 'ok') continue
    result.push({
      id: `stock-${item.info.id}`,
      tone: item.balance.status === 'out' ? 'danger' : 'warning',
      title: `${item.info.name}: ${item.balance.status === 'out' ? 'закончились' : 'заканчиваются'}`,
      detail: `Остаток ${item.balance.balance} ${item.info.unit}, минимум ${item.info.min}`,
      href: '/inventory?tab=materials',
    })
  }

  for (const item of masters) {
    if (item.overloaded) {
      result.push({
        id: `load-${item.master.id}`,
        tone: 'warning',
        title: `${item.master.name}: загрузка ${item.load}%`,
        detail: 'Новые заказы будут сдвигать срок на +14 дней.',
        href: '/production',
      })
    }
  }

  return result
}

/* ------------------------------------------------------------------ главная */

export function deriveAll(state: AppState, nowMs: number): Derived {
  const today = toDateString(new Date(nowMs))
  const currentMonth = monthKey(today)

  const orders = state.orders
    .map((order) => buildOrderView(state, order, today))
    .sort((a, b) =>
      a.order.createdAt < b.order.createdAt ? 1 : a.order.createdAt > b.order.createdAt ? -1 : b.order.number.localeCompare(a.order.number),
    )
  const orderById = new Map(orders.map((view) => [view.order.id, view]))

  const clients: ClientView[] = state.clients
    .map((client) => {
      const own = orders.filter((view) => view.order.clientId === client.id)
      const counted = own.filter((view) => view.order.state !== 'cancelled')
      const spent = counted.reduce((total, view) => total + view.paid, 0)
      const autoTier = tierForSpend(spent)
      const tier = client.tierOverride ? getTier(client.tierOverride) : autoTier
      return {
        client,
        name: fullName(client),
        orders: own,
        spent,
        coins: coinsForSpend(spent),
        autoTier,
        tier,
        tierOverridden: client.tierOverride !== null,
        tierProgress: tierProgress(spent),
        eco: sumEcoMetrics(counted.map((view) => calcEcoMetrics(view.weightKg))),
        activeOrders: own.filter((view) => isActiveOrder(view.order)).length,
        orderedTotal: counted.reduce((total, view) => total + view.pricing.clientTotal, 0),
        lastOrderAt: own[0]?.order.createdAt ?? null,
      }
    })
    .sort((a, b) => a.name.localeCompare(b.name, 'ru'))
  const clientById = new Map(clients.map((view) => [view.client.id, view]))

  const masters: MasterView[] = state.masters.map((master) => {
    const own = orders.filter((view) => view.order.masterId === master.id && view.order.state === 'active')
    const closed = own.filter((view) => view.order.completedAt !== null)
    const unpaid = closed.filter((view) => view.order.payoutId === null)
    const activeTasks = countActiveTasks(master.id, state.orders)
    const load = loadPercent(activeTasks, master.capacity)
    return {
      master,
      activeTasks,
      load,
      overloaded: load > 80,
      closed,
      unpaid,
      balance: unpaid.reduce((total, view) => total + view.payroll.total, 0),
      unpaidBase: unpaid.reduce((total, view) => total + view.payroll.base, 0),
      unpaidBonuses: unpaid.reduce((total, view) => total + view.payroll.bonusTotal, 0),
      unpaidPenalties: unpaid.reduce((total, view) => total + view.payroll.penaltyTotal, 0),
      paidTotal: state.payouts
        .filter((payout) => payout.masterId === master.id)
        .reduce((total, payout) => total + payout.total, 0),
    }
  })
  const masterById = new Map(masters.map((view) => [view.master.id, view]))

  const leads: LeadView[] = state.leads
    .map((lead) => {
      const client = state.clients.find((item) => item.id === lead.clientId)
      return { lead, client, name: client ? fullName(client) : 'Клиент удалён' }
    })
    .sort((a, b) => (a.lead.createdAt < b.lead.createdAt ? 1 : -1))
  const newLeads = leads.filter((item) => item.lead.status === 'new')

  const consumptionByOrder = orders
    .filter((view) => view.order.state === 'active')
    .map((view) => view.consumption)
  const balances = computeStock(state.stockMovements, consumptionByOrder)
  const stock: StockView[] = STOCK_ITEMS.map((info) => {
    const balance = balances.find((item) => item.itemId === info.id) ?? {
      itemId: info.id,
      received: 0,
      writtenOff: 0,
      consumed: 0,
      balance: 0,
      status: stockStatus(0, info.min),
    }
    return { info, balance }
  })
  const stockById = new Map(stock.map((item) => [item.info.id, item]))

  const finance = computeFinance(state, orders, today)
  const activeOrders = orders.filter((view) => isActiveOrder(view.order))
  const pipeline = Array.from({ length: FINAL_STAGE }, (_, index) =>
    orders.filter((view) => view.order.state === 'active' && view.order.stage === index + 1).length,
  )
  const counted = orders.filter((view) => view.order.state !== 'cancelled')

  return {
    today,
    currentMonth,
    orders,
    orderById,
    clients,
    clientById,
    masters,
    masterById,
    leads,
    newLeads,
    stock,
    stockById,
    finance,
    notifications: buildNotifications(newLeads, orders, stock, masters),
    eco: sumEcoMetrics(counted.map((view) => calcEcoMetrics(view.weightKg))),
    pipeline,
    activeOrders,
    averageCheck: counted.length
      ? Math.round(counted.reduce((total, view) => total + view.pricing.clientTotal, 0) / counted.length)
      : 0,
  }
}

/* ------------------------------------------------------------------- выплаты */

export interface PayoutDraft {
  masterId: string
  lines: PayoutLine[]
  base: number
  bonuses: number
  penalties: number
  total: number
}

/** Снимок для акта: что именно входит в выплату мастеру. */
export function buildPayoutDraft(masterId: string, views: readonly OrderView[]): PayoutDraft {
  const lines: PayoutLine[] = views.map((view) => ({
    orderId: view.order.id,
    orderNumber: view.order.number,
    serviceName: view.service.name,
    base: view.payroll.base,
    bonuses: view.payroll.bonuses.map((line) => ({ label: line.label, amount: line.amount })),
    penalties: view.payroll.penalties.map((line) => ({ label: line.label, amount: line.amount })),
  }))
  return { masterId, lines, ...sumPayoutLines(lines) }
}

export function sumPayoutLines(lines: readonly PayoutLine[]): {
  base: number
  bonuses: number
  penalties: number
  total: number
} {
  const base = lines.reduce((total, line) => total + line.base, 0)
  const bonuses = lines.reduce(
    (total, line) => total + line.bonuses.reduce((sum, item) => sum + item.amount, 0),
    0,
  )
  const penalties = lines.reduce(
    (total, line) => total + line.penalties.reduce((sum, item) => sum + item.amount, 0),
    0,
  )
  return { base, bonuses, penalties, total: base + bonuses - penalties }
}

export interface PayrollSummary {
  accrued: number
  paid: number
  withheld: number
  balance: number
}

/**
 * Сводка для карточек «Бухгалтерии». `period` — ключ месяца «2026-10» или null (всё время).
 *  - начислено — база + бонусы по заказам, закрытым в периоде;
 *  - удержано — штрафы по тем же заказам;
 *  - выплачено — суммы выплат в периоде;
 *  - баланс — сколько нужно выплатить прямо сейчас (не зависит от периода).
 */
export function computePayrollSummary(
  masters: readonly MasterView[],
  payouts: readonly Payout[],
  period: string | null,
): PayrollSummary {
  const inPeriod = (iso: string | null): boolean =>
    iso !== null && (period === null || monthKey(iso) === period)

  let accrued = 0
  let withheld = 0
  for (const item of masters) {
    for (const view of item.closed) {
      if (!inPeriod(view.order.completedAt)) continue
      accrued += view.payroll.base + view.payroll.bonusTotal
      withheld += view.payroll.penaltyTotal
    }
  }
  const paid = payouts
    .filter((payout) => inPeriod(payout.at))
    .reduce((total, payout) => total + payout.total, 0)
  const balance = masters.reduce((total, item) => total + item.balance, 0)
  return { accrued, paid, withheld, balance }
}

export { UNKNOWN_MASTER_NAME }
