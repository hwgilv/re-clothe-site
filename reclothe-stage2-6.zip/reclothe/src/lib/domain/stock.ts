import {
  OPTION_CONSUMPTION,
  STOCK_ITEMS,
  THREAD_HOURS_PER_SPOOL,
  getStockItem,
} from '@/lib/domain/catalog'
import { sanitizeQty } from '@/lib/domain/pricing'
import type { Order, StockMovement } from '@/lib/domain/types'

/** Сколько расходников уйдёт на заказ: по картам опций + нитки по норме времени услуги. */
export function orderConsumption(
  order: Pick<Order, 'options'>,
  hoursMax: number,
): Record<string, number> {
  const consumed: Record<string, number> = {}
  const add = (itemId: string, qty: number): void => {
    consumed[itemId] = Math.round(((consumed[itemId] ?? 0) + qty) * 100) / 100
  }
  const addOption = (optionId: string, times: number): void => {
    const map = OPTION_CONSUMPTION[optionId]
    if (!map || times <= 0) return
    for (const [itemId, perUnit] of Object.entries(map)) add(itemId, perUnit * times)
  }

  for (const [id, qty] of Object.entries(order.options.ops)) addOption(id, sanitizeQty(qty))
  for (const [id, qty] of Object.entries(order.options.art)) addOption(id, sanitizeQty(qty))
  if (order.options.corset) addOption('@corset', 1)
  if (order.options.lining) addOption('@lining', 1)
  if (order.options.beads) addOption('@beads', 1)

  add('thread', Math.max(1, Math.ceil(hoursMax / THREAD_HOURS_PER_SPOOL)))
  return consumed
}

export type StockStatus = 'ok' | 'low' | 'out'

export interface StockBalance {
  itemId: string
  received: number
  writtenOff: number
  consumed: number
  balance: number
  status: StockStatus
}

export function stockStatus(balance: number, min: number): StockStatus {
  if (balance <= 0) return 'out'
  if (balance < min) return 'low'
  return 'ok'
}

/**
 * Остаток = приходы − ручные списания − расход на активные и готовые заказы.
 * Расход выводится из заказов, поэтому отмена заказа сама возвращает материалы на склад.
 */
export function computeStock(
  movements: readonly StockMovement[],
  consumptionByOrder: readonly Record<string, number>[],
): StockBalance[] {
  return STOCK_ITEMS.map((item) => {
    const own = movements.filter((movement) => movement.itemId === item.id)
    const received = own.filter((m) => m.qty > 0).reduce((total, m) => total + m.qty, 0)
    const writtenOff = own.filter((m) => m.qty < 0).reduce((total, m) => total - m.qty, 0)
    const consumed = consumptionByOrder.reduce((total, map) => total + (map[item.id] ?? 0), 0)
    const balance = Math.round((received - writtenOff - consumed) * 100) / 100
    return {
      itemId: item.id,
      received: Math.round(received * 100) / 100,
      writtenOff: Math.round(writtenOff * 100) / 100,
      consumed: Math.round(consumed * 100) / 100,
      balance,
      status: stockStatus(balance, item.min),
    }
  })
}

/** Стоимость расходников заказа, ₽ — для себестоимости. */
export function consumptionCost(consumption: Record<string, number>): number {
  return Math.round(
    Object.entries(consumption).reduce(
      (total, [itemId, qty]) => total + qty * (getStockItem(itemId)?.unitCost ?? 0),
      0,
    ),
  )
}
