import { describe, expect, it } from 'vitest'

import { clampPercent, clampStage, getStage, orderProgress } from '@/lib/domain/stages'

describe('orderProgress', () => {
  it('начало — 0%, финал — 100%', () => {
    expect(orderProgress(1, 0)).toBe(0)
    expect(orderProgress(8, 0)).toBe(100)
  })

  it('«Этап 4. Раскрой» на середине — 44%', () => {
    expect(getStage(4).title).toBe('Раскрой')
    expect(orderProgress(4, 50)).toBe(44)
  })

  it('растёт монотонно по этапам и внутри этапа', () => {
    let previous = -1
    for (let stage = 1; stage <= 7; stage += 1) {
      for (const inner of [0, 25, 50, 75]) {
        const value = orderProgress(stage, inner)
        expect(value).toBeGreaterThanOrEqual(previous)
        previous = value
      }
    }
  })

  it('мусор приводится к допустимым значениям', () => {
    expect(clampStage(Number.NaN)).toBe(1)
    expect(clampStage(99)).toBe(8)
    expect(clampStage(0)).toBe(1)
    expect(clampPercent(150)).toBe(100)
    expect(clampPercent(-5)).toBe(0)
    expect(() => getStage(42)).toThrow(RangeError)
  })
})
