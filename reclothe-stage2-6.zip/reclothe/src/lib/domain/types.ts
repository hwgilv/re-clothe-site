/**
 * Типы предметной области RE:clothe.
 *
 * Принцип: в состоянии (AppState) лежат только ПЕРВИЧНЫЕ данные — то, что ввёл человек.
 * Всё остальное (цена, ЗП, остаток, статус карты, загрузка мастера, графики) выводится
 * из первичных данных чистыми функциями — см. `derive.ts`. Поэтому любое действие
 * автоматически пересчитывает всю систему.
 */

export type MessengerId = 'telegram' | 'vk' | 'whatsapp' | 'call'

export type LoyaltyTierId = 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond'

export type ComplexityId = 'base' | 'low' | 'medium' | 'high' | 'very-high' | 'extreme'

export type MaterialId =
  | 'cotton'
  | 'denim'
  | 'flannel'
  | 'knit'
  | 'synthetic'
  | 'leather'
  | 'eco-leather'
  | 'suede'
  | 'fur'
  | 'faux-fur'
  | 'membrane'
  | 'silk'
  | 'mixed'

export type UrgencyId = 'none' | '24h' | '48h' | '72h'

export type CategoryId =
  | 'outerwear'
  | 'midlayer'
  | 'light'
  | 'bottoms'
  | 'accessories'
  | 'headwear'
  | 'kids'
  | 'pets'

/** Услуга из тарифной сетки (раздел 7.3 бизнес-плана). */
export interface Service {
  /** Номер из плана: «1.2», «3.8». */
  id: string
  categoryId: CategoryId
  name: string
  description: string
  /** Базовая ставка мастера, ₽. */
  masterRate: number
  /** Базовая цена для клиента, ₽. */
  clientPrice: number
  hoursMin: number
  hoursMax: number
  /** Мастер, которого система предлагает по умолчанию. */
  defaultMasterId: string
  defaultComplexity: ComplexityId
  /** Типовая вещь-донор для этой услуги (подставляется в форму заказа, можно править). */
  donor: { title: string; materialId: MaterialId; weightKg: number }
}

export interface Client {
  id: string
  lastName: string
  firstName: string
  middleName: string
  phone: string
  email: string
  contact: MessengerId
  createdAt: string
  /** Откуда пришёл: регистрация на сайте или заведён администратором. */
  source: 'site' | 'admin'
  /** Ручная смена статуса карты; null — статус считается автоматически по сумме покупок. */
  tierOverride: LoyaltyTierId | null
}

export type LeadStatus = 'new' | 'contacted' | 'converted' | 'archived'

export interface Lead {
  id: string
  clientId: string
  createdAt: string
  status: LeadStatus
  contactedAt: string | null
}

export interface OrderDonor {
  id: string
  /** Складской номер «DN-0001», присваивается при сохранении заказа. */
  code: string
  title: string
  materialId: MaterialId
  weightKg: number
  note: string
}

/** Выбранные дополнительные опции заказа. Ключ — id опции, значение — количество. */
export interface OrderOptions {
  ops: Record<string, number>
  art: Record<string, number>
  urgency: UrgencyId
  corset: boolean
  lining: boolean
  handSeamsMeters: number
  beads: boolean
}

export interface Payment {
  id: string
  amount: number
  kind: 'advance' | 'payment'
  at: string
  note: string
}

/** Применённая бонусная или штрафная позиция (таблицы 7.8.1 / 7.8.2). */
export interface Adjustment {
  id: string
  kind: 'bonus' | 'penalty'
  /** Код из каталога бонусов/штрафов. */
  code: string
  /** Множитель для позиций «за час» / «за штуку». */
  qty: number
  /** Сумма для позиций с произвольной суммой («новая техника», «возмещение материалов»). */
  customAmount: number | null
  at: string
}

export interface Order {
  id: string
  /** «RC-2026-0001» */
  number: string
  clientId: string
  serviceId: string
  complexityId: ComplexityId
  materialId: MaterialId
  options: OrderOptions
  donors: OrderDonor[]
  masterId: string
  createdAt: string
  /** Итоговый срок (YYYY-MM-DD) — с учётом смещения APS. */
  deadline: string
  /** Срок, который выбрал администратор. */
  requestedDeadline: string
  /** На сколько дней APS сдвинула срок из-за загрузки мастера. */
  apsShiftDays: number
  /** Текущий этап производства, 1…8. */
  stage: number
  /** Прогресс внутри текущего этапа, 0…100. */
  stageProgress: number
  state: 'active' | 'cancelled'
  /** Когда заказ дошёл до последнего этапа («Готово»). */
  completedAt: string | null
  payments: Payment[]
  adjustments: Adjustment[]
  /**
   * Тариф, по которому согласован заказ. Фиксируется при создании: правка тарифной сетки
   * в «Настройках» меняет только новые заказы, а не уже подписанные.
   */
  tariff?: { masterRate: number; clientPrice: number }
  comment: string
  /** Id выплаты, в которую вошёл заказ; null — ЗП по заказу ещё не выплачена. */
  payoutId: string | null
}

export interface Master {
  id: string
  name: string
  /** Специализация словами. */
  role: string
  /** Сколько одновременных задач — это 100% загрузки. */
  capacity: number
  contractNo: string
  contractDate: string
  color: string
}

export interface PayoutLine {
  orderId: string
  orderNumber: string
  serviceName: string
  base: number
  bonuses: { label: string; amount: number }[]
  penalties: { label: string; amount: number }[]
}

export interface Payout {
  id: string
  masterId: string
  at: string
  actNo: number
  lines: PayoutLine[]
  base: number
  bonuses: number
  penalties: number
  total: number
}

export type ExpenseCategory = 'rent' | 'marketing' | 'utilities' | 'equipment' | 'other'

export interface Expense {
  id: string
  at: string
  title: string
  category: ExpenseCategory
  amount: number
}

export interface StockMovement {
  id: string
  itemId: string
  /** Приход — положительное, ручное списание — отрицательное. */
  qty: number
  /** Сколько заплатили за партию (для прихода), ₽. */
  cost: number
  at: string
  note: string
}

export interface ServiceOverride {
  masterRate?: number
  clientPrice?: number
}

export interface Counters {
  order: number
  donor: number
  act: number
}

export interface AppState {
  version: 1
  /** Растёт при каждом изменении — по нему вкладки понимают, чьё состояние новее. */
  rev: number
  clients: Client[]
  leads: Lead[]
  orders: Order[]
  masters: Master[]
  payouts: Payout[]
  expenses: Expense[]
  stockMovements: StockMovement[]
  serviceOverrides: Record<string, ServiceOverride>
  counters: Counters
}
