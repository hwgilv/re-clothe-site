import { getZonedDateParts } from '@/lib/date'

/** Годовой лимит дохода самозанятого (НПД), ₽. */
export const NPD_ANNUAL_LIMIT_RUB = 2_400_000

/** Ставки НПД: 4% с доходов от физлиц, 6% — от юрлиц и ИП. Основные клиенты студии — физлица. */
export const NPD_RATES = {
  individual: 0.04,
  legalEntity: 0.06,
} as const

export type NpdPayerType = keyof typeof NPD_RATES

/** Пороги предупреждений о приближении к лимиту (доли от лимита). */
export const NPD_WARNING_THRESHOLDS = [0.8, 0.9, 0.95] as const

/** Число месяца, до которого платится налог за предыдущий месяц. */
export const NPD_PAYMENT_DAY = 28

/** Налог с одного поступления, округлённый до копеек. */
export function calcNpdTax(amount: number, payer: NpdPayerType = 'individual'): number {
  if (!Number.isFinite(amount) || amount < 0) {
    throw new RangeError(`Сумма должна быть конечным числом ≥ 0, получено: ${amount}`)
  }
  return Math.round(amount * NPD_RATES[payer] * 100) / 100
}

export type NpdLimitLevel = 'ok' | 'warn80' | 'warn90' | 'warn95' | 'exceeded'

export interface NpdLimitStatus {
  income: number
  limit: number
  /** Остаток лимита, не меньше 0. */
  remaining: number
  /** Доля использованного лимита; может быть больше 1 при превышении. */
  usedFraction: number
  level: NpdLimitLevel
}

export function getNpdLimitStatus(
  yearIncome: number,
  limit: number = NPD_ANNUAL_LIMIT_RUB,
): NpdLimitStatus {
  if (!Number.isFinite(yearIncome) || yearIncome < 0) {
    throw new RangeError(`Доход должен быть конечным числом ≥ 0, получено: ${yearIncome}`)
  }
  if (!Number.isFinite(limit) || limit <= 0) {
    throw new RangeError(`Лимит должен быть положительным числом, получено: ${limit}`)
  }

  const usedFraction = yearIncome / limit

  let level: NpdLimitLevel
  // Лимит считается превышенным только когда доход строго больше 2,4 млн.
  if (yearIncome > limit) level = 'exceeded'
  else if (usedFraction >= 0.95) level = 'warn95'
  else if (usedFraction >= 0.9) level = 'warn90'
  else if (usedFraction >= 0.8) level = 'warn80'
  else level = 'ok'

  return {
    income: yearIncome,
    limit,
    remaining: Math.max(0, limit - yearIncome),
    usedFraction,
    level,
  }
}

/**
 * Ближайшая дата уплаты НПД (28-е число) в календарном поясе студии, формат YYYY-MM-DD.
 * Если сегодня 28-е — платёж «сегодня». Перенос на рабочий день не учитывается.
 */
export function nextNpdPaymentDate(now: Date = new Date()): string {
  const { year, month, day } = getZonedDateParts(now)

  let payYear = year
  let payMonth = month
  if (day > NPD_PAYMENT_DAY) {
    payMonth += 1
    if (payMonth > 12) {
      payMonth = 1
      payYear += 1
    }
  }

  return `${payYear}-${String(payMonth).padStart(2, '0')}-${NPD_PAYMENT_DAY}`
}
