import { describe, expect, it } from 'vitest'

import { emptyOptions } from '@/lib/domain/pricing'
import { computeStock, consumptionCost, orderConsumption, stockStatus } from '@/lib/domain/stock'
import type { StockMovement } from '@/lib/domain/types'

describe('orderConsumption', () => {
  it('утепление, молния, люверсы и нитки по норме времени', () => {
    const consumption = orderConsumption(
      { options: { ...emptyOptions(), ops: { insulation: 1, 'zip-double': 2, eyelet: 10 } } },
      16,
    )
    expect(consumption.synthetic).toBe(2)
    expect(consumption['zip-double']).toBe(2)
    expect(consumption.eyelet).toBe(10)
    expect(consumption.thread).toBe(2)
  })

  it('корсет, подкладка и бисер тратят свои материалы', () => {
    const consumption = orderConsumption(
      { options: { ...emptyOptions(), corset: true, lining: true, beads: true } },
      4,
    )
    expect(consumption.boning).toBe(1)
    expect(consumption.lining).toBe(1.5)
    expect(consumption.beads).toBe(1)
    expect(consumption.eyelet).toBe(10)
    expect(consumption.thread).toBe(1)
  })

  it('люверсы из шнуровки складываются с отдельными люверсами', () => {
    const consumption = orderConsumption(
      { options: { ...emptyOptions(), ops: { eyelet: 4, lacing: 1 } } },
      2,
    )
    expect(consumption.eyelet).toBe(12)
    expect(consumption.cord).toBe(1)
  })

  it('стоимость расходников', () => {
    expect(consumptionCost({ synthetic: 2, eyelet: 10 })).toBe(2 * 300 + 10 * 4)
  })
})

describe('computeStock', () => {
  const movements: StockMovement[] = [
    { id: '1', itemId: 'synthetic', qty: 10, cost: 3000, at: '2026-10-01', note: '' },
    { id: '2', itemId: 'synthetic', qty: -1, cost: 0, at: '2026-10-02', note: 'брак' },
  ]

  it('остаток = приход − списание − расход на заказы', () => {
    const balances = computeStock(movements, [{ synthetic: 2 }, { synthetic: 1.5 }])
    const item = balances.find((entry) => entry.itemId === 'synthetic')
    expect(item?.received).toBe(10)
    expect(item?.writtenOff).toBe(1)
    expect(item?.consumed).toBe(3.5)
    expect(item?.balance).toBe(5.5)
  })

  it('статусы: норма / мало / нет', () => {
    expect(stockStatus(10, 6)).toBe('ok')
    expect(stockStatus(5.5, 6)).toBe('low')
    expect(stockStatus(0, 6)).toBe('out')
    expect(stockStatus(-2, 6)).toBe('out')
  })
})
