import { describe, expect, it } from 'vitest'

import { formatDeadlineLabel, getDeadlineStatus } from './deadline'

// 12:00 по Новокузнецку, суббота 17 октября 2026
const NOW = new Date('2026-10-17T05:00:00Z')
const inDays = (days: number) => new Date(NOW.getTime() + days * 86_400_000)

describe('getDeadlineStatus', () => {
  it('сегодня — красный', () => {
    const status = getDeadlineStatus(inDays(0), NOW)
    expect(status).toMatchObject({ daysLeft: 0, tone: 'danger', overdue: false, label: 'Сегодня' })
  })

  it('просрочен — красный с числом дней', () => {
    const status = getDeadlineStatus(inDays(-2), NOW)
    expect(status).toMatchObject({
      daysLeft: -2,
      tone: 'danger',
      overdue: true,
      label: 'Просрочен на 2 дн.',
    })
  })

  it('завтра и через 3 дня — жёлтый', () => {
    expect(getDeadlineStatus(inDays(1), NOW)).toMatchObject({ tone: 'warning', label: 'Завтра' })
    expect(getDeadlineStatus(inDays(3), NOW)).toMatchObject({
      tone: 'warning',
      label: 'Через 3 дн.',
    })
  })

  it('через 4 дня и позже — зелёный', () => {
    expect(getDeadlineStatus(inDays(4), NOW)).toMatchObject({ tone: 'ok', label: 'Через 4 дн.' })
  })

  it('дедлайн позже в тот же календарный день не считается просроченным', () => {
    const lateToday = new Date('2026-10-17T11:00:00Z') // 18:00 по Новокузнецку
    expect(getDeadlineStatus(lateToday, NOW).overdue).toBe(false)
  })
})

describe('formatDeadlineLabel', () => {
  it('формирует подписи', () => {
    expect(formatDeadlineLabel(-1)).toBe('Просрочен на 1 дн.')
    expect(formatDeadlineLabel(0)).toBe('Сегодня')
    expect(formatDeadlineLabel(1)).toBe('Завтра')
    expect(formatDeadlineLabel(7)).toBe('Через 7 дн.')
  })
})
