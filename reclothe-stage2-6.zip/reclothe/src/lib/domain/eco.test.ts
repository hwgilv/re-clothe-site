import { describe, expect, it } from 'vitest'

import { calcEcoMetrics, nextMilestoneKg, sumEcoMetrics } from '@/lib/domain/eco'

describe('calcEcoMetrics — 1 кг текстиля = 2 700 л воды и 10 кг CO₂', () => {
  it('1 кг', () => {
    expect(calcEcoMetrics(1)).toEqual({ textileSavedKg: 1, waterSavedLiters: 2700, co2PreventedKg: 10 })
  })
  it('дробные килограммы', () => {
    const metrics = calcEcoMetrics(2.5)
    expect(metrics.waterSavedLiters).toBe(6750)
    expect(metrics.co2PreventedKg).toBe(25)
  })
  it('ноль и отрицательные значения', () => {
    expect(calcEcoMetrics(0).waterSavedLiters).toBe(0)
    expect(() => calcEcoMetrics(-1)).toThrow(RangeError)
    expect(() => calcEcoMetrics(Number.NaN)).toThrow(RangeError)
  })
})

describe('sumEcoMetrics / вехи', () => {
  it('складывает метрики', () => {
    const total = sumEcoMetrics([calcEcoMetrics(1), calcEcoMetrics(2)])
    expect(total.textileSavedKg).toBe(3)
    expect(total.waterSavedLiters).toBe(8100)
  })
  it('следующая веха по килограммам', () => {
    expect(nextMilestoneKg(0)).toBe(5)
    expect(nextMilestoneKg(5)).toBe(10)
    expect(nextMilestoneKg(23.2)).toBe(25)
    expect(nextMilestoneKg(2000)).toBeGreaterThan(2000)
  })
})
