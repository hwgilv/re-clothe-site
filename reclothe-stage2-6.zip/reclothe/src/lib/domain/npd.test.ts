import { describe, expect, it } from 'vitest'

import { calcNpdTax, getNpdLimitStatus, nextNpdPaymentDate } from './npd'

describe('calcNpdTax', () => {
  it('4% с физлиц и 6% с юрлиц', () => {
    expect(calcNpdTax(10_000)).toBe(400)
    expect(calcNpdTax(10_000, 'legalEntity')).toBe(600)
  })

  it('округляет до копеек', () => {
    expect(calcNpdTax(333.33)).toBe(13.33)
  })

  it('отклоняет отрицательные и нечисловые суммы', () => {
    expect(() => calcNpdTax(-1)).toThrow(RangeError)
    expect(() => calcNpdTax(Number.NaN)).toThrow(RangeError)
  })
})

describe('getNpdLimitStatus', () => {
  it('ниже 80% — ok', () => {
    expect(getNpdLimitStatus(0).level).toBe('ok')
    expect(getNpdLimitStatus(1_919_999).level).toBe('ok')
  })

  it('пороги 80 / 90 / 95%', () => {
    expect(getNpdLimitStatus(1_920_000).level).toBe('warn80')
    expect(getNpdLimitStatus(2_160_000).level).toBe('warn90')
    expect(getNpdLimitStatus(2_280_000).level).toBe('warn95')
  })

  it('ровно 2,4 млн — ещё не превышение, строго больше — превышение', () => {
    expect(getNpdLimitStatus(2_400_000).level).toBe('warn95')
    expect(getNpdLimitStatus(2_400_001).level).toBe('exceeded')
  })

  it('остаток не уходит в минус', () => {
    expect(getNpdLimitStatus(2_500_000).remaining).toBe(0)
    expect(getNpdLimitStatus(1_000_000).remaining).toBe(1_400_000)
  })

  it('отклоняет некорректные входные данные', () => {
    expect(() => getNpdLimitStatus(-1)).toThrow(RangeError)
    expect(() => getNpdLimitStatus(100, 0)).toThrow(RangeError)
  })
})

describe('nextNpdPaymentDate', () => {
  it('до 28-го — в этом месяце', () => {
    expect(nextNpdPaymentDate(new Date('2026-10-17T05:00:00Z'))).toBe('2026-10-28')
  })

  it('28-го — сегодня', () => {
    expect(nextNpdPaymentDate(new Date('2026-10-28T05:00:00Z'))).toBe('2026-10-28')
  })

  it('после 28-го — в следующем месяце, с переходом через год', () => {
    expect(nextNpdPaymentDate(new Date('2026-10-29T05:00:00Z'))).toBe('2026-11-28')
    expect(nextNpdPaymentDate(new Date('2026-12-29T05:00:00Z'))).toBe('2027-01-28')
  })
})
