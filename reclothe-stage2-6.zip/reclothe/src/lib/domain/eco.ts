import { ECO_CO2_KG_PER_KG, ECO_WATER_LITERS_PER_KG } from '@/lib/domain/catalog'

/**
 * Эко-эффект: на каждый килограмм спасённого текстиля — 2 700 л воды и 10 кг CO₂.
 * Вес берётся из вещей-доноров заказов клиента.
 */
export interface EcoMetrics {
  textileSavedKg: number
  waterSavedLiters: number
  co2PreventedKg: number
}

export const EMPTY_ECO_METRICS: EcoMetrics = {
  textileSavedKg: 0,
  waterSavedLiters: 0,
  co2PreventedKg: 0,
}

export function calcEcoMetrics(donorWeightKg: number): EcoMetrics {
  if (!Number.isFinite(donorWeightKg) || donorWeightKg < 0) {
    throw new RangeError(
      `Вес вещей-доноров должен быть конечным числом ≥ 0, получено: ${donorWeightKg}`,
    )
  }
  const kg = Math.round(donorWeightKg * 1000) / 1000
  return {
    textileSavedKg: kg,
    waterSavedLiters: Math.round(kg * ECO_WATER_LITERS_PER_KG),
    co2PreventedKg: Math.round(kg * ECO_CO2_KG_PER_KG * 10) / 10,
  }
}

export function sumEcoMetrics(items: readonly EcoMetrics[]): EcoMetrics {
  return items.reduce<EcoMetrics>(
    (total, item) => ({
      textileSavedKg: total.textileSavedKg + item.textileSavedKg,
      waterSavedLiters: total.waterSavedLiters + item.waterSavedLiters,
      co2PreventedKg: total.co2PreventedKg + item.co2PreventedKg,
    }),
    EMPTY_ECO_METRICS,
  )
}

/** Вехи для шкалы прогресса: следующая цель по спасённым килограммам. */
const MILESTONES_KG = [5, 10, 25, 50, 100, 250, 500, 1000] as const

export function nextMilestoneKg(kg: number): number {
  return MILESTONES_KG.find((milestone) => milestone > kg) ?? Math.ceil((kg + 1) / 500) * 500
}
