import { STOCK_ITEMS, getBaseService } from '@/lib/domain/catalog'
import type { Order, Payment, Service, ServiceOverride } from '@/lib/domain/types'
import { toDateString } from '@/lib/date'

/** Услуга с учётом правок тарифов из «Настроек». */
export function resolveService(
  serviceId: string,
  overrides: Readonly<Record<string, ServiceOverride>>,
): Service | undefined {
  const base = getBaseService(serviceId)
  if (!base) return undefined
  const override = overrides[serviceId]
  if (!override) return base
  return {
    ...base,
    masterRate: override.masterRate ?? base.masterRate,
    clientPrice: override.clientPrice ?? base.clientPrice,
  }
}

/** Текущие ставки услуги с учётом правок — «снимок» тарифа для нового заказа. */
export function snapshotTariff(
  serviceId: string,
  overrides: Readonly<Record<string, ServiceOverride>>,
): { masterRate: number; clientPrice: number } | undefined {
  const service = resolveService(serviceId, overrides)
  return service ? { masterRate: service.masterRate, clientPrice: service.clientPrice } : undefined
}

export function totalPaid(payments: readonly Payment[]): number {
  return payments.reduce((total, payment) => total + payment.amount, 0)
}

export type PaymentStatus = 'unpaid' | 'advance' | 'paid'

export function paymentStatus(paid: number, price: number): PaymentStatus {
  if (paid <= 0) return 'unpaid'
  if (paid >= price) return 'paid'
  return 'advance'
}

export const PAYMENT_STATUS_LABELS: Record<PaymentStatus, string> = {
  unpaid: 'Не оплачен',
  advance: 'Аванс внесён',
  paid: 'Оплачен полностью',
}

export type OrderStatus = 'in-progress' | 'ready' | 'overdue' | 'cancelled'

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  'in-progress': 'В работе',
  ready: 'Готово',
  overdue: 'Просрочен',
  cancelled: 'Отменён',
}

export function orderStatus(order: Pick<Order, 'state' | 'completedAt' | 'deadline'>, today: string): OrderStatus {
  if (order.state === 'cancelled') return 'cancelled'
  if (order.completedAt !== null) return 'ready'
  if (order.deadline < today) return 'overdue'
  return 'in-progress'
}

/** Список складских позиций — для форм и справочников. */
export const STOCK_ITEM_IDS: readonly string[] = STOCK_ITEMS.map((item) => item.id)

/** «RC-2026-0007» — год берётся из даты создания заказа. */
export function formatOrderNumber(createdAt: string, sequence: number): string {
  const year = toDateString(new Date(createdAt)).slice(0, 4)
  return `RC-${year}-${String(sequence).padStart(4, '0')}`
}

export function formatDonorCode(sequence: number): string {
  return `DN-${String(sequence).padStart(4, '0')}`
}
