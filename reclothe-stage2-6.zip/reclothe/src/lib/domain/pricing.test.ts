import { describe, expect, it } from 'vitest'

import { getBaseService } from '@/lib/domain/catalog'
import { calcPricing, emptyOptions, normHours, sanitizeQty } from '@/lib/domain/pricing'
import type { OrderOptions } from '@/lib/domain/types'

function service(id: string) {
  const found = getBaseService(id)
  if (!found) throw new Error(`нет услуги ${id}`)
  return found
}

describe('calcPricing — примеры из бизнес-плана (раздел 7)', () => {
  it('7.4: куртка пэчворк, К сложности 1,8 → 2 800 × 1,8 = 5 040 ₽', () => {
    const pricing = calcPricing({
      service: service('1.2'),
      complexityId: 'high',
      materialId: 'cotton',
      options: emptyOptions(),
    })
    expect(pricing.masterBase).toBe(5040)
    expect(pricing.masterTotal).toBe(5040)
  })

  it('7.5: кожаная куртка 3 500 × 1,5 × 1,5 = 7 875 ₽', () => {
    const pricing = calcPricing({
      service: service('1.10'),
      complexityId: 'medium',
      materialId: 'leather',
      options: emptyOptions(),
    })
    expect(pricing.masterBase).toBe(7875)
  })

  it('7.7, пример 1: куртка из денима с утеплением, фурнитурой и срочностью 48 ч = 11 372 ₽', () => {
    const options: OrderOptions = {
      ...emptyOptions(),
      ops: { insulation: 1, eyelet: 10, 'pocket-flap': 4, 'zip-double': 1 },
      urgency: '48h',
    }
    const pricing = calcPricing({
      service: service('1.2'),
      complexityId: 'high',
      materialId: 'denim',
      options,
    })
    expect(pricing.masterBase).toBe(6048)
    expect(pricing.masterOps).toBe(2700)
    expect(pricing.masterUrgency).toBe(2624)
    expect(pricing.masterTotal).toBe(11372)
  })
})

describe('calcPricing — цена для клиента', () => {
  it('базовая цена клиента не зависит от сложности и материала', () => {
    const base = { service: service('2.1'), options: emptyOptions() }
    const simple = calcPricing({ ...base, complexityId: 'base', materialId: 'cotton' })
    const hard = calcPricing({ ...base, complexityId: 'extreme', materialId: 'fur' })
    expect(simple.clientTotal).toBe(4200)
    expect(hard.clientTotal).toBe(4200)
    expect(hard.masterTotal).toBeGreaterThan(simple.masterTotal)
  })

  it('заданные заказчиком цены: пэчворк 6 500, худи-гибрид 4 200, корсет 5 500', () => {
    expect(service('1.2').clientPrice).toBe(6500)
    expect(service('2.1').clientPrice).toBe(4200)
    expect(service('3.8').clientPrice).toBe(5500)
  })

  it('Art-опции входят в цену клиента, но не в оплату мастеру', () => {
    const pricing = calcPricing({
      service: service('1.2'),
      complexityId: 'base',
      materialId: 'cotton',
      options: { ...emptyOptions(), art: { 'paint-complex': 1, holes: 3 } },
    })
    expect(pricing.clientArt).toBe(3000 + 600)
    expect(pricing.clientTotal).toBe(6500 + 3600)
    expect(pricing.masterTotal).toBe(2800)
  })

  it('спецдоплаты идут и клиенту, и мастеру', () => {
    const options: OrderOptions = {
      ...emptyOptions(),
      corset: true,
      lining: true,
      handSeamsMeters: 2,
      beads: true,
    }
    const pricing = calcPricing({
      service: service('3.8'),
      complexityId: 'base',
      materialId: 'cotton',
      options,
    })
    const special = 800 + 600 + 2 * 300 + 2000
    expect(pricing.clientSpecial).toBe(special)
    expect(pricing.masterSpecial).toBe(special)
    expect(pricing.clientTotal).toBe(5500 + special)
    expect(pricing.masterTotal).toBe(2500 + special)
  })

  it('срочность: +15% / +30% / +50% к сумме «база + доп. операции»', () => {
    const run = (urgency: OrderOptions['urgency']) =>
      calcPricing({
        service: service('4.3'),
        complexityId: 'base',
        materialId: 'cotton',
        options: { ...emptyOptions(), urgency },
      })
    expect(run('none').clientTotal).toBe(1900)
    expect(run('72h').clientTotal).toBe(1900 + 285)
    expect(run('48h').clientTotal).toBe(1900 + 570)
    expect(run('24h').clientTotal).toBe(1900 + 950)
    expect(run('24h').masterTotal).toBe(800 + 400)
  })

  it('люверсы, кнопки и хольнитены — по 50 ₽ за штуку', () => {
    const pricing = calcPricing({
      service: service('1.1'),
      complexityId: 'base',
      materialId: 'cotton',
      options: { ...emptyOptions(), ops: { eyelet: 4, snap: 2, rivet: 6 } },
    })
    expect(pricing.clientOps).toBe(12 * 50)
  })

  it('метры: окантовка 200 ₽/м и зигзаг 100 ₽/м', () => {
    const pricing = calcPricing({
      service: service('1.1'),
      complexityId: 'base',
      materialId: 'cotton',
      options: { ...emptyOptions(), ops: { bias: 2.5, zigzag: 3 } },
    })
    expect(pricing.clientOps).toBe(500 + 300)
  })

  it('маржа: отрицательная, если оплата мастеру выше цены клиента', () => {
    const pricing = calcPricing({
      service: service('1.10'),
      complexityId: 'extreme',
      materialId: 'fur',
      options: emptyOptions(),
    })
    expect(pricing.margin).toBeLessThan(0)
    expect(pricing.marginFraction).toBeLessThan(0)
  })

  it('игнорирует неизвестные опции и нулевое количество', () => {
    const pricing = calcPricing({
      service: service('1.1'),
      complexityId: 'base',
      materialId: 'cotton',
      options: { ...emptyOptions(), ops: { nope: 3, eyelet: 0, snap: -2 } },
    })
    expect(pricing.clientOps).toBe(0)
  })
})

describe('вспомогательное', () => {
  it('sanitizeQty отбрасывает мусор', () => {
    expect(sanitizeQty(Number.NaN)).toBe(0)
    expect(sanitizeQty(-1)).toBe(0)
    expect(sanitizeQty(2.456)).toBe(2.46)
  })

  it('норма времени = верхняя граница плана + часы доп. операций', () => {
    const pricing = calcPricing({
      service: service('1.2'),
      complexityId: 'base',
      materialId: 'cotton',
      options: { ...emptyOptions(), ops: { insulation: 1 } },
    })
    expect(pricing.hoursMax).toBe(16)
    expect(pricing.extraHours).toBe(0.5)
    expect(normHours(pricing)).toBe(16.5)
  })
})
