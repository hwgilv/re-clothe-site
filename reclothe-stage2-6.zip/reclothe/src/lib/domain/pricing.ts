import {
  ART_OPTIONS,
  COMPLEXITY_LEVELS,
  EXTRA_OPS,
  MATERIALS,
  SPECIAL_SURCHARGES,
  URGENCY_LEVELS,
} from '@/lib/domain/catalog'
import type {
  ComplexityId,
  MaterialId,
  OrderOptions,
  Service,
  UrgencyId,
} from '@/lib/domain/types'

/**
 * Калькулятор заказа (раздел 7 бизнес-плана и ТЗ заказчика).
 *
 *   Оплата мастеру = ставка × К_сложности × К_материала
 *                    + доп. операции + спецдоплаты (+ срочность)
 *   Цена клиенту   = базовая цена клиента
 *                    + доп. операции + Art-опции + спецдоплаты (+ срочность)
 *
 * Срочность считается в процентах от суммы «база + доп. операции», как в рабочем
 * примере 1 из раздела 7.7 плана: (6 048 + 2 700) × 1,3 = 11 372 ₽.
 * Art-опции входят только в цену клиента (как в ТЗ): их часто делает художник,
 * которому платят отдельно (пример 3 из 7.7).
 */

const OPS_BY_ID = new Map(EXTRA_OPS.map((option) => [option.id, option]))
const ART_BY_ID = new Map(ART_OPTIONS.map((option) => [option.id, option]))
const OPS_BY_ID_MINUTES = new Map(EXTRA_OPS.map((option) => [option.id, option.minutes]))
const ART_BY_ID_MINUTES = new Map(ART_OPTIONS.map((option) => [option.id, option.minutes]))

export function getComplexityK(id: ComplexityId): number {
  const level = COMPLEXITY_LEVELS.find((item) => item.id === id)
  if (!level) throw new RangeError(`Неизвестная сложность: ${id}`)
  return level.k
}

export function getMaterialK(id: MaterialId): number {
  const material = MATERIALS.find((item) => item.id === id)
  if (!material) throw new RangeError(`Неизвестный материал: ${id}`)
  return material.k
}

export function getUrgencyFraction(id: UrgencyId): number {
  const urgency = URGENCY_LEVELS.find((item) => item.id === id)
  if (!urgency) throw new RangeError(`Неизвестная срочность: ${id}`)
  return urgency.fraction
}

export function emptyOptions(): OrderOptions {
  return {
    ops: {},
    art: {},
    urgency: 'none',
    corset: false,
    lining: false,
    handSeamsMeters: 0,
    beads: false,
  }
}

/** Количество: конечное, неотрицательное, до сотых. */
export function sanitizeQty(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 0
  return Math.round(value * 100) / 100
}

export interface PriceLine {
  key: string
  label: string
  qty: number
  unitPrice: number
  amount: number
}

export interface PricingInput {
  service: Service
  complexityId: ComplexityId
  materialId: MaterialId
  options: OrderOptions
}

export interface Pricing {
  kComplexity: number
  kMaterial: number

  masterBase: number
  masterOps: number
  masterSpecial: number
  masterUrgency: number
  masterTotal: number

  clientBase: number
  clientOps: number
  clientArt: number
  clientSpecial: number
  clientUrgency: number
  clientTotal: number

  /** Прибыль студии до материалов и налога: цена клиента − оплата мастеру. */
  margin: number
  /** Доля маржи в цене клиента (может быть отрицательной). */
  marginFraction: number

  hoursMin: number
  hoursMax: number
  /** Дополнительные часы от выбранных операций и Art-опций. */
  extraHours: number

  masterLines: PriceLine[]
  clientLines: PriceLine[]
}

function optionLines(
  quantities: Record<string, number>,
  lookup: ReadonlyMap<string, { id: string; label: string; price: number }>,
): PriceLine[] {
  const lines: PriceLine[] = []
  for (const [id, rawQty] of Object.entries(quantities)) {
    const option = lookup.get(id)
    const qty = sanitizeQty(rawQty)
    if (!option || qty === 0) continue
    lines.push({
      key: id,
      label: option.label,
      qty,
      unitPrice: option.price,
      amount: Math.round(option.price * qty),
    })
  }
  return lines
}

function sum(lines: readonly PriceLine[]): number {
  return lines.reduce((total, line) => total + line.amount, 0)
}

function specialLines(options: OrderOptions): PriceLine[] {
  const lines: PriceLine[] = []
  if (options.corset) {
    lines.push({
      key: 'corset',
      label: SPECIAL_SURCHARGES.corset.label,
      qty: 1,
      unitPrice: SPECIAL_SURCHARGES.corset.price,
      amount: SPECIAL_SURCHARGES.corset.price,
    })
  }
  if (options.lining) {
    lines.push({
      key: 'lining',
      label: SPECIAL_SURCHARGES.lining.label,
      qty: 1,
      unitPrice: SPECIAL_SURCHARGES.lining.price,
      amount: SPECIAL_SURCHARGES.lining.price,
    })
  }
  const seams = sanitizeQty(options.handSeamsMeters)
  if (seams > 0) {
    lines.push({
      key: 'hand-seams',
      label: `${SPECIAL_SURCHARGES.handSeamsPerMeter.label} (м)`,
      qty: seams,
      unitPrice: SPECIAL_SURCHARGES.handSeamsPerMeter.price,
      amount: Math.round(SPECIAL_SURCHARGES.handSeamsPerMeter.price * seams),
    })
  }
  if (options.beads) {
    lines.push({
      key: 'beads',
      label: SPECIAL_SURCHARGES.beads.label,
      qty: 1,
      unitPrice: SPECIAL_SURCHARGES.beads.price,
      amount: SPECIAL_SURCHARGES.beads.price,
    })
  }
  return lines
}

export function calcPricing(input: PricingInput): Pricing {
  const { service, complexityId, materialId, options } = input
  const kComplexity = getComplexityK(complexityId)
  const kMaterial = getMaterialK(materialId)
  const urgency = getUrgencyFraction(options.urgency)

  const opLines = optionLines(options.ops, OPS_BY_ID)
  const artLines = optionLines(options.art, ART_BY_ID)
  const special = specialLines(options)

  const opsTotal = sum(opLines)
  const artTotal = sum(artLines)
  const specialTotal = sum(special)

  const masterBase = Math.round(service.masterRate * kComplexity * kMaterial)
  const masterUrgency = Math.round((masterBase + opsTotal) * urgency)
  const masterTotal = masterBase + opsTotal + specialTotal + masterUrgency

  const clientBase = service.clientPrice
  const clientUrgency = Math.round((clientBase + opsTotal + artTotal) * urgency)
  const clientTotal = clientBase + opsTotal + artTotal + specialTotal + clientUrgency

  const urgencyLabel = URGENCY_LEVELS.find((item) => item.id === options.urgency)?.label ?? ''

  const masterLines: PriceLine[] = [
    {
      key: 'base',
      label: `Ставка ${service.masterRate.toLocaleString('ru-RU')} ₽ × ${kComplexity} × ${kMaterial}`,
      qty: 1,
      unitPrice: masterBase,
      amount: masterBase,
    },
    ...opLines,
    ...special,
  ]
  if (masterUrgency > 0) {
    masterLines.push({
      key: 'urgency',
      label: `Срочность (${urgencyLabel})`,
      qty: 1,
      unitPrice: masterUrgency,
      amount: masterUrgency,
    })
  }

  const clientLines: PriceLine[] = [
    { key: 'base', label: service.name, qty: 1, unitPrice: clientBase, amount: clientBase },
    ...opLines,
    ...artLines,
    ...special,
  ]
  if (clientUrgency > 0) {
    clientLines.push({
      key: 'urgency',
      label: `Срочность (${urgencyLabel})`,
      qty: 1,
      unitPrice: clientUrgency,
      amount: clientUrgency,
    })
  }

  const extraMinutes =
    opLines.reduce((total, line) => total + (OPS_BY_ID_MINUTES.get(line.key) ?? 0) * line.qty, 0) +
    artLines.reduce((total, line) => total + (ART_BY_ID_MINUTES.get(line.key) ?? 0) * line.qty, 0)

  const margin = clientTotal - masterTotal

  return {
    kComplexity,
    kMaterial,
    masterBase,
    masterOps: opsTotal,
    masterSpecial: specialTotal,
    masterUrgency,
    masterTotal,
    clientBase,
    clientOps: opsTotal,
    clientArt: artTotal,
    clientSpecial: specialTotal,
    clientUrgency,
    clientTotal,
    margin,
    marginFraction: clientTotal > 0 ? margin / clientTotal : 0,
    hoursMin: service.hoursMin,
    hoursMax: service.hoursMax,
    extraHours: Math.round((extraMinutes / 60) * 10) / 10,
    masterLines,
    clientLines,
  }
}

/** Норма времени для планирования — верхняя граница из плана плюс доп. часы. */
export function normHours(pricing: Pick<Pricing, 'hoursMax' | 'extraHours'>): number {
  return Math.round((pricing.hoursMax + pricing.extraHours) * 10) / 10
}
