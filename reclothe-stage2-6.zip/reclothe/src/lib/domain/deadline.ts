import { calendarDaysBetween } from '@/lib/date'

/** За сколько дней до дедлайна заказ подсвечивается жёлтым. */
export const DEADLINE_WARNING_DAYS = 3

/** ok — зелёный, warning — жёлтый, danger — красный (сегодня или просрочен). */
export type DeadlineTone = 'ok' | 'warning' | 'danger'

export interface DeadlineStatus {
  /** Календарных дней до дедлайна в поясе студии; отрицательное — просрочен. */
  daysLeft: number
  tone: DeadlineTone
  overdue: boolean
  label: string
}

export function formatDeadlineLabel(daysLeft: number): string {
  if (daysLeft < 0) return `Просрочен на ${Math.abs(daysLeft)} дн.`
  if (daysLeft === 0) return 'Сегодня'
  if (daysLeft === 1) return 'Завтра'
  return `Через ${daysLeft} дн.`
}

export function getDeadlineStatus(deadline: Date, now: Date = new Date()): DeadlineStatus {
  const daysLeft = calendarDaysBetween(now, deadline)

  let tone: DeadlineTone
  if (daysLeft <= 0) tone = 'danger'
  else if (daysLeft <= DEADLINE_WARNING_DAYS) tone = 'warning'
  else tone = 'ok'

  return { daysLeft, tone, overdue: daysLeft < 0, label: formatDeadlineLabel(daysLeft) }
}
