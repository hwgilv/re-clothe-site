import type { Client } from '@/lib/domain/types'

type NameParts = Pick<Client, 'lastName' | 'firstName' | 'middleName'>

export function fullName(client: NameParts): string {
  return [client.lastName, client.firstName, client.middleName]
    .map((part) => part.trim())
    .filter(Boolean)
    .join(' ')
}

/** «Иванова М. П.» */
export function shortName(client: NameParts): string {
  const initials = [client.firstName, client.middleName]
    .map((part) => part.trim().charAt(0).toUpperCase())
    .filter(Boolean)
    .map((letter) => `${letter}.`)
    .join(' ')
  return [client.lastName.trim(), initials].filter(Boolean).join(' ')
}

export function initialsOf(text: string): string {
  const letters = text
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
  return letters.join('')
}

/** Только цифры; российский номер с 8 в начале приводится к 7. */
export function phoneDigits(phone: string): string {
  const digits = phone.replace(/\D/g, '')
  if (digits.length === 11 && digits.startsWith('8')) return `7${digits.slice(1)}`
  if (digits.length === 10) return `7${digits}`
  return digits
}

export function isValidPhone(phone: string): boolean {
  const digits = phoneDigits(phone)
  return digits.length === 11 && digits.startsWith('7')
}

/** 79039095763 → «+7 903 909-57-63». Неполные номера возвращаются как есть. */
export function formatPhone(phone: string): string {
  const digits = phoneDigits(phone)
  if (digits.length !== 11) return phone
  return `+7 ${digits.slice(1, 4)} ${digits.slice(4, 7)}-${digits.slice(7, 9)}-${digits.slice(9, 11)}`
}

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase()
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())
}
