import { LOYALTY_TIERS, RUB_PER_COIN } from '@/lib/domain/catalog'
import type { TierInfo } from '@/lib/domain/catalog'
import type { LoyaltyTierId } from '@/lib/domain/types'

/**
 * Статус карты по сумме покупок клиента (оплаченное по его заказам):
 * Бронзовая ≤ 10 000 · Серебряная 10 001–25 000 · Золотая 25 001–50 000 ·
 * Платиновая 50 001–100 000 · Бриллиантовая > 100 000.
 */
export function tierForSpend(spend: number): TierInfo {
  const amount = Number.isFinite(spend) && spend > 0 ? spend : 0
  const found = LOYALTY_TIERS.find(
    (tier) => amount > tier.above && (tier.upTo === null || amount <= tier.upTo),
  )
  // Список покрывает всю числовую ось, но тип этого не знает.
  return found ?? (LOYALTY_TIERS[0] as TierInfo)
}

export function getTier(id: LoyaltyTierId): TierInfo {
  const tier = LOYALTY_TIERS.find((item) => item.id === id)
  if (!tier) throw new RangeError(`Неизвестный статус карты: ${id}`)
  return tier
}

/** 1 RE-coin за каждые полные 10 ₽ в чеке. */
export function coinsForSpend(spend: number): number {
  if (!Number.isFinite(spend) || spend <= 0) return 0
  return Math.floor(spend / RUB_PER_COIN)
}

export interface TierProgress {
  next: TierInfo | null
  /** Сколько ещё потратить до следующего статуса, ₽. */
  remaining: number
  /** Доля пути от начала текущего статуса до следующего, 0…1. */
  fraction: number
}

export function tierProgress(spend: number): TierProgress {
  const current = tierForSpend(spend)
  const index = LOYALTY_TIERS.findIndex((tier) => tier.id === current.id)
  const next = LOYALTY_TIERS[index + 1] ?? null
  if (!next) return { next: null, remaining: 0, fraction: 1 }

  const start = Math.max(0, current.above)
  const end = current.upTo ?? start
  const span = Math.max(1, end - start)
  return {
    next,
    // Следующий статус начинается со СЛЕДУЮЩЕГО рубля после границы.
    remaining: Math.max(0, end + 1 - Math.max(0, spend)),
    fraction: Math.min(1, Math.max(0, (spend - start) / span)),
  }
}
