import { phoneDigits } from '@/lib/domain/client'
import type { Client, MessengerId } from '@/lib/domain/types'

/** Шаблон первого сообщения новому клиенту (ТЗ, модуль 4). */
export function leadMessageTemplate(firstName: string): string {
  const name = firstName.trim() || 'клиент'
  return `Добрый день, ${name}! Я администратор апсайклинг-студии RE:clothe. Получили вашу заявку на пересборку вещей. Подскажите, пожалуйста, в какое время вам будет удобно провести онлайн-консультацию для обсуждения дизайн-эскиза и снятия мерок?`
}

export interface MessengerLink {
  id: MessengerId
  url: string
  /** Можно ли подставить текст прямо в ссылку (иначе он копируется в буфер обмена). */
  prefilled: boolean
}

/**
 * Официальные веб-ссылки мессенджеров.
 * WhatsApp принимает текст в параметре `text`. Telegram и VK не позволяют подставить текст
 * в чат по номеру телефона — для них шаблон копируется в буфер обмена.
 */
export function buildMessengerLink(
  id: MessengerId,
  client: Pick<Client, 'phone' | 'lastName' | 'firstName'>,
  message: string,
): MessengerLink {
  const digits = phoneDigits(client.phone)
  switch (id) {
    case 'whatsapp':
      return {
        id,
        url: `https://wa.me/${digits}?text=${encodeURIComponent(message)}`,
        prefilled: true,
      }
    case 'telegram':
      return { id, url: `https://t.me/+${digits}`, prefilled: false }
    case 'vk': {
      const query = encodeURIComponent(`${client.firstName} ${client.lastName}`.trim())
      return {
        id,
        url: `https://vk.com/search?c%5Bsection%5D=people&c%5Bq%5D=${query}`,
        prefilled: false,
      }
    }
    case 'call':
      return { id, url: `tel:+${digits}`, prefilled: false }
  }
}
