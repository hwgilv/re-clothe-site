import { describe, expect, it } from 'vitest'

import { buildMessengerLink, leadMessageTemplate } from '@/lib/domain/messenger'

describe('шаблон сообщения', () => {
  it('подставляет имя клиента и содержит ключевые фразы ТЗ', () => {
    const text = leadMessageTemplate('Мария')
    expect(text).toContain('Добрый день, Мария!')
    expect(text).toContain('администратор апсайклинг-студии RE:clothe')
    expect(text).toContain('онлайн-консультацию')
  })
})

describe('buildMessengerLink', () => {
  const client = { phone: '+7 913 000-00-01', firstName: 'Мария', lastName: 'Иванова' }
  it('WhatsApp подставляет текст прямо в ссылку', () => {
    const link = buildMessengerLink('whatsapp', client, 'Привет, мир')
    expect(link.url).toBe('https://wa.me/79130000001?text=%D0%9F%D1%80%D0%B8%D0%B2%D0%B5%D1%82%2C%20%D0%BC%D0%B8%D1%80')
    expect(link.prefilled).toBe(true)
  })
  it('Telegram открывает чат по номеру, текст копируется отдельно', () => {
    const link = buildMessengerLink('telegram', client, 'x')
    expect(link.url).toBe('https://t.me/+79130000001')
    expect(link.prefilled).toBe(false)
  })
  it('VK ищет человека по имени; звонок — tel:', () => {
    expect(buildMessengerLink('vk', client, 'x').url).toContain('vk.com/search')
    expect(buildMessengerLink('call', client, 'x').url).toBe('tel:+79130000001')
  })
})
