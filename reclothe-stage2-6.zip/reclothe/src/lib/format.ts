import { APP_LOCALE, STUDIO_TIME_ZONE } from '@/config/app'

// Создание Intl-форматтеров относительно дорогое, а на дашборде их десятки вызовов — кешируем.
const numberFormatCache = new Map<string, Intl.NumberFormat>()

function getNumberFormat(locale: string, options: Intl.NumberFormatOptions): Intl.NumberFormat {
  const key = `${locale}|${JSON.stringify(options)}`
  let formatter = numberFormatCache.get(key)
  if (!formatter) {
    formatter = new Intl.NumberFormat(locale, options)
    numberFormatCache.set(key, formatter)
  }
  return formatter
}

/** 245000 → «245 000 ₽» (копейки не показываем). */
export function formatRub(amount: number, locale: string = APP_LOCALE): string {
  return getNumberFormat(locale, {
    style: 'currency',
    currency: 'RUB',
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatNumber(
  value: number,
  fractionDigits = 0,
  locale: string = APP_LOCALE,
): string {
  return getNumberFormat(locale, {
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  }).format(value)
}

/** Принимает долю (0.724), а не проценты: 0.724 → «72,4 %». */
export function formatPercent(
  fraction: number,
  fractionDigits = 0,
  locale: string = APP_LOCALE,
): string {
  return getNumberFormat(locale, {
    style: 'percent',
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  }).format(fraction)
}

/** Со знаком для ненулевых значений: 0.12 → «+12 %», -0.05 → «−5 %», 0 → «0 %». */
export function formatSignedPercent(
  fraction: number,
  fractionDigits = 0,
  locale: string = APP_LOCALE,
): string {
  return getNumberFormat(locale, {
    style: 'percent',
    signDisplay: 'exceptZero',
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  }).format(fraction)
}

/** Компактные рубли для оси графика: 150000 → «150 тыс. ₽», 1200000 → «1,2 млн ₽». */
export function formatRubCompact(amount: number, locale: string = APP_LOCALE): string {
  return getNumberFormat(locale, {
    style: 'currency',
    currency: 'RUB',
    notation: 'compact',
    // Для валюты минимум знаков по умолчанию 2 — без явного нуля получилось бы «150,0 тыс. ₽».
    minimumFractionDigits: 0,
    maximumFractionDigits: 1,
  }).format(amount)
}

/** «октябрь 2026 г.» — месяц задаётся первым числом в UTC. */
export function formatMonthYear(date: Date, locale: string = APP_LOCALE): string {
  return new Intl.DateTimeFormat(locale, {
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(date)
}

/** «суббота, 17 октября 2026 г.» */
export function formatDateLong(
  date: Date,
  timeZone: string = STUDIO_TIME_ZONE,
  locale: string = APP_LOCALE,
): string {
  return new Intl.DateTimeFormat(locale, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone,
  }).format(date)
}

/** «17.10.2026» */
export function formatDate(
  date: Date,
  timeZone: string = STUDIO_TIME_ZONE,
  locale: string = APP_LOCALE,
): string {
  return new Intl.DateTimeFormat(locale, {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    timeZone,
  }).format(date)
}

/** Короткое название месяца: «окт.». Для оси графиков; даты передавайте как 1-е число в UTC. */
export function formatMonthShort(date: Date, locale: string = APP_LOCALE): string {
  return new Intl.DateTimeFormat(locale, { month: 'short', timeZone: 'UTC' }).format(date)
}

/** «2 часа назад», «вчера». Меньше 45 секунд — «только что». */
export function formatTimeAgo(
  date: Date,
  now: Date = new Date(),
  locale: string = APP_LOCALE,
): string {
  const diffSeconds = Math.round((date.getTime() - now.getTime()) / 1000)
  const abs = Math.abs(diffSeconds)
  if (abs < 45) return 'только что'

  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' })
  if (abs < 3600) return rtf.format(Math.round(diffSeconds / 60), 'minute')
  if (abs < 86_400) return rtf.format(Math.round(diffSeconds / 3600), 'hour')
  return rtf.format(Math.round(diffSeconds / 86_400), 'day')
}

/** «2026-10-18T05:36:00.000Z» → «18.10.2026» в поясе студии. */
export function formatIsoDate(iso: string): string {
  const date = new Date(iso)
  return Number.isNaN(date.getTime()) ? iso : formatDate(date)
}

/** «18.10.2026, 12:36» в поясе студии. */
export function formatIsoDateTime(iso: string): string {
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return iso
  return new Intl.DateTimeFormat(APP_LOCALE, {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: STUDIO_TIME_ZONE,
  }).format(date)
}

/** «1 день», «2 дня», «5 дней». */
export function pluralDays(count: number): string {
  const n = Math.abs(Math.round(count))
  const mod10 = n % 10
  const mod100 = n % 100
  if (mod10 === 1 && mod100 !== 11) return `${n} день`
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return `${n} дня`
  return `${n} дней`
}
