import { describe, expect, it } from 'vitest'

import { addDays, calendarDaysBetween, getZonedDateParts } from './date'

describe('getZonedDateParts', () => {
  it('переводит момент времени в календарную дату пояса студии (UTC+7)', () => {
    // 20:00 UTC 17 октября = 03:00 18 октября в Новокузнецке
    const parts = getZonedDateParts(new Date('2026-10-17T20:00:00Z'), 'Asia/Novokuznetsk')
    expect(parts).toEqual({ year: 2026, month: 10, day: 18 })
  })
})

describe('calendarDaysBetween', () => {
  it('считает по календарю студии, а не по UTC', () => {
    // В UTC это разные даты (17 и 18), но в Новокузнецке оба момента — 18 октября.
    const from = new Date('2026-10-17T20:00:00Z')
    const to = new Date('2026-10-18T01:00:00Z')
    expect(calendarDaysBetween(from, to, 'Asia/Novokuznetsk')).toBe(0)
  })

  it('возвращает положительное число для будущего и отрицательное для прошлого', () => {
    const now = new Date('2026-10-17T05:00:00Z')
    expect(calendarDaysBetween(now, new Date('2026-10-20T05:00:00Z'))).toBe(3)
    expect(calendarDaysBetween(now, new Date('2026-10-15T05:00:00Z'))).toBe(-2)
  })

  it('корректно переходит через границу месяца и года', () => {
    const from = new Date('2026-12-30T05:00:00Z')
    const to = new Date('2027-01-02T05:00:00Z')
    expect(calendarDaysBetween(from, to)).toBe(3)
  })
})

describe('addDays', () => {
  it('прибавляет сутки', () => {
    const base = new Date('2026-10-17T05:00:00Z')
    expect(addDays(base, 2).toISOString()).toBe('2026-10-19T05:00:00.000Z')
    expect(addDays(base, -1).toISOString()).toBe('2026-10-16T05:00:00.000Z')
  })
})
