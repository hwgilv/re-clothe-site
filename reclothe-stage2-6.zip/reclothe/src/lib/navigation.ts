/**
 * Чистая логика навигации (без иконок и React) — чтобы её можно было тестировать в Vitest.
 * Данные меню с иконками лежат в src/config/navigation.ts.
 */

export interface HrefItem {
  href: string
}

/**
 * Какой пункт меню подсвечивать для текущего пути: побеждает самый длинный подходящий href.
 * Так /production/queue подсвечивает «Очередь цеха», а не «Производство», а «/» — только на главной.
 */
export function getActiveHref(pathname: string, items: readonly HrefItem[]): string | null {
  let best: string | null = null

  for (const { href } of items) {
    const matches =
      href === '/' ? pathname === '/' : pathname === href || pathname.startsWith(`${href}/`)
    if (matches && (best === null || href.length > best.length)) best = href
  }

  return best
}

export interface HotkeyBinding {
  /** Первая клавиша последовательности: «g» (перейти) или «n» (создать). */
  prefix: string
  /** Вторая клавиша. */
  key: string
  href: string
}

/**
 * Карта «g d» → «/». Бросает исключение при дубликате: конфликт горячих клавиш
 * должен ронять приложение на старте, а не молча перекрывать один пункт другим.
 */
export function buildHotkeyMap(bindings: readonly HotkeyBinding[]): Map<string, string> {
  const map = new Map<string, string>()

  for (const { prefix, key, href } of bindings) {
    const sequence = `${prefix} ${key}`
    const existing = map.get(sequence)
    if (existing !== undefined) {
      throw new Error(`Конфликт горячих клавиш «${sequence}»: ${existing} и ${href}`)
    }
    map.set(sequence, href)
  }

  return map
}

// Map, а не объект: для сегмента вроде "constructor" объект вернул бы функцию из прототипа.
const SEGMENT_LABELS = new Map<string, string>([
  ['clients', 'Клиенты'],
  ['orders', 'Заказы'],
  ['production', 'Производство'],
  ['documents', 'Документы'],
  ['inventory', 'Склад'],
  ['payroll', 'Бухгалтерия и ЗП'],
  ['finance', 'Финансы'],
  ['settings', 'Настройки'],
])

export interface Breadcrumb {
  label: string
  href: string
}

/** decodeURIComponent, который не бросает исключение на битой кодировке (%E0%A4%A). */
export function safeDecode(segment: string): string {
  try {
    return decodeURIComponent(segment)
  } catch {
    return segment
  }
}

/** Хлебные крошки по пути. Динамические сегменты (номер заказа, id) показываются как есть. */
export function buildBreadcrumbs(pathname: string): Breadcrumb[] {
  const segments = pathname.split('/').filter(Boolean)
  if (segments.length === 0) return [{ label: 'Дашборд', href: '/' }]

  return segments.map((segment, index) => ({
    label: SEGMENT_LABELS.get(segment) ?? safeDecode(segment),
    href: `/${segments.slice(0, index + 1).join('/')}`,
  }))
}
