import { clsx, type ClassValue } from 'clsx'
import { extendTailwindMerge } from 'tailwind-merge'

// Кастомный размер шрифта text-2xs нужно объяснить tailwind-merge,
// иначе он примет его за цвет текста и будет отбрасывать соседние классы.
const twMerge = extendTailwindMerge({
  extend: {
    classGroups: {
      'font-size': [{ text: ['2xs'] }],
    },
  },
})

/** Склеивает классы и разрешает конфликты Tailwind (последний побеждает). */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs))
}
