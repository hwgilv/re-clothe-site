import { describe, expect, it } from 'vitest'

import { buildBreadcrumbs, buildHotkeyMap, getActiveHref } from './navigation'

const ITEMS = [
  { href: '/' },
  { href: '/orders' },
  { href: '/production' },
  { href: '/production/queue' },
  { href: '/finance' },
]

describe('getActiveHref', () => {
  it('«/» подсвечивается только на главной', () => {
    expect(getActiveHref('/', ITEMS)).toBe('/')
    expect(getActiveHref('/orders', ITEMS)).toBe('/orders')
  })

  it('вложенные страницы подсвечивают родителя', () => {
    expect(getActiveHref('/orders/RC-2026-0042/production', ITEMS)).toBe('/orders')
  })

  it('побеждает самый специфичный пункт', () => {
    expect(getActiveHref('/production/queue', ITEMS)).toBe('/production/queue')
    expect(getActiveHref('/production', ITEMS)).toBe('/production')
  })

  it('не путает префиксы без разделителя', () => {
    expect(getActiveHref('/finance-archive', ITEMS)).toBeNull()
  })

  it('возвращает null для неизвестного пути', () => {
    expect(getActiveHref('/nowhere', ITEMS)).toBeNull()
  })
})

describe('buildHotkeyMap', () => {
  it('собирает карту последовательностей', () => {
    const map = buildHotkeyMap([
      { prefix: 'g', key: 'd', href: '/' },
      { prefix: 'n', key: 'o', href: '/orders/new' },
    ])
    expect(map.get('g d')).toBe('/')
    expect(map.get('n o')).toBe('/orders/new')
  })

  it('один и тот же ключ с разными префиксами — не конфликт', () => {
    expect(() =>
      buildHotkeyMap([
        { prefix: 'g', key: 'o', href: '/orders' },
        { prefix: 'n', key: 'o', href: '/orders/new' },
      ]),
    ).not.toThrow()
  })

  it('дубликат последовательности бросает ошибку', () => {
    expect(() =>
      buildHotkeyMap([
        { prefix: 'g', key: 'c', href: '/clients' },
        { prefix: 'g', key: 'c', href: '/reports' },
      ]),
    ).toThrow(Error)
  })
})

describe('buildBreadcrumbs', () => {
  it('главная — один пункт «Дашборд»', () => {
    expect(buildBreadcrumbs('/')).toEqual([{ label: 'Дашборд', href: '/' }])
  })

  it('переводит известные сегменты и накапливает href', () => {
    expect(buildBreadcrumbs('/payroll')).toEqual([{ label: 'Бухгалтерия и ЗП', href: '/payroll' }])
    expect(buildBreadcrumbs('/orders/o-1')).toEqual([
      { label: 'Заказы', href: '/orders' },
      { label: 'o-1', href: '/orders/o-1' },
    ])
  })

  it('динамический сегмент показывается как есть', () => {
    const crumbs = buildBreadcrumbs('/orders/RC-2026-0042/documents')
    expect(crumbs.map((crumb) => crumb.label)).toEqual(['Заказы', 'RC-2026-0042', 'Документы'])
  })

  it('сегмент вроде "constructor" не берёт значение из прототипа', () => {
    expect(buildBreadcrumbs('/orders/constructor')[1]?.label).toBe('constructor')
  })

  it('битая URL-кодировка не роняет функцию', () => {
    expect(buildBreadcrumbs('/orders/%E0%A4%A')[1]?.label).toBe('%E0%A4%A')
  })
})
