export const APP_NAME = 'RE:clothe'
export const APP_TAGLINE = 'CRM · ERP · Production Tracker'

/**
 * Локаль форматирования чисел/дат. Все форматтеры принимают locale параметром
 * с этим значением по умолчанию — задел под мультиязычность (ru/en, Этап 6).
 */
export const APP_LOCALE = 'ru-RU'

/**
 * Часовой пояс студии (Новокузнецк, UTC+7). Серверы Vercel работают в UTC,
 * поэтому «сегодня/завтра» для дедлайнов всегда считаем в поясе студии.
 */
export const STUDIO_TIME_ZONE = 'Asia/Novokuznetsk'
