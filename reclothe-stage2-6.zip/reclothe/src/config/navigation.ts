import {
  Banknote,
  ClipboardList,
  Factory,
  FileText,
  LayoutDashboard,
  Plus,
  Settings,
  TrendingUp,
  UserPlus,
  Users,
  Warehouse,
  type LucideIcon,
} from 'lucide-react'

import { buildHotkeyMap, type HotkeyBinding } from '@/lib/navigation'

export interface NavItem {
  label: string
  href: string
  icon: LucideIcon
  /** Вторая клавиша последовательности «G → …». */
  hotkey?: string
  /** Дополнительные слова для поиска в командной палитре. */
  keywords?: readonly string[]
}

export interface NavGroup {
  label: string
  items: readonly NavItem[]
}

export interface QuickAction {
  id: 'new-order' | 'new-client'
  label: string
  icon: LucideIcon
  /** Вторая клавиша последовательности «N → …». */
  hotkey: string
  keywords?: readonly string[]
}

/** Клавиши-префиксы последовательностей: «g» — перейти, «n» — создать (new). */
export const NAVIGATE_PREFIX = 'g'
export const CREATE_PREFIX = 'n'

export const NAV_GROUPS: readonly NavGroup[] = [
  {
    label: 'Операции',
    items: [
      { label: 'Дашборд', href: '/', icon: LayoutDashboard, hotkey: 'd', keywords: ['главная', 'аналитика'] },
      { label: 'Заказы', href: '/orders', icon: ClipboardList, hotkey: 'o', keywords: ['лиды', 'заявки', 'orders'] },
      { label: 'Клиенты', href: '/clients', icon: Users, hotkey: 'c', keywords: ['crm', 'карта', 'лояльность'] },
      { label: 'Производство', href: '/production', icon: Factory, hotkey: 'p', keywords: ['цех', 'этапы', 'мастера', 'aps'] },
    ],
  },
  {
    label: 'Склад и деньги',
    items: [
      { label: 'Склад', href: '/inventory', icon: Warehouse, hotkey: 'i', keywords: ['доноры', 'расходники', 'материалы'] },
      { label: 'Бухгалтерия и ЗП', href: '/payroll', icon: Banknote, hotkey: 'b', keywords: ['зарплата', 'выплаты', 'акт', 'гпх', 'премии'] },
      { label: 'Финансы', href: '/finance', icon: TrendingUp, hotkey: 'f', keywords: ['p&l', 'налог', 'нпд', 'выручка'] },
    ],
  },
  {
    label: 'Документы',
    items: [
      { label: 'Документы', href: '/documents', icon: FileText, hotkey: 'u', keywords: ['договор', 'акт', 'печать'] },
    ],
  },
]

/** Раздел «Настройки»: в сайдбаре — одной ссылкой внизу. */
export const SETTINGS_ITEMS: readonly NavItem[] = [
  { label: 'Настройки', href: '/settings', icon: Settings, hotkey: 's', keywords: ['тарифы', 'пароль', 'сброс'] },
]

export const QUICK_ACTIONS: readonly QuickAction[] = [
  { id: 'new-order', label: 'Новый заказ', icon: Plus, hotkey: 'o', keywords: ['создать', 'калькулятор'] },
  { id: 'new-client', label: 'Новый клиент', icon: UserPlus, hotkey: 'c', keywords: ['создать'] },
]

export const ALL_NAV_ITEMS: readonly NavItem[] = [
  ...NAV_GROUPS.flatMap((group) => group.items),
  ...SETTINGS_ITEMS,
]

const hotkeyBindings: HotkeyBinding[] = [
  ...ALL_NAV_ITEMS.flatMap((item) =>
    item.hotkey ? [{ prefix: NAVIGATE_PREFIX, key: item.hotkey, href: item.href }] : [],
  ),
  // Быстрые действия открывают окно, а не страницу: href — служебная метка.
  ...QUICK_ACTIONS.map((action) => ({
    prefix: CREATE_PREFIX,
    key: action.hotkey,
    href: `action:${action.id}`,
  })),
]

/** «g d» → «/», «n o» → «action:new-order». Дубликаты бросают ошибку при загрузке модуля. */
export const HOTKEY_MAP: ReadonlyMap<string, string> = buildHotkeyMap(hotkeyBindings)

export const HOTKEY_PREFIXES: ReadonlySet<string> = new Set([NAVIGATE_PREFIX, CREATE_PREFIX])
