'use client'

import { useMemo } from 'react'
import Link from 'next/link'
import { AlertTriangle, ArrowRight, BellRing, CircleAlert, CircleCheck, Info, Plus } from 'lucide-react'

import { FinanceChart } from '@/components/charts/FinanceChart'
import { HBarList, type HBarItem } from '@/components/charts/HBarList'
import { PageHeader } from '@/components/common/PageHeader'
import { StatTile, deltaPercent } from '@/components/finance/StatTile'
import { ORDER_STATUS_BADGE } from '@/components/orders/order-ui'
import { StageBar } from '@/components/orders/StageBar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { EmptyState } from '@/components/ui/empty-state'
import { Progress } from '@/components/ui/progress'
import { STAGES } from '@/lib/domain/catalog'
import type { NotificationTone } from '@/lib/domain/derive'
import { formatDateString, formatMonthKey } from '@/lib/date'
import { formatNumber, formatRub, pluralDays } from '@/lib/format'
import { ORDER_STATUS_LABELS } from '@/lib/domain/orders'
import { cn } from '@/lib/utils'
import { useApp } from '@/store/AppProvider'
import { useUI } from '@/store/ui'

const TONE_ICON: Record<NotificationTone, typeof Info> = {
  info: Info,
  warning: AlertTriangle,
  danger: CircleAlert,
  success: CircleCheck,
}

const TONE_CLASS: Record<NotificationTone, string> = {
  info: 'text-denim-text',
  warning: 'text-warning-text',
  danger: 'text-destructive-text',
  success: 'text-success-text',
}

function deadlineText(daysLeft: number): string {
  if (daysLeft < 0) return `просрочен на ${pluralDays(Math.abs(daysLeft))}`
  if (daysLeft === 0) return 'срок сегодня'
  if (daysLeft === 1) return 'срок завтра'
  return `ещё ${pluralDays(daysLeft)}`
}

/**
 * Главная панель администратора. Здесь нет ни одной зашитой цифры: все плитки, графики,
 * очередь сроков и загрузка мастеров считаются из состояния приложения и обновляются
 * мгновенно — после создания заказа, смены этапа, оплаты, премии или выплаты.
 */
export function DashboardView() {
  const { derived } = useApp()
  const { openOrderModal } = useUI()
  const { finance, activeOrders, masters, notifications, newLeads, pipeline, orders } = derived

  const months = finance.months
  const current = finance.current
  const previous = finance.previous
  const overdue = activeOrders.filter((view) => view.status === 'overdue').length

  const pipelineItems = useMemo<HBarItem[]>(
    () =>
      STAGES.map((stage, index) => {
        const count = pipeline[index] ?? 0
        return {
          key: String(stage.n),
          label: `${stage.n}. ${stage.title}`,
          value: count,
          display: String(count),
          title: `Этап ${stage.n}. ${stage.title}: заказов в работе — ${count}`,
        }
      }),
    [pipeline],
  )

  const deadlines = useMemo(
    () => [...activeOrders].sort((a, b) => a.order.deadline.localeCompare(b.order.deadline)).slice(0, 6),
    [activeOrders],
  )

  const npd = finance.npd
  const npdTone = npd.level === 'ok' ? 'success' : npd.level === 'warn80' || npd.level === 'warn90' ? 'warning' : 'destructive'
  const monthLabel = formatMonthKey(derived.currentMonth, 'long')

  return (
    <div>
      <PageHeader
        eyebrow={formatDateString(derived.today)}
        title="Дашборд"
        description={`Студия RE:clothe · ${monthLabel}. Все цифры считаются из заказов, оплат и склада в реальном времени.`}
        actions={
          <Button onClick={() => openOrderModal()}>
            <Plus aria-hidden="true" />
            Новый заказ
          </Button>
        }
      />

      <section aria-label="Ключевые показатели" className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile
          label={`Выручка за ${monthLabel}`}
          value={formatRub(current.revenue)}
          delta={deltaPercent(current.revenue, previous.revenue)}
          trend={months.map((month) => month.revenue)}
          trendColor="var(--series-revenue)"
          trendLabel="Динамика выручки по месяцам"
          testId="kpi-revenue"
        />
        <StatTile
          label="Чистая прибыль за месяц"
          value={formatRub(current.profit)}
          delta={deltaPercent(current.profit, previous.profit)}
          trend={months.map((month) => month.profit)}
          trendColor="var(--series-profit)"
          trendLabel="Динамика прибыли по месяцам"
          testId="kpi-profit"
        />
        <StatTile
          label="Заказов в работе"
          value={String(activeOrders.length)}
          hint={overdue > 0 ? `из них просрочено: ${overdue}` : 'просрочек нет'}
          testId="kpi-active"
        />
        <StatTile
          label="Ждём оплаты от клиентов"
          value={formatRub(finance.receivables)}
          hint={`средний чек ${formatRub(derived.averageCheck)}`}
          testId="kpi-receivables"
        />
      </section>

      {newLeads.length > 0 ? (
        <Link
          href="/orders?tab=leads"
          className="mt-4 flex items-center justify-between gap-3 rounded-lg border border-primary/40 bg-primary/10 px-4 py-3 text-sm transition-colors hover:bg-primary/15"
        >
          <span className="flex items-center gap-2">
            <BellRing className="size-4 text-primary-text" aria-hidden="true" />
            <span>
              Новых заявок от клиентов: <strong className="font-mono">{newLeads.length}</strong> — свяжитесь в один клик
            </span>
          </span>
          <ArrowRight className="size-4 text-primary-text" aria-hidden="true" />
        </Link>
      ) : null}

      <div className="mt-4 grid gap-4 xl:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <Card>
          <CardHeader>
            <CardTitle>Выручка, расходы и прибыль</CardTitle>
            <Link href="/finance" className="text-xs text-primary-text hover:underline">
              Финансы →
            </Link>
          </CardHeader>
          <CardContent>
            <FinanceChart months={months} />
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Лимит НПД</CardTitle>
              <Badge variant={npdTone}>{Math.round(npd.usedFraction * 100)}%</Badge>
            </CardHeader>
            <CardContent>
              <Progress
                value={npd.usedFraction * 100}
                tone={npdTone}
                size="lg"
                aria-label={`Использовано ${Math.round(npd.usedFraction * 100)}% годового лимита НПД`}
              />
              <p className="mt-2 text-xs text-muted-foreground">
                Доход за год <span className="font-mono text-foreground">{formatRub(npd.income)}</span> из{' '}
                <span className="font-mono text-foreground">{formatRub(npd.limit)}</span>. Остаток:{' '}
                <span className="font-mono text-foreground">{formatRub(npd.remaining)}</span>.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Загрузка мастеров</CardTitle>
              <Link href="/production" className="text-xs text-primary-text hover:underline">
                Цех →
              </Link>
            </CardHeader>
            <CardContent className="space-y-3">
              {masters.map((view) => (
                <div key={view.master.id}>
                  <div className="flex items-baseline justify-between gap-2 text-sm">
                    <span className="truncate">{view.master.name}</span>
                    <span
                      className={cn(
                        'font-mono text-xs font-semibold tabular-nums',
                        view.overloaded ? 'text-destructive-text' : 'text-foreground',
                      )}
                    >
                      {view.load}%
                      <span className="ml-1.5 font-normal text-muted-foreground">
                        ({view.activeTasks}/{view.master.capacity})
                      </span>
                    </span>
                  </div>
                  <Progress
                    value={view.load}
                    tone={view.overloaded ? 'destructive' : view.load >= 60 ? 'warning' : 'success'}
                    aria-label={`Загрузка мастера ${view.master.name}: ${view.load}%`}
                    className="mt-1.5"
                  />
                </div>
              ))}
              <p className="text-xs text-muted-foreground">Выше 80% — новый заказ автоматически сдвигается на +14 дней.</p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Ближайшие сроки</CardTitle>
            <Link href="/orders" className="text-xs text-primary-text hover:underline">
              Все заказы →
            </Link>
          </CardHeader>
          <CardContent>
            {deadlines.length === 0 ? (
              <EmptyState
                title="Нет заказов в работе"
                description={orders.length === 0 ? 'Создайте первый заказ — он сразу появится здесь.' : 'Все заказы выполнены.'}
              />
            ) : (
              <ul className="divide-y divide-border/60">
                {deadlines.map((view) => (
                  <li key={view.order.id} className="py-3 first:pt-0 last:pb-0">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="min-w-0">
                        <Link href={`/orders/${view.order.id}`} className="font-mono text-sm font-semibold hover:text-primary-text hover:underline">
                          {view.order.number}
                        </Link>
                        <p className="truncate text-xs text-muted-foreground">
                          {view.clientName} · {view.service.name}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge variant={ORDER_STATUS_BADGE[view.status]}>{ORDER_STATUS_LABELS[view.status]}</Badge>
                        <p className={cn('mt-1 text-xs', view.daysLeft < 0 ? 'text-destructive-text' : 'text-muted-foreground')}>
                          {formatDateString(view.order.deadline)} · {deadlineText(view.daysLeft)}
                        </p>
                      </div>
                    </div>
                    <StageBar view={view} className="mt-2" />
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Воронка производства</CardTitle>
              <span className="font-mono text-xs text-muted-foreground">
                в работе: {formatNumber(activeOrders.length)}
              </span>
            </CardHeader>
            <CardContent>
              <HBarList
                items={pipelineItems}
                color="var(--series-cost)"
                aria-label="Заказы в работе по этапам"
                emptyText="Сейчас нет заказов в работе"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Требует внимания</CardTitle>
              {notifications.length > 0 ? <Badge variant="default">{notifications.length}</Badge> : null}
            </CardHeader>
            <CardContent>
              {notifications.length === 0 ? (
                <p className="py-4 text-center text-sm text-muted-foreground">Всё в порядке: срочных дел нет.</p>
              ) : (
                <ul className="space-y-1">
                  {notifications.slice(0, 6).map((item) => {
                    const Icon = TONE_ICON[item.tone]
                    return (
                      <li key={item.id}>
                        <Link
                          href={item.href}
                          className="flex items-start gap-2.5 rounded-md px-2 py-2 transition-colors hover:bg-muted"
                        >
                          <Icon className={cn('mt-0.5 size-4 shrink-0', TONE_CLASS[item.tone])} aria-hidden="true" />
                          <span className="min-w-0">
                            <span className="block text-sm">{item.title}</span>
                            <span className="block text-xs text-muted-foreground">{item.detail}</span>
                          </span>
                        </Link>
                      </li>
                    )
                  })}
                </ul>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
