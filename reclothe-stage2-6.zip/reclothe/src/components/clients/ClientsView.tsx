'use client'

import { Suspense, useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { Plus, Search, UserPlus } from 'lucide-react'

import { EcoImpact } from '@/components/client/EcoImpact'
import { LoyaltyCard } from '@/components/client/LoyaltyCard'
import { MessengerIcon } from '@/components/common/MessengerIcon'
import { PageHeader } from '@/components/common/PageHeader'
import { PageSkeleton } from '@/components/common/PageSkeleton'
import { PAYMENT_BADGE } from '@/components/orders/order-ui'
import { StageBar } from '@/components/orders/StageBar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { DataTable, type Column } from '@/components/ui/data-table'
import { EmptyState } from '@/components/ui/empty-state'
import { Field } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Modal } from '@/components/ui/modal'
import { Select } from '@/components/ui/select'
import { useToast } from '@/components/ui/toast'
import { LOYALTY_TIERS, MESSENGERS, messengerLabel } from '@/lib/domain/catalog'
import type { ClientView } from '@/lib/domain/derive'
import { PAYMENT_STATUS_LABELS } from '@/lib/domain/orders'
import type { LoyaltyTierId, MessengerId } from '@/lib/domain/types'
import { formatIsoDate, formatNumber, formatRub } from '@/lib/format'
import {
  validateClientForm,
  type ClientFormErrors,
  type ClientFormValues,
} from '@/lib/validation/client-form'
import { newId, useActions, useApp } from '@/store/AppProvider'
import { useUI } from '@/store/ui'

type Draft = Record<keyof ClientFormValues, string>

const EMPTY: Draft = { lastName: '', firstName: '', middleName: '', phone: '', email: '', contact: 'telegram' }

function TierBadge({ view }: { view: ClientView }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 font-mono text-2xs font-semibold uppercase tracking-wide"
      style={{ borderColor: `${view.tier.glow}99`, color: view.tier.text, background: `${view.tier.from}66` }}
    >
      {view.tier.label}
      {view.tierOverridden ? <span aria-label="назначена вручную">✎</span> : null}
    </span>
  )
}

function NewClientModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const actions = useActions()
  const { derived } = useApp()
  const toast = useToast()
  const [draft, setDraft] = useState<Draft>(EMPTY)
  const [errors, setErrors] = useState<ClientFormErrors>({})

  const set = (key: keyof Draft, value: string): void => {
    setDraft((current) => ({ ...current, [key]: value }))
    setErrors((current) => ({ ...current, [key]: undefined }))
  }

  const submit = (event: React.FormEvent): void => {
    event.preventDefault()
    const result = validateClientForm(draft)
    if (!result.ok) {
      setErrors(result.errors)
      return
    }
    const existing = derived.clients.find(
      (view) =>
        view.client.phone.replace(/\D/g, '').slice(-10) === result.values.phone.replace(/\D/g, '').slice(-10) ||
        (view.client.email !== '' && view.client.email === result.values.email.toLowerCase()),
    )
    if (existing) {
      setErrors({ phone: `Такой клиент уже есть: ${existing.name}` })
      return
    }
    actions.saveClient({
      id: newId('c'),
      ...result.values,
      email: result.values.email.toLowerCase(),
      createdAt: new Date().toISOString(),
      source: 'admin',
      tierOverride: null,
    })
    toast({ title: 'Клиент добавлен', description: `${result.values.lastName} ${result.values.firstName}` })
    setDraft(EMPTY)
    onClose()
  }

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose()
      }}
      title="Новый клиент"
      description="Карта лояльности создастся автоматически: Бронзовая, 0 RE-coins."
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Отмена
          </Button>
          <Button type="submit" form="new-client-form">
            <UserPlus aria-hidden="true" />
            Добавить
          </Button>
        </>
      }
    >
      <form id="new-client-form" onSubmit={submit} noValidate className="grid gap-3 sm:grid-cols-2">
        <Field label="Фамилия" htmlFor="nc-last" error={errors.lastName} className="sm:col-span-2">
          <Input id="nc-last" value={draft.lastName} onChange={(e) => set('lastName', e.target.value)} autoFocus />
        </Field>
        <Field label="Имя" htmlFor="nc-first" error={errors.firstName}>
          <Input id="nc-first" value={draft.firstName} onChange={(e) => set('firstName', e.target.value)} />
        </Field>
        <Field label="Отчество" htmlFor="nc-middle" error={errors.middleName}>
          <Input id="nc-middle" value={draft.middleName} onChange={(e) => set('middleName', e.target.value)} />
        </Field>
        <Field label="Телефон" htmlFor="nc-phone" error={errors.phone}>
          <Input id="nc-phone" type="tel" inputMode="tel" placeholder="+7 900 000-00-00" value={draft.phone} onChange={(e) => set('phone', e.target.value)} />
        </Field>
        <Field label="Email" htmlFor="nc-email" error={errors.email}>
          <Input id="nc-email" type="email" inputMode="email" value={draft.email} onChange={(e) => set('email', e.target.value)} />
        </Field>
        <Field label="Как связаться" htmlFor="nc-contact" className="sm:col-span-2">
          <Select id="nc-contact" value={draft.contact} onChange={(e) => set('contact', e.target.value as MessengerId)}>
            {MESSENGERS.map((m) => (
              <option key={m.id} value={m.id}>
                {m.label}
              </option>
            ))}
          </Select>
        </Field>
      </form>
    </Modal>
  )
}

function ClientDetail({ view, onClose }: { view: ClientView | null; onClose: () => void }) {
  const actions = useActions()
  const toast = useToast()
  const { openOrderModal } = useUI()
  const router = useRouter()

  return (
    <Modal
      open={view !== null}
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      size="xl"
      title={view?.name ?? 'Клиент'}
      description={view ? `${view.client.phone} · ${view.client.email || 'без e-mail'} · ${messengerLabel(view.client.contact)}` : undefined}
      footer={
        view ? (
          <>
            <Button variant="ghost" onClick={onClose}>
              Закрыть
            </Button>
            <Button
              onClick={() => {
                onClose()
                openOrderModal({ clientId: view.client.id })
              }}
            >
              <Plus aria-hidden="true" />
              Новый заказ
            </Button>
          </>
        ) : undefined
      }
    >
      {view ? (
        <div className="space-y-5">
          <div className="grid gap-4 lg:grid-cols-2">
            <LoyaltyCard view={view} />
            <EcoImpact eco={view.eco} title="Эко-вклад клиента" />
          </div>

          <div className="rounded-lg border border-border bg-background p-3">
            <Field
              label="Статус карты лояльности"
              htmlFor="tier-override"
              hint={`Авто по сумме покупок (${formatRub(view.spent)}): ${view.autoTier.label}. Ручная смена мгновенно меняет карту клиента в его кабинете.`}
            >
              <Select
                id="tier-override"
                value={view.client.tierOverride ?? 'auto'}
                onChange={(event) => {
                  const value = event.target.value
                  const tier = value === 'auto' ? null : (value as LoyaltyTierId)
                  actions.setTierOverride(view.client.id, tier)
                  toast({
                    title: tier ? `Статус карты изменён: ${LOYALTY_TIERS.find((item) => item.id === tier)?.label}` : 'Статус карты: авто',
                    description: view.name,
                  })
                }}
              >
                <option value="auto">Авто — {view.autoTier.label}</option>
                {LOYALTY_TIERS.map((tier) => (
                  <option key={tier.id} value={tier.id}>
                    {tier.label}
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          <section aria-label="Заказы клиента">
            <h3 className="mb-2 font-mono text-xs uppercase tracking-wider text-muted-foreground">
              Заказы клиента · {view.orders.length}
            </h3>
            {view.orders.length === 0 ? (
              <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">Заказов пока нет.</p>
            ) : (
              <ul className="space-y-2">
                {view.orders.map((order) => (
                  <li key={order.order.id}>
                    <button
                      type="button"
                      onClick={() => {
                        onClose()
                        router.push(`/orders/${order.order.id}`)
                      }}
                      className="block w-full rounded-lg border border-border bg-background p-3 text-left transition-colors hover:bg-muted"
                    >
                      <span className="flex flex-wrap items-baseline justify-between gap-2">
                        <span className="font-mono text-sm font-semibold">{order.order.number}</span>
                        <span className="font-mono text-sm tabular-nums">{formatRub(order.pricing.clientTotal)}</span>
                      </span>
                      <span className="mt-0.5 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
                        <span>
                          {order.service.name} · {formatIsoDate(order.order.createdAt)}
                        </span>
                        <Badge variant={order.order.state === 'cancelled' ? 'muted' : PAYMENT_BADGE[order.paymentStatus]}>
                          {order.order.state === 'cancelled' ? 'Возврат' : PAYMENT_STATUS_LABELS[order.paymentStatus]}
                        </Badge>
                      </span>
                      <StageBar view={order} className="mt-2" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      ) : null}
    </Modal>
  )
}

function ClientsInner() {
  const { derived } = useApp()
  const params = useSearchParams()
  const router = useRouter()
  const [query, setQuery] = useState('')
  const [tier, setTier] = useState<LoyaltyTierId | 'all'>('all')
  const [openId, setOpenId] = useState<string | null>(params.get('client'))
  const [creating, setCreating] = useState(false)

  // «/clients#new» (быстрое действие из палитры) открывает форму нового клиента.
  useEffect(() => {
    const check = (): void => {
      if (window.location.hash === '#new') {
        setCreating(true)
        window.history.replaceState(null, '', window.location.pathname)
      }
    }
    check()
    window.addEventListener('hashchange', check)
    return () => window.removeEventListener('hashchange', check)
  }, [])

  const rows = useMemo(() => {
    const text = query.trim().toLowerCase()
    const digits = text.replace(/\D/g, '')
    return derived.clients.filter((view) => {
      if (tier !== 'all' && view.tier.id !== tier) return false
      if (!text) return true
      return (
        view.name.toLowerCase().includes(text) ||
        view.client.email.toLowerCase().includes(text) ||
        (digits.length >= 3 && view.client.phone.replace(/\D/g, '').includes(digits))
      )
    })
  }, [derived.clients, query, tier])

  const opened = openId ? derived.clientById.get(openId) ?? null : null

  const columns: Column<ClientView>[] = [
    {
      key: 'name',
      header: 'Клиент',
      mobileTitle: true,
      cell: (view) => (
        <div className="min-w-0">
          <p className="font-medium">{view.name}</p>
          <p className="font-mono text-xs text-muted-foreground">{view.client.phone}</p>
        </div>
      ),
    },
    {
      key: 'contact',
      header: 'Связь',
      cell: (view) => (
        <span className="inline-flex items-center gap-2 text-xs">
          <MessengerIcon id={view.client.contact} size="sm" />
          {messengerLabel(view.client.contact)}
        </span>
      ),
    },
    { key: 'tier', header: 'Карта', cell: (view) => <TierBadge view={view} /> },
    {
      key: 'spent',
      header: 'Покупки',
      align: 'right',
      cell: (view) => <span className="font-mono tabular-nums">{formatRub(view.spent)}</span>,
    },
    {
      key: 'coins',
      header: 'RE-coins',
      align: 'right',
      cell: (view) => <span className="font-mono tabular-nums">{formatNumber(view.coins)}</span>,
    },
    {
      key: 'orders',
      header: 'Заказов',
      align: 'right',
      cell: (view) => (
        <span className="font-mono tabular-nums">
          {view.orders.length}
          {view.activeOrders > 0 ? <span className="text-primary-text"> · {view.activeOrders} в работе</span> : null}
        </span>
      ),
    },
  ]

  return (
    <div>
      <PageHeader
        title="Клиенты"
        description="База клиентов и карты лояльности: статус считается из оплаченных заказов и меняется сразу после платежа."
        actions={
          <Button onClick={() => setCreating(true)}>
            <UserPlus aria-hidden="true" />
            Новый клиент
          </Button>
        }
      />

      <div className="mb-4 grid gap-2 sm:grid-cols-[1fr_14rem]">
        <div className="relative">
          <label htmlFor="clients-search" className="sr-only">
            Поиск клиентов
          </label>
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <Input
            id="clients-search"
            type="search"
            className="pl-9"
            placeholder="Фамилия, телефон, e-mail…"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
        </div>
        <Select aria-label="Статус карты" value={tier} onChange={(event) => setTier(event.target.value as LoyaltyTierId | 'all')}>
          <option value="all">Все статусы карты</option>
          {LOYALTY_TIERS.map((item) => (
            <option key={item.id} value={item.id}>
              {item.label}
            </option>
          ))}
        </Select>
      </div>

      <DataTable
        caption="Клиенты"
        columns={columns}
        rows={rows}
        rowKey={(view) => view.client.id}
        onRowClick={(view) => setOpenId(view.client.id)}
        empty={<EmptyState title="Клиентов не найдено" description="Измените поиск или добавьте клиента." />}
        mobileCard={(view) => (
          <div className="space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-medium">{view.name}</p>
                <p className="font-mono text-xs text-muted-foreground">{view.client.phone}</p>
              </div>
              <TierBadge view={view} />
            </div>
            <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <MessengerIcon id={view.client.contact} size="sm" />
                {messengerLabel(view.client.contact)}
              </span>
              <span className="font-mono">
                {formatRub(view.spent)} · {formatNumber(view.coins)} RE-coins
              </span>
            </div>
          </div>
        )}
      />

      <ClientDetail
        view={opened}
        onClose={() => {
          setOpenId(null)
          if (params.get('client')) router.replace('/clients', { scroll: false })
        }}
      />
      <NewClientModal open={creating} onClose={() => setCreating(false)} />
    </div>
  )
}

export function ClientsView() {
  return (
    <Suspense fallback={<PageSkeleton />}>
      <ClientsInner />
    </Suspense>
  )
}

// Ссылка-хелпер для других экранов: Link на карточку клиента.
export function ClientLink({ clientId, children }: { clientId: string; children: React.ReactNode }) {
  return (
    <Link href={`/clients?client=${clientId}`} className="hover:text-primary-text hover:underline">
      {children}
    </Link>
  )
}
