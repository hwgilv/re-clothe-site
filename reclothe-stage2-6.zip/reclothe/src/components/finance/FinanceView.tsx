'use client'

import { useMemo, useState } from 'react'
import Link from 'next/link'
import { Plus, Trash2 } from 'lucide-react'

import { FinanceChart, monthCosts } from '@/components/charts/FinanceChart'
import { HBarList, type HBarItem } from '@/components/charts/HBarList'
import { PageHeader } from '@/components/common/PageHeader'
import { StatTile, deltaPercent } from '@/components/finance/StatTile'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { DataTable, type Column } from '@/components/ui/data-table'
import { EmptyState } from '@/components/ui/empty-state'
import { Field } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Modal } from '@/components/ui/modal'
import { Progress } from '@/components/ui/progress'
import { SegmentedControl } from '@/components/ui/segmented-control'
import { Select } from '@/components/ui/select'
import { Tabs } from '@/components/ui/tabs'
import { useToast } from '@/components/ui/toast'
import { EXPENSE_CATEGORY_LABELS, type Transaction } from '@/lib/domain/derive'
import { NPD_RATES } from '@/lib/domain/npd'
import type { ExpenseCategory } from '@/lib/domain/types'
import { formatDateString, formatMonthKey, monthKey, toDateString } from '@/lib/date'
import { formatIsoDate, formatNumber, formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'
import { useActions, useApp } from '@/store/AppProvider'

type Scope = 'month' | 'all'
type Filter = 'all' | 'income' | 'expense'

const PAGE = 25

function AddExpenseModal({ open, onClose, today }: { open: boolean; onClose: () => void; today: string }) {
  const actions = useActions()
  const toast = useToast()
  const [title, setTitle] = useState('')
  const [category, setCategory] = useState<ExpenseCategory>('rent')
  const [amount, setAmount] = useState('')
  const [date, setDate] = useState(today)
  const [error, setError] = useState<string | null>(null)

  const submit = (event: React.FormEvent): void => {
    event.preventDefault()
    const value = Number.parseInt(amount.replace(/\D/g, ''), 10)
    if (!Number.isFinite(value) || value <= 0) {
      setError('Введите сумму больше нуля')
      return
    }
    actions.addExpense({
      title,
      category,
      amount: value,
      // Дата без времени — полдень по Новокузнецку, чтобы «сутки» не съезжали при смене пояса.
      at: new Date(`${date}T12:00:00+07:00`).toISOString(),
    })
    toast({ title: 'Расход добавлен', description: `${formatRub(value)} · ${EXPENSE_CATEGORY_LABELS[category]}. Прибыль и налог пересчитаны.` })
    setTitle('')
    setAmount('')
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose()
      }}
      size="sm"
      title="Добавить расход"
      description="Аренда, реклама, коммунальные платежи, оборудование."
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Отмена
          </Button>
          <Button type="submit" form="expense-form">
            Добавить
          </Button>
        </>
      }
    >
      <form id="expense-form" onSubmit={submit} noValidate className="space-y-3">
        <Field label="Название" htmlFor="ex-title">
          <Input id="ex-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Аренда цеха, октябрь" />
        </Field>
        <Field label="Категория" htmlFor="ex-category">
          <Select id="ex-category" value={category} onChange={(e) => setCategory(e.target.value as ExpenseCategory)}>
            {(Object.keys(EXPENSE_CATEGORY_LABELS) as ExpenseCategory[]).map((key) => (
              <option key={key} value={key}>
                {EXPENSE_CATEGORY_LABELS[key]}
              </option>
            ))}
          </Select>
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Сумма, ₽" htmlFor="ex-amount" error={error ?? undefined}>
            <Input
              id="ex-amount"
              inputMode="numeric"
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value.replace(/[^\d]/g, ''))
                setError(null)
              }}
              aria-invalid={Boolean(error) || undefined}
              aria-describedby={error ? 'ex-amount-error' : undefined}
            />
          </Field>
          <Field label="Дата" htmlFor="ex-date">
            <Input id="ex-date" type="date" max={today} value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
        </div>
      </form>
    </Modal>
  )
}

export function FinanceView() {
  const { state, derived } = useApp()
  const actions = useActions()
  const { finance } = derived
  const [scope, setScope] = useState<Scope>('month')
  const [filter, setFilter] = useState<Filter>('all')
  const [query, setQuery] = useState('')
  const [shown, setShown] = useState(PAGE)
  const [adding, setAdding] = useState(false)

  const months = finance.months
  const trend = (pick: (month: (typeof months)[number]) => number): number[] => months.map(pick)

  // Структура расходов: за текущий месяц или за всё время — считается из тех же первичных данных.
  const costItems = useMemo<HBarItem[]>(() => {
    const inScope = (iso: string): boolean => scope === 'all' || monthKey(iso) === derived.currentMonth
    const base = scope === 'all' ? finance.totals : finance.current
    const byCategory = new Map<ExpenseCategory, number>()
    for (const expense of state.expenses) {
      if (inScope(expense.at)) byCategory.set(expense.category, (byCategory.get(expense.category) ?? 0) + expense.amount)
    }
    const items: Omit<HBarItem, 'display'>[] = [
      { key: 'payroll', label: 'ЗП портным', value: base.payroll },
      { key: 'materials', label: 'Материалы', value: base.materials },
      { key: 'tax', label: `Налог НПД ${Math.round(NPD_RATES.individual * 100)}%`, value: base.tax },
      ...(Object.keys(EXPENSE_CATEGORY_LABELS) as ExpenseCategory[]).map((key) => ({
        key,
        label: EXPENSE_CATEGORY_LABELS[key],
        value: byCategory.get(key) ?? 0,
      })),
    ]
    return items
      .filter((item) => item.value > 0)
      .sort((a, b) => b.value - a.value)
      .map((item) => ({ ...item, display: formatRub(item.value), title: `${item.label}: ${formatRub(item.value)}` }))
  }, [scope, finance, state.expenses, derived.currentMonth])

  const transactions = useMemo(() => {
    const text = query.trim().toLowerCase()
    return finance.transactions.filter((item) => {
      if (filter !== 'all' && item.kind !== filter) return false
      return !text || item.title.toLowerCase().includes(text) || item.category.toLowerCase().includes(text)
    })
  }, [finance.transactions, filter, query])

  const npd = finance.npd
  const npdTone = npd.level === 'ok' ? 'success' : npd.level === 'warn80' || npd.level === 'warn90' ? 'warning' : 'destructive'
  const npdText =
    npd.level === 'exceeded'
      ? 'Лимит превышен — самозанятость больше не действует, нужно переходить на другой режим.'
      : npd.level === 'ok'
        ? 'Запас по лимиту достаточный.'
        : 'Приближаетесь к лимиту — планируйте переход на ИП/УСН заранее.'

  const columns: Column<Transaction>[] = [
    { key: 'date', header: 'Дата', mobileTitle: true, cell: (item) => <span className="whitespace-nowrap font-mono text-xs">{formatIsoDate(item.at)}</span> },
    {
      key: 'kind',
      header: 'Тип',
      cell: (item) => <Badge variant={item.kind === 'income' ? 'success' : 'destructive'}>{item.kind === 'income' ? 'Приход' : 'Расход'}</Badge>,
    },
    { key: 'category', header: 'Категория', cell: (item) => <span className="text-xs">{item.category}</span> },
    {
      key: 'title',
      header: 'Описание',
      cell: (item) =>
        item.orderId ? (
          <Link href={`/orders/${item.orderId}`} className="hover:text-primary-text hover:underline">
            {item.title}
          </Link>
        ) : (
          item.title
        ),
    },
    {
      key: 'amount',
      header: 'Сумма',
      align: 'right',
      cell: (item) => (
        <span className={cn('whitespace-nowrap font-mono font-semibold tabular-nums', item.kind === 'income' ? 'text-success-text' : 'text-destructive-text')}>
          {item.kind === 'income' ? '+' : '−'}
          {formatRub(item.amount)}
        </span>
      ),
    },
    {
      key: 'actions',
      header: '',
      align: 'right',
      hideOnMobile: false,
      cell: (item) =>
        item.id.startsWith('exp-') ? (
          <Button
            variant="ghost"
            size="sm"
            aria-label={`Удалить расход: ${item.title}`}
            onClick={() => actions.removeExpense(item.id.slice('exp-'.length))}
          >
            <Trash2 aria-hidden="true" />
          </Button>
        ) : null,
    },
  ]

  const currentLabel = formatMonthKey(derived.currentMonth, 'long')
  const cur = finance.current
  const prev = finance.previous

  return (
    <div>
      <PageHeader
        title="Финансы"
        description="Выручка, расходы, прибыль и налог считаются из оплат по заказам, выплат ЗП, закупок склада и ваших расходов."
        actions={
          <Button onClick={() => setAdding(true)}>
            <Plus aria-hidden="true" />
            Добавить расход
          </Button>
        }
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile
          testId="fin-revenue"
          label={`Выручка, ${currentLabel}`}
          value={formatRub(cur.revenue)}
          delta={deltaPercent(cur.revenue, prev.revenue)}
          trend={trend((m) => m.revenue)}
          trendColor="var(--series-revenue)"
          trendLabel="Выручка за 6 месяцев"
        />
        <StatTile
          testId="fin-costs"
          label="Расходы"
          value={formatRub(monthCosts(cur))}
          delta={deltaPercent(monthCosts(cur), monthCosts(prev))}
          goodWhenUp={false}
          trend={trend(monthCosts)}
          trendColor="var(--series-cost)"
          trendLabel="Расходы за 6 месяцев"
        />
        <StatTile
          testId="fin-profit"
          label="Чистая прибыль"
          value={formatRub(cur.profit)}
          delta={deltaPercent(cur.profit, prev.profit)}
          trend={trend((m) => m.profit)}
          trendColor="var(--series-profit)"
          trendLabel="Прибыль за 6 месяцев"
        />
        <StatTile
          testId="fin-receivables"
          label="Ожидается от клиентов"
          value={formatRub(finance.receivables)}
          hint="Остаток по активным заказам"
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_24rem]">
        <Card>
          <CardHeader>
            <CardTitle>Выручка, расходы и прибыль по месяцам</CardTitle>
          </CardHeader>
          <CardContent>
            <FinanceChart months={months} />
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Лимит НПД</CardTitle>
              <Badge variant={npdTone}>{Math.round(npd.usedFraction * 100)}%</Badge>
            </CardHeader>
            <CardContent>
              <p className="font-mono text-lg font-semibold tabular-nums" data-testid="npd-income">
                {formatRub(npd.income)} <span className="text-xs font-normal text-muted-foreground">из {formatRub(npd.limit)}</span>
              </p>
              <Progress
                value={Math.min(100, npd.usedFraction * 100)}
                tone={npdTone}
                size="lg"
                aria-label={`Использовано ${Math.round(npd.usedFraction * 100)}% годового лимита НПД`}
                className="mt-2"
              />
              <p className="mt-2 text-xs text-muted-foreground">
                Осталось {formatRub(npd.remaining)} до конца года. {npdText}
              </p>
              <p className="mt-2 text-xs text-muted-foreground">
                Налог за {currentLabel}: <span className="font-mono text-foreground">{formatRub(cur.tax)}</span> (
                {Math.round(NPD_RATES.individual * 100)}% с доходов физлиц).
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Структура расходов</CardTitle>
              <SegmentedControl<Scope>
                aria-label="Период расходов"
                value={scope}
                onChange={setScope}
                options={[
                  { value: 'month', label: 'Месяц' },
                  { value: 'all', label: 'Всё время' },
                ]}
              />
            </CardHeader>
            <CardContent>
              <HBarList items={costItems} aria-label="Структура расходов" emptyText="Расходов за период нет" />
            </CardContent>
          </Card>
        </div>
      </div>

      <section aria-labelledby="tx-heading" className="mt-6">
        <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
          <h2 id="tx-heading" className="text-lg font-semibold">
            Операции
          </h2>
          <div className="flex flex-wrap items-center gap-2">
            <Input
              type="search"
              aria-label="Поиск по операциям"
              placeholder="Поиск…"
              className="h-9 w-44"
              value={query}
              onChange={(event) => {
                setQuery(event.target.value)
                setShown(PAGE)
              }}
            />
            <Tabs<Filter>
              aria-label="Тип операций"
              value={filter}
              onChange={(next) => {
                setFilter(next)
                setShown(PAGE)
              }}
              tabs={[
                { value: 'all', label: 'Все' },
                { value: 'income', label: 'Приходы' },
                { value: 'expense', label: 'Расходы' },
              ]}
            />
          </div>
        </div>

        <DataTable
          caption="Финансовые операции"
          columns={columns}
          rows={transactions.slice(0, shown)}
          rowKey={(item) => item.id}
          empty={<EmptyState title="Операций не найдено" description="Измените фильтры или добавьте расход." />}
        />
        {transactions.length > shown ? (
          <div className="mt-3 text-center">
            <Button variant="outline" onClick={() => setShown((count) => count + PAGE)}>
              Показать ещё ({formatNumber(transactions.length - shown)})
            </Button>
          </div>
        ) : null}
        <p className="mt-2 text-xs text-muted-foreground">
          Последняя операция: {transactions[0] ? formatDateString(toDateString(new Date(transactions[0].at))) : '—'}
        </p>
      </section>

      <AddExpenseModal open={adding} onClose={() => setAdding(false)} today={derived.today} />
    </div>
  )
}
