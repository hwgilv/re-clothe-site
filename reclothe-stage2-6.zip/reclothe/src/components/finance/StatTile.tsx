import { Sparkline } from '@/components/charts/Sparkline'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'

/** Изменение к прошлому периоду: «+12%», «−5%». null, если сравнивать не с чем. */
export function deltaPercent(current: number, previous: number): number | null {
  if (previous === 0) return null
  return Math.round(((current - previous) / Math.abs(previous)) * 100)
}

/**
 * Плитка показателя: подпись · значение · изменение · тренд.
 * `goodWhenUp=false` — для расходов: рост показывается красным, а не зелёным.
 */
export function StatTile({
  label,
  value,
  delta,
  deltaLabel = 'к прошлому месяцу',
  goodWhenUp = true,
  trend,
  trendColor,
  trendLabel,
  testId,
  hint,
}: {
  label: string
  value: string
  delta?: number | null
  deltaLabel?: string
  goodWhenUp?: boolean
  trend?: readonly number[]
  trendColor?: string
  trendLabel?: string
  testId?: string
  hint?: string
}) {
  const good = delta === undefined || delta === null || delta === 0 ? null : (delta > 0) === goodWhenUp
  return (
    <Card>
      <CardContent className="flex items-start justify-between gap-3 p-4">
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="mt-1 text-2xl font-semibold" data-testid={testId}>
            {value}
          </p>
          {delta !== undefined ? (
            <p className="mt-1 text-xs">
              {delta === null ? (
                <span className="text-muted-foreground">нет данных для сравнения</span>
              ) : (
                <>
                  <span
                    className={cn(
                      'font-mono font-semibold',
                      good === null ? 'text-muted-foreground' : good ? 'text-success-text' : 'text-destructive-text',
                    )}
                  >
                    <span aria-hidden="true">{delta > 0 ? '▲' : delta < 0 ? '▼' : '■'} </span>
                    {delta > 0 ? '+' : delta < 0 ? '−' : ''}
                    {Math.abs(delta)}%
                  </span>{' '}
                  <span className="text-muted-foreground">{deltaLabel}</span>
                </>
              )}
            </p>
          ) : null}
          {hint ? <p className="mt-1 text-xs text-muted-foreground">{hint}</p> : null}
        </div>
        {trend && trend.length > 1 ? (
          <Sparkline
            values={trend}
            {...(trendColor ? { color: trendColor } : {})}
            aria-label={trendLabel ?? `Динамика: ${label}`}
          />
        ) : null}
      </CardContent>
    </Card>
  )
}
