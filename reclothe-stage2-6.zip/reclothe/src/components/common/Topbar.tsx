'use client'

import { Menu, Plus, Search } from 'lucide-react'

import { Breadcrumbs } from '@/components/common/Breadcrumbs'
import { NotificationsButton } from '@/components/common/NotificationsButton'
import { Button } from '@/components/ui/button'
import { Kbd } from '@/components/ui/kbd'
import { modifierLabel, usePlatform } from '@/hooks/use-platform'
import { useUI } from '@/store/ui'

export function Topbar() {
  const { setMobileNavOpen, setPaletteOpen, openOrderModal } = useUI()
  const platform = usePlatform()

  return (
    <header className="sticky top-0 z-30 flex h-12 shrink-0 items-center gap-2 border-b border-border bg-background/85 px-3 backdrop-blur lg:px-6">
      <Button
        variant="ghost"
        size="icon"
        className="lg:hidden"
        aria-label="Открыть меню навигации"
        onClick={() => setMobileNavOpen(true)}
      >
        <Menu aria-hidden="true" />
      </Button>

      <Breadcrumbs />

      <div className="ml-auto flex items-center gap-2">
        <Button size="sm" className="hidden sm:inline-flex" onClick={() => openOrderModal()}>
          <Plus aria-hidden="true" />
          Новый заказ
        </Button>
        <Button
          size="icon"
          className="sm:hidden"
          aria-label="Новый заказ"
          onClick={() => openOrderModal()}
        >
          <Plus aria-hidden="true" />
        </Button>

        <button
          type="button"
          onClick={() => setPaletteOpen(true)}
          aria-label="Открыть командную палитру"
          className="hidden h-8 w-48 items-center gap-2 rounded-md border border-input bg-surface px-2.5 text-xs text-muted-foreground transition-colors hover:text-foreground xl:flex"
        >
          <Search className="size-3.5" aria-hidden="true" />
          <span>Поиск и команды…</span>
          <span className="ml-auto flex gap-0.5" aria-hidden="true">
            <Kbd>{modifierLabel(platform)}</Kbd>
            <Kbd>K</Kbd>
          </span>
        </button>

        <NotificationsButton />

        <div
          role="img"
          aria-label="Роль: администратор"
          className="flex size-8 items-center justify-center rounded-md border border-primary/40 bg-primary/10 font-mono text-xs font-semibold text-primary-text"
        >
          АД
        </div>
      </div>
    </header>
  )
}
