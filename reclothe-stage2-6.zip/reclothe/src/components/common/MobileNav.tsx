'use client'

import { useEffect } from 'react'
import * as Dialog from '@radix-ui/react-dialog'
import { X } from 'lucide-react'

import { Logo } from '@/components/common/Logo'
import { SettingsLink, SidebarActions } from '@/components/common/Sidebar'
import { SidebarNav } from '@/components/common/SidebarNav'
import { Button } from '@/components/ui/button'
import { useUI } from '@/store/ui'

/** Бургер-меню: на телефоне и планшете (< 1024 px) вместо сайдбара. */
export function MobileNav() {
  const { mobileNavOpen: open, setMobileNavOpen: setOpen } = useUI()

  // Если экран стал широким (поворот планшета), меню закрываем: иначе останется блокировка скролла.
  useEffect(() => {
    const query = window.matchMedia('(min-width: 1024px)')
    const onChange = (event: MediaQueryListEvent) => {
      if (event.matches) setOpen(false)
    }
    query.addEventListener('change', onChange)
    return () => query.removeEventListener('change', onChange)
  }, [setOpen])

  const close = () => setOpen(false)

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-black/70 data-[state=closed]:animate-out data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 lg:hidden" />
        <Dialog.Content
          aria-describedby={undefined}
          className="fixed inset-y-0 left-0 z-50 flex w-72 max-w-[85vw] flex-col border-r border-border bg-surface shadow-xl duration-200 data-[state=closed]:animate-out data-[state=open]:animate-in data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left lg:hidden"
        >
          <Dialog.Title className="sr-only">Меню навигации</Dialog.Title>

          <div className="h-1.5 shrink-0 bg-hazard" aria-hidden="true" />
          <div className="flex h-12 shrink-0 items-center justify-between border-b border-border px-3">
            <Logo />
            <Dialog.Close asChild>
              <Button variant="ghost" size="icon" aria-label="Закрыть меню">
                <X aria-hidden="true" />
              </Button>
            </Dialog.Close>
          </div>

          <SidebarActions onAction={close} />
          <SidebarNav onNavigate={close} />

          <div className="shrink-0 border-t border-border p-2">
            <SettingsLink onNavigate={close} />
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
