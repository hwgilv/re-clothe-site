'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

import { HOTKEY_MAP, HOTKEY_PREFIXES } from '@/config/navigation'
import { isEditableTarget, keyLetterFromCode } from '@/lib/hotkeys'
import { useUI } from '@/store/ui'

/** Время, в течение которого ждём вторую клавишу последовательности («G», затем «D»). */
const SEQUENCE_TIMEOUT_MS = 1200

/**
 * Глобальные горячие клавиши (ничего не рисует):
 *  - Ctrl/⌘ + K — командная палитра, Ctrl/⌘ + B — свернуть сайдбар (работают всегда);
 *  - «G → буква» — перейти в раздел, «N → буква» — создать (только вне полей ввода).
 */
export function HotkeysProvider() {
  const router = useRouter()
  const { togglePalette, toggleSidebar, openOrderModal } = useUI()

  useEffect(() => {
    let pendingPrefix: string | null = null
    let timer: ReturnType<typeof setTimeout> | undefined

    const clearPending = () => {
      pendingPrefix = null
      if (timer) clearTimeout(timer)
    }

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.defaultPrevented || event.repeat || event.isComposing) return

      const letter = keyLetterFromCode(event.code)

      if (event.metaKey || event.ctrlKey) {
        if (letter === 'k') {
          event.preventDefault()
          togglePalette()
        } else if (letter === 'b') {
          event.preventDefault()
          toggleSidebar()
        }
        return
      }

      if (event.altKey || event.shiftKey || !letter || isEditableTarget(event.target)) {
        clearPending()
        return
      }

      if (pendingPrefix) {
        const href = HOTKEY_MAP.get(`${pendingPrefix} ${letter}`)
        clearPending()
        if (href) {
          event.preventDefault()
          if (href === 'action:new-order') openOrderModal()
          else if (href === 'action:new-client') router.push('/clients#new')
          else router.push(href)
        }
        return
      }

      if (HOTKEY_PREFIXES.has(letter)) {
        pendingPrefix = letter
        timer = setTimeout(clearPending, SEQUENCE_TIMEOUT_MS)
      }
    }

    window.addEventListener('keydown', onKeyDown)
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      clearPending()
    }
  }, [router, togglePalette, toggleSidebar, openOrderModal])

  return null
}
