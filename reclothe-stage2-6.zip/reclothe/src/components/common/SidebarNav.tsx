'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

import { Kbd } from '@/components/ui/kbd'
import { ALL_NAV_ITEMS, NAV_GROUPS, NAVIGATE_PREFIX } from '@/config/navigation'
import { getActiveHref } from '@/lib/navigation'
import { cn } from '@/lib/utils'
import { useDerived } from '@/store/AppProvider'

interface SidebarNavProps {
  /** Только иконки (свёрнутый сайдбар). */
  collapsed?: boolean
  /** Вызывается при переходе по ссылке — мобильное меню закрывается. */
  onNavigate?: () => void
}

/** Основная навигация. Общая для десктопного сайдбара и мобильного меню. */
export function SidebarNav({ collapsed = false, onNavigate }: SidebarNavProps) {
  const pathname = usePathname()
  const activeHref = getActiveHref(pathname, ALL_NAV_ITEMS)
  const derived = useDerived()

  /** Числовые бейджи: новые заявки в «Заказах», готовые к выплате ЗП в «Бухгалтерии». */
  const badges: Record<string, number> = {
    '/orders': derived.newLeads.length,
    '/payroll': derived.masters.filter((master) => master.balance > 0).length,
  }

  return (
    <nav
      aria-label="Основная навигация"
      className="flex-1 overflow-y-auto px-2 py-3 scrollbar-thin"
    >
      {NAV_GROUPS.map((group, groupIndex) => (
        <div key={group.label} className="mb-4">
          {collapsed ? (
            groupIndex > 0 && (
              <div className="mx-2 mb-2 border-t border-border" aria-hidden="true" />
            )
          ) : (
            <p className="px-2 pb-1 font-mono text-2xs uppercase tracking-widest text-muted-foreground">
              {group.label}
            </p>
          )}

          <ul className="space-y-0.5">
            {group.items.map((item) => {
              const active = item.href === activeHref
              const badge = badges[item.href] ?? 0
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    onClick={onNavigate}
                    aria-current={active ? 'page' : undefined}
                    title={collapsed ? item.label : undefined}
                    className={cn(
                      'group relative flex min-h-10 items-center gap-2.5 rounded-md px-2 text-sm transition-colors lg:min-h-9',
                      active
                        ? 'bg-muted text-foreground'
                        : 'text-muted-foreground hover:bg-muted hover:text-foreground',
                    )}
                  >
                    {/* Оранжевая метка активного пункта. */}
                    {active && (
                      <span
                        aria-hidden="true"
                        className="absolute inset-y-1.5 left-0 w-0.5 rounded-full bg-primary"
                      />
                    )}
                    <item.icon
                      className={cn('size-4 shrink-0', active && 'text-primary-text')}
                      aria-hidden="true"
                    />
                    <span className={collapsed ? 'sr-only' : 'truncate'}>{item.label}</span>
                    {badge > 0 && (
                      <span
                        className={cn(
                          'ml-auto rounded-full bg-primary px-1.5 font-mono text-2xs font-semibold text-primary-foreground',
                          collapsed && 'absolute right-0.5 top-0.5 ml-0 px-1',
                        )}
                      >
                        <span className="sr-only">Новых: </span>
                        {badge}
                      </span>
                    )}
                    {!collapsed && badge === 0 && item.hotkey && (
                      <span
                        className="ml-auto hidden items-center gap-0.5 group-hover:flex"
                        aria-hidden="true"
                      >
                        <Kbd>{NAVIGATE_PREFIX.toUpperCase()}</Kbd>
                        <Kbd>{item.hotkey.toUpperCase()}</Kbd>
                      </span>
                    )}
                  </Link>
                </li>
              )
            })}
          </ul>
        </div>
      ))}
    </nav>
  )
}
