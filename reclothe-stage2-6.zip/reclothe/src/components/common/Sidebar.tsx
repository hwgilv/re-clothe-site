'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion } from 'framer-motion'
import { LogOut, PanelLeftClose, PanelLeftOpen, Plus, Settings } from 'lucide-react'

import { Logo } from '@/components/common/Logo'
import { SidebarNav } from '@/components/common/SidebarNav'
import { useSession } from '@/components/auth/SessionProvider'
import { Button } from '@/components/ui/button'
import { modifierLabel, usePlatform } from '@/hooks/use-platform'
import { cn } from '@/lib/utils'
import { useUI } from '@/store/ui'

const EXPANDED_WIDTH = 248
const COLLAPSED_WIDTH = 56

/** Ссылка «Настройки» внизу сайдбара; используется и в мобильном меню. */
export function SettingsLink({
  collapsed = false,
  onNavigate,
}: {
  collapsed?: boolean
  onNavigate?: () => void
}) {
  const pathname = usePathname()
  const active = pathname.startsWith('/settings')

  return (
    <Link
      href="/settings"
      onClick={onNavigate}
      aria-current={active ? 'page' : undefined}
      title={collapsed ? 'Настройки' : undefined}
      className={cn(
        'flex min-h-10 items-center gap-2.5 rounded-md px-2 text-sm transition-colors lg:min-h-9',
        active
          ? 'bg-muted text-foreground'
          : 'text-muted-foreground hover:bg-muted hover:text-foreground',
      )}
    >
      <Settings className="size-4 shrink-0" aria-hidden="true" />
      <span className={collapsed ? 'sr-only' : 'truncate'}>Настройки</span>
    </Link>
  )
}

/** Кнопки «+ Новый заказ» и «Выйти» — общие для сайдбара и мобильного меню. */
export function SidebarActions({
  collapsed = false,
  onAction,
}: {
  collapsed?: boolean
  onAction?: () => void
}) {
  const { openOrderModal } = useUI()
  const { logout } = useSession()

  return (
    <>
      <div className="px-2 pt-3">
        <Button
          className="w-full"
          size={collapsed ? 'icon' : 'md'}
          aria-label="Новый заказ"
          title="Новый заказ"
          onClick={() => {
            onAction?.()
            openOrderModal()
          }}
        >
          <Plus aria-hidden="true" />
          {!collapsed && <span>Новый заказ</span>}
        </Button>
      </div>
      <div className="px-2 pb-1">
        <button
          type="button"
          onClick={() => {
            onAction?.()
            logout()
          }}
          title={collapsed ? 'Выйти' : undefined}
          className="flex min-h-10 w-full items-center gap-2.5 rounded-md px-2 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground lg:min-h-9"
        >
          <LogOut className="size-4 shrink-0" aria-hidden="true" />
          <span className={collapsed ? 'sr-only' : 'truncate'}>Выйти</span>
        </button>
      </div>
    </>
  )
}

/** Десктопный сайдбар (от 1024 px). Ниже — вместо него выезжающее меню (бургер). */
export function Sidebar() {
  const { sidebarCollapsed: collapsed, toggleSidebar: toggle } = useUI()
  const platform = usePlatform()

  return (
    <motion.aside
      aria-label="Боковая панель"
      initial={false}
      animate={{ width: collapsed ? COLLAPSED_WIDTH : EXPANDED_WIDTH }}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      className="sticky top-0 hidden h-dvh shrink-0 flex-col overflow-hidden border-r border-border bg-surface lg:flex"
    >
      {/* Сигнальная лента — фирменный акцент. */}
      <div className="h-1.5 shrink-0 bg-hazard" aria-hidden="true" />

      <div className="flex h-12 shrink-0 items-center border-b border-border px-3">
        <Logo collapsed={collapsed} />
      </div>

      <SidebarActions collapsed={collapsed} />
      <SidebarNav collapsed={collapsed} />

      <div className="shrink-0 space-y-0.5 border-t border-border p-2">
        <SettingsLink collapsed={collapsed} />
        <Button
          variant="ghost"
          size="sm"
          onClick={toggle}
          aria-expanded={!collapsed}
          aria-label={collapsed ? 'Развернуть боковую панель' : 'Свернуть боковую панель'}
          title={`${modifierLabel(platform)} + B`}
          className="w-full justify-start gap-2.5 px-2 font-normal text-muted-foreground hover:text-foreground"
        >
          {collapsed ? <PanelLeftOpen aria-hidden="true" /> : <PanelLeftClose aria-hidden="true" />}
          {!collapsed && <span>Свернуть</span>}
        </Button>
      </div>
    </motion.aside>
  )
}
