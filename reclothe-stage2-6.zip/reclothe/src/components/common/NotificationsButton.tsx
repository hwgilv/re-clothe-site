'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Bell, CircleAlert, CircleCheck, Info, TriangleAlert } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Modal } from '@/components/ui/modal'
import type { NotificationTone } from '@/lib/domain/derive'
import { cn } from '@/lib/utils'
import { useDerived } from '@/store/AppProvider'

const TONE_ICON = {
  info: { Icon: Info, className: 'text-denim-text' },
  warning: { Icon: TriangleAlert, className: 'text-warning-text' },
  danger: { Icon: CircleAlert, className: 'text-destructive-text' },
  success: { Icon: CircleCheck, className: 'text-success-text' },
} as const satisfies Record<NotificationTone, { Icon: unknown; className: string }>

/** Колокольчик в шапке: число и список уведомлений считаются из состояния. */
export function NotificationsButton() {
  const { notifications } = useDerived()
  const [open, setOpen] = useState(false)

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        className="relative"
        aria-label={`Уведомления: ${notifications.length}`}
        onClick={() => setOpen(true)}
      >
        <Bell aria-hidden="true" />
        {notifications.length > 0 && (
          <span className="absolute right-1 top-1 flex min-w-4 items-center justify-center rounded-full bg-primary px-1 font-mono text-2xs font-semibold leading-4 text-primary-foreground">
            {notifications.length}
          </span>
        )}
      </Button>

      <Modal open={open} onOpenChange={setOpen} title="Уведомления" description="Всё, что требует внимания прямо сейчас.">
        {notifications.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">Всё спокойно — задач нет.</p>
        ) : (
          <ul className="space-y-2">
            {notifications.map((item) => {
              const { Icon, className } = TONE_ICON[item.tone]
              return (
                <li key={item.id}>
                  <Link
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className="flex items-start gap-3 rounded-lg border border-border bg-background p-3 transition-colors hover:bg-muted"
                  >
                    <Icon className={cn('mt-0.5 size-4 shrink-0', className)} aria-hidden="true" />
                    <span className="min-w-0">
                      <span className="block text-sm font-medium">{item.title}</span>
                      <span className="block text-xs text-muted-foreground">{item.detail}</span>
                    </span>
                  </Link>
                </li>
              )
            })}
          </ul>
        )}
      </Modal>
    </>
  )
}
