'use client'

import { useCallback } from 'react'
import * as Dialog from '@radix-ui/react-dialog'
import { Command } from 'cmdk'
import { Search } from 'lucide-react'
import { useRouter } from 'next/navigation'

import { Kbd } from '@/components/ui/kbd'
import { ALL_NAV_ITEMS, CREATE_PREFIX, NAVIGATE_PREFIX, QUICK_ACTIONS } from '@/config/navigation'
import { useUI } from '@/store/ui'

const GROUP_CLASS =
  'mb-1 [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:font-mono [&_[cmdk-group-heading]]:text-2xs [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-widest [&_[cmdk-group-heading]]:text-muted-foreground'

const ITEM_CLASS =
  'flex cursor-pointer items-center gap-2.5 rounded-md px-2 py-2 text-sm aria-selected:bg-muted'

function Shortcut({ prefix, keyName }: { prefix: string; keyName: string }) {
  return (
    <span className="ml-auto flex gap-0.5" aria-hidden="true">
      <Kbd>{prefix.toUpperCase()}</Kbd>
      <Kbd>{keyName.toUpperCase()}</Kbd>
    </span>
  )
}

/** Командная палитра (Ctrl/⌘ + K): переходы по разделам и быстрые действия. */
export function CommandPalette() {
  const { paletteOpen: open, setPaletteOpen: setOpen, openOrderModal } = useUI()
  const router = useRouter()

  const run = useCallback(
    (action: () => void) => {
      setOpen(false)
      action()
    },
    [setOpen],
  )

  const go = useCallback((href: string) => run(() => router.push(href)), [run, router])

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm data-[state=closed]:animate-out data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" />
        <Dialog.Content
          aria-describedby={undefined}
          className="fixed left-1/2 top-[12vh] z-50 w-[calc(100vw-2rem)] max-w-xl -translate-x-1/2 overflow-hidden rounded-lg border border-border bg-background shadow-2xl data-[state=closed]:animate-out data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95"
        >
          <Dialog.Title className="sr-only">Командная палитра</Dialog.Title>

          <Command label="Командная палитра" loop>
            <div className="flex items-center gap-2 border-b border-border px-3">
              <Search className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
              <Command.Input
                placeholder="Куда перейти или что создать?"
                className="h-11 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              />
            </div>

            <Command.List className="max-h-[min(60vh,420px)] overflow-y-auto p-2 scrollbar-thin">
              <Command.Empty className="px-3 py-6 text-center text-sm text-muted-foreground">
                Ничего не найдено
              </Command.Empty>

              <Command.Group heading="Создать" className={GROUP_CLASS}>
                {QUICK_ACTIONS.map((action) => (
                  <Command.Item
                    key={action.id}
                    value={action.label}
                    keywords={action.keywords ? [...action.keywords] : undefined}
                    onSelect={() =>
                      run(() => {
                        if (action.id === 'new-order') openOrderModal()
                        else router.push('/clients#new')
                      })
                    }
                    className={ITEM_CLASS}
                  >
                    <action.icon className="size-4 text-primary-text" aria-hidden="true" />
                    <span>{action.label}</span>
                    <Shortcut prefix={CREATE_PREFIX} keyName={action.hotkey} />
                  </Command.Item>
                ))}
              </Command.Group>

              <Command.Group heading="Перейти" className={GROUP_CLASS}>
                {ALL_NAV_ITEMS.map((item) => (
                  <Command.Item
                    key={item.href}
                    value={item.label}
                    keywords={item.keywords ? [...item.keywords] : undefined}
                    onSelect={() => go(item.href)}
                    className={ITEM_CLASS}
                  >
                    <item.icon className="size-4 text-muted-foreground" aria-hidden="true" />
                    <span>{item.label}</span>
                    {item.hotkey && <Shortcut prefix={NAVIGATE_PREFIX} keyName={item.hotkey} />}
                  </Command.Item>
                ))}
              </Command.Group>

            </Command.List>

            <div className="flex items-center gap-3 border-t border-border px-3 py-2 font-mono text-2xs text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <Kbd>↑</Kbd>
                <Kbd>↓</Kbd> навигация
              </span>
              <span className="inline-flex items-center gap-1">
                <Kbd>↵</Kbd> выбрать
              </span>
              <span className="inline-flex items-center gap-1">
                <Kbd>Esc</Kbd> закрыть
              </span>
            </div>
          </Command>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
