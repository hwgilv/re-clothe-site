'use client'

import { Fragment } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ChevronRight } from 'lucide-react'

import { buildBreadcrumbs } from '@/lib/navigation'
import { cn } from '@/lib/utils'
import { useDerived } from '@/store/AppProvider'

export function Breadcrumbs() {
  const pathname = usePathname()
  const { orderById } = useDerived()
  // В адресе — служебный id заказа; в крошках показываем понятный номер RC-2026-XXXX.
  const crumbs = buildBreadcrumbs(pathname).map((crumb) => {
    const match = /^\/orders\/([^/]+)$/.exec(crumb.href)
    const number = match?.[1] ? orderById.get(decodeURIComponent(match[1]))?.order.number : undefined
    return number ? { ...crumb, label: number } : crumb
  })

  return (
    <nav aria-label="Хлебные крошки" className="min-w-0">
      <ol className="flex items-center gap-1.5 font-mono text-xs">
        {crumbs.map((crumb, index) => {
          const isLast = index === crumbs.length - 1
          return (
            <Fragment key={crumb.href}>
              {index > 0 && (
                <li
                  aria-hidden="true"
                  className={cn('text-muted-foreground', !isLast && 'hidden sm:block')}
                >
                  <ChevronRight className="size-3" />
                </li>
              )}
              <li className={cn('min-w-0', !isLast && 'hidden sm:block')}>
                {isLast ? (
                  <span aria-current="page" className="block truncate font-medium text-foreground">
                    {crumb.label}
                  </span>
                ) : (
                  <Link
                    href={crumb.href}
                    className="text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {crumb.label}
                  </Link>
                )}
              </li>
            </Fragment>
          )
        })}
      </ol>
    </nav>
  )
}
