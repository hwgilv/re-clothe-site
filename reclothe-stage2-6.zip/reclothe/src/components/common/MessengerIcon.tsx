import { MessageCircle, Phone, Send } from 'lucide-react'

import type { MessengerId } from '@/lib/domain/types'
import { cn } from '@/lib/utils'

const STYLES: Record<MessengerId, string> = {
  telegram: 'bg-[#229ED9] text-white',
  whatsapp: 'bg-[#25D366] text-[#06210f]',
  vk: 'bg-[#0077FF] text-white',
  call: 'bg-success text-primary-foreground',
}

/** Значок мессенджера: цвет бренда + простой глиф (у VK в lucide значка нет — рисуем буквами). */
export function MessengerIcon({
  id,
  className,
  size = 'md',
}: {
  id: MessengerId
  className?: string
  size?: 'sm' | 'md' | 'lg'
}) {
  const box = size === 'lg' ? 'size-11' : size === 'sm' ? 'size-6' : 'size-9'
  const icon = size === 'lg' ? 'size-5' : size === 'sm' ? 'size-3' : 'size-4'
  return (
    <span
      aria-hidden="true"
      className={cn('inline-flex shrink-0 items-center justify-center rounded-lg', box, STYLES[id], className)}
    >
      {id === 'telegram' ? <Send className={icon} /> : null}
      {id === 'whatsapp' ? <MessageCircle className={icon} /> : null}
      {id === 'call' ? <Phone className={icon} /> : null}
      {id === 'vk' ? (
        <span className={cn('font-mono font-bold leading-none', size === 'sm' ? 'text-2xs' : 'text-xs')}>VK</span>
      ) : null}
    </span>
  )
}
