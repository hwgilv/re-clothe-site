'use client'

import { Component, type ErrorInfo, type ReactNode } from 'react'
import { TriangleAlert } from 'lucide-react'

import { Button } from '@/components/ui/button'

interface ErrorBoundaryProps {
  children: ReactNode
  /** Свой запасной интерфейс; по умолчанию — компактная карточка с кнопкой «Повторить». */
  fallback?: ReactNode
  /** Имя области — попадает в лог, чтобы быстро найти источник ошибки. */
  name?: string
}

interface ErrorBoundaryState {
  hasError: boolean
}

/**
 * Изолирует падение отдельного виджета: остальная страница продолжает работать.
 * Ловит ошибки отрисовки клиентских компонентов (например, графиков Recharts).
 * Ошибки серверных компонентов обрабатываются файлами error.tsx.
 */
export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  override state: ErrorBoundaryState = { hasError: false }

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true }
  }

  override componentDidCatch(error: Error, info: ErrorInfo): void {
    // Этап 6: здесь будет отправка в систему мониторинга (Sentry и т.п.).
    console.error(`[ErrorBoundary:${this.props.name ?? 'без имени'}]`, error, info.componentStack)
  }

  private reset = (): void => {
    this.setState({ hasError: false })
  }

  override render(): ReactNode {
    if (!this.state.hasError) return this.props.children

    return (
      this.props.fallback ?? (
        <div
          role="alert"
          className="flex min-h-32 flex-col items-center justify-center gap-3 p-4 text-center"
        >
          <TriangleAlert className="size-5 text-warning-text" aria-hidden="true" />
          <p className="text-sm text-muted-foreground">Не удалось отобразить этот блок.</p>
          <Button variant="outline" size="sm" onClick={this.reset}>
            Повторить
          </Button>
        </div>
      )
    )
  }
}
