'use client'

import { Droplets, Leaf, Wind } from 'lucide-react'

import { formatNumber } from '@/lib/format'
import { useDerived } from '@/store/AppProvider'

/** Эко-счётчик в футере: суммарный эффект от всех заказов студии — считается из состояния. */
export function EcoFooter() {
  const { eco: totals } = useDerived()

  return (
    <footer className="shrink-0 border-t border-border px-4 py-2.5 lg:px-6">
      <p className="flex flex-wrap items-center gap-x-5 gap-y-1 font-mono text-xs text-muted-foreground">
        <span className="font-medium uppercase tracking-widest text-foreground">Эко-счётчик</span>
        <span className="inline-flex items-center gap-1.5">
          <Leaf className="size-3.5 text-success-text" aria-hidden="true" />
          <strong className="font-semibold text-foreground">
            {formatNumber(totals.textileSavedKg, 1)} кг
          </strong>
          текстиля спасено
        </span>
        <span className="inline-flex items-center gap-1.5">
          <Droplets className="size-3.5 text-success-text" aria-hidden="true" />
          <strong className="font-semibold text-foreground">
            {formatNumber(totals.waterSavedLiters)} л
          </strong>
          воды сэкономлено
        </span>
        <span className="inline-flex items-center gap-1.5">
          <Wind className="size-3.5 text-success-text" aria-hidden="true" />
          <strong className="font-semibold text-foreground">
            {formatNumber(totals.co2PreventedKg)} кг
          </strong>
          CO₂ предотвращено
        </span>
      </p>
    </footer>
  )
}
