import Link from 'next/link'

import { cn } from '@/lib/utils'

interface LogoProps {
  /** Свёрнутый вид — только «RE:». */
  collapsed?: boolean
  className?: string
}

/** Вордмарк студии: двоеточие — акцентного оранжевого цвета. */
export function Logo({ collapsed = false, className }: LogoProps) {
  return (
    <Link
      href="/"
      aria-label="RE:clothe — на главную"
      className={cn(
        'inline-flex items-baseline font-mono text-base font-bold tracking-tight',
        className,
      )}
    >
      <span>RE</span>
      <span className="text-primary">:</span>
      {!collapsed && <span>clothe</span>}
    </Link>
  )
}
