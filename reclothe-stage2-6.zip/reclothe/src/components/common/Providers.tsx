'use client'

import { MotionConfig } from 'framer-motion'

import { SessionProvider } from '@/components/auth/SessionProvider'
import { AuthGate } from '@/components/shell/AuthGate'
import { ToastProvider } from '@/components/ui/toast'
import { AppProvider } from '@/store/AppProvider'
import { UIProvider } from '@/store/ui'

/**
 * Единое динамическое состояние приложения:
 *  AppProvider — данные (заказы, клиенты, склад…) + все производные расчёты;
 *  UIProvider — интерфейс; SessionProvider — роль вкладки.
 */
export function Providers({ children }: { children: React.ReactNode }) {
  return (
    // reducedMotion="user": анимации отключаются, если так настроена система.
    <MotionConfig reducedMotion="user">
      <AppProvider>
        <UIProvider>
          <ToastProvider>
            <SessionProvider>
              <AuthGate>{children}</AuthGate>
            </SessionProvider>
          </ToastProvider>
        </UIProvider>
      </AppProvider>
    </MotionConfig>
  )
}
