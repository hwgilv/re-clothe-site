'use client'

import Link from 'next/link'
import { ArrowRight, TriangleAlert } from 'lucide-react'

import { HBarList } from '@/components/charts/HBarList'
import { PageHeader } from '@/components/common/PageHeader'
import { StatTile } from '@/components/finance/StatTile'
import { DeadlineCell } from '@/components/orders/OrdersView'
import { STAGE_BORDER_CLASS, STAGE_TEXT_CLASS, stageTone } from '@/components/orders/stage-ui'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { useToast } from '@/components/ui/toast'
import { APS_OVERLOAD_THRESHOLD, APS_SHIFT_DAYS, FINAL_STAGE, STAGES } from '@/lib/domain/catalog'
import { initialsOf, shortName } from '@/lib/domain/client'
import type { MasterView, OrderView } from '@/lib/domain/derive'
import { formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'
import { useActions, useApp } from '@/store/AppProvider'

function MasterLoadCard({ item }: { item: MasterView }) {
  const tone = item.load > APS_OVERLOAD_THRESHOLD ? 'destructive' : item.load > 60 ? 'warning' : 'success'
  return (
    <Card>
      <CardContent className="space-y-3 p-4">
        <div className="flex items-center gap-3">
          <span
            aria-hidden="true"
            className="flex size-10 shrink-0 items-center justify-center rounded-full font-mono text-sm font-bold"
            style={{ background: `${item.master.color}33`, color: item.master.color, boxShadow: `inset 0 0 0 1px ${item.master.color}88` }}
          >
            {initialsOf(item.master.name)}
          </span>
          <div className="min-w-0">
            <p className="font-medium leading-tight">{item.master.name}</p>
            <p className="text-xs text-muted-foreground">{item.master.role}</p>
          </div>
          <p
            className={cn(
              'ml-auto font-mono text-2xl font-bold tabular-nums',
              tone === 'destructive' ? 'text-destructive-text' : tone === 'warning' ? 'text-warning-text' : 'text-success-text',
            )}
            data-testid={`load-${item.master.id}`}
          >
            {item.load}%
          </p>
        </div>
        <Progress value={Math.min(100, item.load)} tone={tone} size="lg" aria-label={`Загрузка ${item.master.name}: ${item.load}%`} />
        <p className="text-xs text-muted-foreground">
          Активных задач: <span className="font-mono text-foreground">{item.activeTasks}</span> из {item.master.capacity} одновременных
        </p>
        {item.overloaded ? (
          <p role="alert" className="flex gap-2 rounded-md border border-destructive/50 bg-destructive/10 p-2 text-xs">
            <TriangleAlert className="mt-0.5 size-3.5 shrink-0 text-destructive-text" aria-hidden="true" />
            Загруженность выше {APS_OVERLOAD_THRESHOLD}%: новые заказы сдвигают срок на +{APS_SHIFT_DAYS} дней.
          </p>
        ) : null}
      </CardContent>
    </Card>
  )
}

function BoardCard({ view }: { view: OrderView }) {
  const actions = useActions()
  const toast = useToast()
  const next = view.order.stage + 1
  return (
    <li className="rounded-lg border border-border bg-background p-2.5">
      <div className="flex items-start justify-between gap-2">
        <Link href={`/orders/${view.order.id}`} className="font-mono text-xs font-semibold hover:text-primary-text hover:underline">
          {view.order.number}
        </Link>
        <DeadlineCell view={view} />
      </div>
      <p className="mt-1 line-clamp-2 text-sm leading-tight">{view.service.name}</p>
      <p className="mt-0.5 truncate text-xs text-muted-foreground">
        {view.client ? shortName(view.client) : view.clientName} · {view.master?.name.split(' ')[0] ?? '—'}
      </p>
      <Progress
        value={view.order.stageProgress}
        tone={stageTone(view.order.stage)}
        aria-label={`Прогресс этапа: ${view.order.stageProgress}%`}
        className="mt-2"
      />
      <div className="mt-2 flex items-center justify-between gap-2">
        <span className="font-mono text-2xs text-muted-foreground">
          этап {view.order.stageProgress}% · всего {view.progress}%
        </span>
        <Button
          size="sm"
          variant="outline"
          aria-label={`Перевести ${view.order.number} на этап ${next}`}
          onClick={() => {
            actions.setStage(view.order.id, next, 0)
            if (next === FINAL_STAGE) {
              toast({ title: `${view.order.number}: заказ готов`, description: `ЗП ${formatRub(view.payroll.total)} добавлена к выплате.` })
            }
          }}
        >
          <ArrowRight aria-hidden="true" />
        </Button>
      </div>
    </li>
  )
}

export function ProductionView() {
  const { derived } = useApp()
  const inWork = derived.activeOrders
  const overdue = inWork.filter((view) => view.daysLeft < 0)
  const avg = inWork.length ? Math.round(inWork.reduce((sum, view) => sum + view.progress, 0) / inWork.length) : 0
  const readyUnpaid = derived.orders.filter((view) => view.order.state === 'active' && view.order.completedAt !== null && view.payrollLocked === false)

  const board = STAGES.slice(0, FINAL_STAGE - 1).map((stage) => ({
    stage,
    orders: inWork.filter((view) => view.order.stage === stage.n).sort((a, b) => a.order.deadline.localeCompare(b.order.deadline)),
  }))

  return (
    <div>
      <PageHeader
        title="Производство"
        description="Доска этапов и загрузка мастеров. Перевод заказа по этапам мгновенно меняет проценты в кабинете клиента, ЗП и склад."
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="Заказов в работе" value={String(inWork.length)} testId="prod-active" />
        <StatTile label="Просрочено" value={String(overdue.length)} hint={overdue.length > 0 ? 'нужно связаться с клиентами' : 'всё в срок'} testId="prod-overdue" />
        <StatTile label="Средняя готовность" value={`${avg}%`} hint="по заказам в работе" />
        <StatTile label="Готово, ЗП не выплачена" value={String(readyUnpaid.length)} hint="ждут выплаты в «Бухгалтерии»" />
      </div>

      <section aria-labelledby="loads-heading" className="mb-6">
        <h2 id="loads-heading" className="mb-3 text-lg font-semibold">
          Загрузка мастеров (APS)
        </h2>
        <div className="grid gap-3 md:grid-cols-3">
          {derived.masters.map((item) => (
            <MasterLoadCard key={item.master.id} item={item} />
          ))}
        </div>
      </section>

      <section aria-labelledby="board-heading" className="mb-6">
        <h2 id="board-heading" className="mb-3 text-lg font-semibold">
          Доска этапов
        </h2>
        <div className="grid gap-3 md:flex md:overflow-x-auto md:pb-3 scrollbar-thin">
          {board.map(({ stage, orders }) => {
            const tone = stageTone(stage.n)
            return (
              <section
                key={stage.n}
                aria-label={`Этап ${stage.n}: ${stage.title}`}
                className={cn('flex flex-col rounded-xl border p-2.5 md:w-72 md:shrink-0', STAGE_BORDER_CLASS[tone])}
              >
                <header className="mb-2 flex items-center justify-between gap-2 px-0.5">
                  <h3 className={cn('font-mono text-xs font-semibold uppercase tracking-wide', STAGE_TEXT_CLASS[tone])}>
                    {stage.n}. {stage.title}
                  </h3>
                  <span className="rounded-full bg-background px-2 py-0.5 font-mono text-xs tabular-nums">{orders.length}</span>
                </header>
                {orders.length === 0 ? (
                  <p className="rounded-md border border-dashed border-border/70 px-2 py-4 text-center text-xs text-muted-foreground">Пусто</p>
                ) : (
                  <ul className="space-y-2">
                    {orders.map((view) => (
                      <BoardCard key={view.order.id} view={view} />
                    ))}
                  </ul>
                )}
              </section>
            )
          })}
        </div>
      </section>

      <Card>
        <CardHeader>
          <CardTitle>Заказы по этапам</CardTitle>
        </CardHeader>
        <CardContent>
          <HBarList
            aria-label="Заказов на каждом этапе"
            emptyText="Нет заказов в работе"
            items={STAGES.slice(0, FINAL_STAGE - 1).map((stage, index) => ({
              key: String(stage.n),
              label: `${stage.n}. ${stage.title}`,
              value: derived.pipeline[index] ?? 0,
              display: String(derived.pipeline[index] ?? 0),
            }))}
          />
        </CardContent>
      </Card>
    </div>
  )
}
