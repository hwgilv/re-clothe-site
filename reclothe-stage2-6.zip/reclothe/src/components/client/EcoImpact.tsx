import { Droplets, Leaf, Wind } from 'lucide-react'

import { Progress } from '@/components/ui/progress'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ECO_CO2_KG_PER_KG, ECO_WATER_LITERS_PER_KG } from '@/lib/domain/catalog'
import type { EcoMetrics } from '@/lib/domain/eco'
import { nextMilestoneKg } from '@/lib/domain/eco'
import { formatNumber } from '@/lib/format'

/**
 * «Мой вклад в очистку планеты»: 1 кг текстиля = 2 700 л воды + 10 кг CO₂.
 * Шкалы показывают путь до следующей вехи по спасённым килограммам.
 */
export function EcoImpact({ eco, title = 'Мой вклад в очистку планеты' }: { eco: EcoMetrics; title?: string }) {
  const goal = nextMilestoneKg(eco.textileSavedKg)
  const percent = Math.min(100, (eco.textileSavedKg / goal) * 100)

  const rows = [
    {
      icon: Leaf,
      label: 'Текстиль спасён от свалки',
      value: `${formatNumber(eco.textileSavedKg, 1)} кг`,
      goal: `цель ${formatNumber(goal)} кг`,
    },
    {
      icon: Droplets,
      label: 'Вода сэкономлена',
      value: `${formatNumber(eco.waterSavedLiters)} л`,
      goal: `цель ${formatNumber(goal * ECO_WATER_LITERS_PER_KG)} л`,
    },
    {
      icon: Wind,
      label: 'CO₂ не попало в атмосферу',
      value: `${formatNumber(eco.co2PreventedKg, 1)} кг`,
      goal: `цель ${formatNumber(goal * ECO_CO2_KG_PER_KG)} кг`,
    },
  ] as const

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {rows.map((row) => (
          <div key={row.label}>
            <div className="flex items-baseline justify-between gap-2">
              <span className="flex items-center gap-2 text-sm">
                <row.icon className="size-4 text-success-text" aria-hidden="true" />
                {row.label}
              </span>
              <span className="font-mono text-base font-semibold tabular-nums">{row.value}</span>
            </div>
            <Progress
              value={percent}
              tone="success"
              size="lg"
              aria-label={`${row.label}: ${Math.round(percent)}% пути до цели`}
              className="mt-1.5"
            />
            <p className="mt-1 text-right font-mono text-2xs text-muted-foreground">{row.goal}</p>
          </div>
        ))}
        <p className="rounded-md border border-border bg-background p-2.5 text-xs text-muted-foreground">
          Каждый килограмм текстиля, которому мы дали вторую жизнь, — это {formatNumber(ECO_WATER_LITERS_PER_KG)} л
          сэкономленной воды и {ECO_CO2_KG_PER_KG} кг CO₂, которые не были потрачены на производство новой ткани.
        </p>
      </CardContent>
    </Card>
  )
}
