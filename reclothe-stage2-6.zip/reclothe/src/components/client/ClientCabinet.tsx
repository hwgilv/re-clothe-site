'use client'

import { useMemo, useState } from 'react'
import { LogOut, Phone } from 'lucide-react'

import { useSession } from '@/components/auth/SessionProvider'
import { ClientOrderDetail } from '@/components/client/ClientOrderDetail'
import { EcoImpact } from '@/components/client/EcoImpact'
import { LoyaltyCard } from '@/components/client/LoyaltyCard'
import { Logo } from '@/components/common/Logo'
import { PAYMENT_BADGE } from '@/components/orders/order-ui'
import { StageBar } from '@/components/orders/StageBar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle } from '@/components/ui/card'
import { DataTable, type Column } from '@/components/ui/data-table'
import { EmptyState } from '@/components/ui/empty-state'
import { Tabs } from '@/components/ui/tabs'
import { STUDIO } from '@/lib/domain/catalog'
import type { OrderView } from '@/lib/domain/derive'
import { PAYMENT_STATUS_LABELS } from '@/lib/domain/orders'
import { formatIsoDate, formatRub } from '@/lib/format'
import { useDerived } from '@/store/AppProvider'

type Filter = 'all' | 'active' | 'done'

/** «Личный кабинет Клиента»: карта лояльности, вклад в экологию, живые заказы. */
export function ClientCabinet({ clientId }: { clientId: string }) {
  const { clientById } = useDerived()
  const { logout } = useSession()
  const view = clientById.get(clientId)
  const [filter, setFilter] = useState<Filter>('all')
  const [openId, setOpenId] = useState<string | null>(null)

  const orders = view?.orders ?? []
  const counts = useMemo(
    () => ({
      all: orders.length,
      active: orders.filter((item) => item.order.state === 'active' && item.order.completedAt === null).length,
      done: orders.filter((item) => item.order.completedAt !== null && item.order.state === 'active').length,
    }),
    [orders],
  )
  const visible = useMemo(
    () =>
      orders.filter((item) => {
        if (filter === 'active') return item.order.state === 'active' && item.order.completedAt === null
        if (filter === 'done') return item.order.completedAt !== null && item.order.state === 'active'
        return true
      }),
    [orders, filter],
  )

  if (!view) return null
  const opened = openId ? view.orders.find((item) => item.order.id === openId) : undefined

  const columns: Column<OrderView>[] = [
    {
      key: 'number',
      header: 'Номер',
      mobileTitle: true,
      cell: (row) => (
        <span className="font-mono text-sm font-semibold">{row.order.number}</span>
      ),
    },
    { key: 'date', header: 'Дата', cell: (row) => formatIsoDate(row.order.createdAt), className: 'whitespace-nowrap' },
    {
      key: 'item',
      header: 'Изделие',
      cell: (row) => <span className="line-clamp-2">{row.service.name}</span>,
    },
    {
      key: 'cost',
      header: 'Стоимость',
      align: 'right',
      className: 'whitespace-nowrap font-mono tabular-nums',
      cell: (row) => formatRub(row.pricing.clientTotal),
    },
    {
      key: 'payment',
      header: 'Оплата',
      cell: (row) => (
        <div className="flex flex-col items-start gap-1 md:items-start">
          <Badge variant={row.order.state === 'cancelled' ? 'destructive' : PAYMENT_BADGE[row.paymentStatus]}>
            {row.order.state === 'cancelled' ? 'Возврат' : PAYMENT_STATUS_LABELS[row.paymentStatus]}
          </Badge>
          {row.order.state === 'active' && row.remaining > 0 ? (
            <span className="font-mono text-2xs text-muted-foreground">осталось {formatRub(row.remaining)}</span>
          ) : null}
        </div>
      ),
    },
    {
      key: 'stage',
      header: 'Статус производства',
      className: 'min-w-[17rem]',
      cell: (row) => <StageBar view={row} className="text-left" />,
    },
  ]

  return (
    <div className="min-h-dvh bg-vignette">
      <div className="h-1.5 bg-hazard" aria-hidden="true" />
      <header className="sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-3 sm:px-4">
          <div className="flex min-w-0 items-center gap-3">
            <Logo />
            <span className="hidden truncate font-mono text-2xs uppercase tracking-widest text-muted-foreground sm:block">
              Личный кабинет Клиента
            </span>
          </div>
          <Button variant="outline" size="sm" onClick={logout}>
            <LogOut aria-hidden="true" />
            Выйти
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-5 px-3 py-5 sm:px-4">
        <div>
          <p className="font-mono text-2xs uppercase tracking-widest text-muted-foreground sm:hidden">
            Личный кабинет Клиента
          </p>
          <h1 className="mt-1 text-xl font-semibold sm:mt-0">Здравствуйте, {view.client.firstName}!</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Здесь видно, на каком этапе ваши вещи, и сколько баллов вы накопили.
          </p>
        </div>

        <div className="grid gap-5 lg:grid-cols-2">
          <LoyaltyCard view={view} />
          <EcoImpact eco={view.eco} />
        </div>

        <section aria-labelledby="my-orders" className="space-y-3">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <h2 id="my-orders" className="text-lg font-semibold">
              Мои заказы
            </h2>
            <Tabs<Filter>
              aria-label="Фильтр заказов"
              value={filter}
              onChange={setFilter}
              tabs={[
                { value: 'all', label: `Все · ${counts.all}` },
                { value: 'active', label: `В работе · ${counts.active}` },
                { value: 'done', label: `Готовы · ${counts.done}` },
              ]}
            />
          </div>

          <DataTable
            caption="Мои заказы"
            columns={columns}
            rows={visible}
            rowKey={(row) => row.order.id}
            onRowClick={(row) => setOpenId(row.order.id)}
            empty={
              <EmptyState
                title={orders.length === 0 ? 'Заказов пока нет' : 'В этой категории заказов нет'}
                description={
                  orders.length === 0
                    ? 'Мы свяжемся с вами в выбранном мессенджере, обсудим эскиз и снимем мерки.'
                    : 'Попробуйте другой фильтр.'
                }
              />
            }
            mobileCard={(row) => (
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-mono text-sm font-semibold">{row.order.number}</p>
                    <p className="mt-0.5 text-sm">{row.service.name}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">от {formatIsoDate(row.order.createdAt)}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="font-mono text-sm font-semibold tabular-nums">{formatRub(row.pricing.clientTotal)}</p>
                    <Badge
                      className="mt-1"
                      variant={row.order.state === 'cancelled' ? 'destructive' : PAYMENT_BADGE[row.paymentStatus]}
                    >
                      {row.order.state === 'cancelled' ? 'Возврат' : PAYMENT_STATUS_LABELS[row.paymentStatus]}
                    </Badge>
                  </div>
                </div>
                <StageBar view={row} />
              </div>
            )}
          />
        </section>

        <Card>
          <CardHeader>
            <CardTitle>Связь со студией</CardTitle>
          </CardHeader>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 p-4 text-sm">
            <span>
              Администратор свяжется с вами через{' '}
              <strong className="font-semibold">{contactLabel(view.client.contact)}</strong>.
            </span>
            <a
              href={`tel:${STUDIO.phone.replace(/[^\d+]/g, '')}`}
              className="inline-flex items-center gap-1.5 text-primary-text underline-offset-2 hover:underline"
            >
              <Phone className="size-3.5" aria-hidden="true" />
              {STUDIO.phone}
            </a>
          </div>
        </Card>
      </main>

      <ClientOrderDetail view={opened ?? null} onClose={() => setOpenId(null)} />
    </div>
  )
}

function contactLabel(id: string): string {
  switch (id) {
    case 'telegram':
      return 'Telegram'
    case 'vk':
      return 'VK'
    case 'whatsapp':
      return 'WhatsApp'
    default:
      return 'звонок'
  }
}
