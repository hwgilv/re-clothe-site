'use client'

import { Modal } from '@/components/ui/modal'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { StageBar } from '@/components/orders/StageBar'
import { StageTrack } from '@/components/orders/StageTrack'
import { PAYMENT_BADGE } from '@/components/orders/order-ui'
import type { OrderView } from '@/lib/domain/derive'
import { PAYMENT_STATUS_LABELS } from '@/lib/domain/orders'
import { formatDateString } from '@/lib/date'
import { formatIsoDate, formatRub, pluralDays } from '@/lib/format'

/** Карточка заказа для клиента: этапы, оплата, срок. Без внутренних цифр студии (ЗП, маржа). */
export function ClientOrderDetail({ view, onClose }: { view: OrderView | null; onClose: () => void }) {
  return (
    <Modal
      open={view !== null}
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      size="lg"
      title={view ? `Заказ ${view.order.number}` : 'Заказ'}
      description={view ? `${view.service.name} · от ${formatIsoDate(view.order.createdAt)}` : undefined}
    >
      {view ? (
        <div className="space-y-5">
          <StageBar view={view} />
          <StageTrack view={view} />

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-lg border border-border bg-background p-3">
              <p className="font-mono text-2xs uppercase tracking-widest text-muted-foreground">Оплата</p>
              <p className="mt-1 font-mono text-lg font-semibold tabular-nums">{formatRub(view.pricing.clientTotal)}</p>
              <Badge
                className="mt-1"
                variant={view.order.state === 'cancelled' ? 'destructive' : PAYMENT_BADGE[view.paymentStatus]}
              >
                {view.order.state === 'cancelled' ? 'Возврат' : PAYMENT_STATUS_LABELS[view.paymentStatus]}
              </Badge>
              <Progress value={view.paidPercent} tone="success" aria-label={`Оплачено ${view.paidPercent}%`} className="mt-3" />
              <p className="mt-1.5 flex justify-between text-xs text-muted-foreground">
                <span>Оплачено: {formatRub(view.paid)}</span>
                <span>Остаток: {formatRub(view.remaining)}</span>
              </p>
            </div>

            <div className="rounded-lg border border-border bg-background p-3">
              <p className="font-mono text-2xs uppercase tracking-widest text-muted-foreground">Срок готовности</p>
              <p className="mt-1 font-mono text-lg font-semibold tabular-nums">{formatDateString(view.order.deadline)}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {view.order.completedAt !== null
                  ? 'Заказ готов — можно забирать.'
                  : view.daysLeft >= 0
                    ? `Осталось ${pluralDays(view.daysLeft)}`
                    : `Срок сдвинулся: просрочка ${pluralDays(-view.daysLeft)}`}
              </p>
              {view.order.apsShiftDays > 0 ? (
                <p className="mt-2 text-xs text-warning-text">
                  Срок сдвинут на {pluralDays(view.order.apsShiftDays)} из-за загрузки мастера.
                </p>
              ) : null}
              <p className="mt-2 text-xs text-muted-foreground">Мастер: {view.master?.name ?? '—'}</p>
            </div>
          </div>

          {view.order.donors.length > 0 ? (
            <div>
              <p className="mb-2 font-mono text-2xs uppercase tracking-widest text-muted-foreground">Ваши вещи-доноры</p>
              <ul className="space-y-1.5">
                {view.order.donors.map((donor) => (
                  <li
                    key={donor.id}
                    className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm"
                  >
                    <span className="min-w-0 truncate">{donor.title}</span>
                    <span className="shrink-0 font-mono text-xs text-muted-foreground">
                      {donor.code} · {donor.weightKg} кг
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      ) : null}
    </Modal>
  )
}
