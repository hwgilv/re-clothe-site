import { Coins, Gem } from 'lucide-react'

import { Progress } from '@/components/ui/progress'
import type { ClientView } from '@/lib/domain/derive'
import { RUB_PER_COIN } from '@/lib/domain/catalog'
import { formatNumber, formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'

/**
 * Карта лояльности: цвет и статус зависят от суммы, оплаченной по заказам клиента.
 * Бронза ≤ 10 000 ₽ · Серебро ≤ 25 000 · Золото ≤ 50 000 · Платина ≤ 100 000 · Бриллиант > 100 000.
 */
export function LoyaltyCard({ view, className }: { view: ClientView; className?: string }) {
  const { tier, coins, spent, tierProgress: progress } = view

  return (
    <section
      aria-label={`Карта лояльности: ${tier.label}`}
      data-tier={tier.id}
      className={cn('relative isolate overflow-hidden rounded-3xl p-5 sm:p-6', className)}
      style={{
        backgroundImage: `linear-gradient(135deg, ${tier.from} 0%, ${tier.to} 100%)`,
        color: tier.text,
        boxShadow: `0 0 0 1px ${tier.glow}88, 0 0 28px 2px ${tier.glow}66, 0 0 70px 6px ${tier.glow}33`,
      }}
    >
      {/* Неоновое свечение по контуру и блик. */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10 animate-glow-pulse rounded-3xl"
        style={{ boxShadow: `inset 0 0 36px ${tier.glow}55` }}
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-16 -top-16 -z-10 size-56 rounded-full opacity-30 blur-2xl"
        style={{ background: tier.glow }}
      />

      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-mono text-2xs uppercase tracking-[0.25em] opacity-80">RE:clothe · карта лояльности</p>
          <p
            className="mt-2 font-mono text-2xl font-bold uppercase leading-tight tracking-wide sm:text-3xl"
            data-testid="loyalty-tier"
          >
            {tier.label}
          </p>
        </div>
        <Gem className="size-8 shrink-0 opacity-90" aria-hidden="true" />
      </div>

      <p className="mt-5 text-lg font-semibold leading-tight">{view.name}</p>

      <div className="mt-4 flex flex-wrap items-end justify-between gap-x-6 gap-y-2">
        <div>
          <p className="font-mono text-2xs uppercase tracking-widest opacity-80">Баланс RE-coins</p>
          <p className="mt-0.5 flex items-center gap-2 font-mono text-3xl font-bold tabular-nums" data-testid="loyalty-coins">
            <Coins className="size-6" aria-hidden="true" />
            {formatNumber(coins)}
          </p>
        </div>
        <div className="text-right">
          <p className="font-mono text-2xs uppercase tracking-widest opacity-80">Сумма покупок</p>
          <p className="mt-0.5 font-mono text-lg font-semibold tabular-nums">{formatRub(spent)}</p>
        </div>
      </div>

      <div className="mt-4 rounded-xl bg-black/25 p-3">
        {progress.next ? (
          <>
            <div className="mb-1.5 flex flex-wrap items-center justify-between gap-1 text-xs">
              <span>До статуса «{progress.next.label}»</span>
              <span className="font-mono font-semibold">{formatRub(progress.remaining)}</span>
            </div>
            <Progress
              value={progress.fraction * 100}
              aria-label={`Прогресс до статуса ${progress.next.label}`}
              className="bg-black/40"
            />
          </>
        ) : (
          <p className="text-xs">Максимальный статус — спасибо, что вы с нами!</p>
        )}
        <p className="mt-2 text-2xs opacity-80">
          1 RE-coin начисляется за каждые {RUB_PER_COIN} ₽ в чеке.
          {view.tierOverridden ? ' Статус назначен администратором.' : ''}
        </p>
      </div>
    </section>
  )
}
