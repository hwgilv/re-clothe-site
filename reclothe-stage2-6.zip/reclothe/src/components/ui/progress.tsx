import { cn } from '@/lib/utils'

export type ProgressTone = 'primary' | 'success' | 'warning' | 'destructive' | 'denim'

const TONE_CLASSES: Record<ProgressTone, string> = {
  primary: 'bg-primary',
  success: 'bg-success',
  warning: 'bg-warning',
  destructive: 'bg-destructive',
  denim: 'bg-denim',
}

interface ProgressProps {
  value: number
  max?: number
  tone?: ProgressTone
  className?: string
  /** Обязателен: у индикатора без текстовой подписи нет доступного имени. */
  'aria-label': string
  /** Толщина полосы: по умолчанию тонкая, `lg` — для главных индикаторов. */
  size?: 'sm' | 'lg'
}

/** Простой индикатор прогресса. Значения вне диапазона обрезаются до [0, max]. */
export function Progress({
  value,
  max = 100,
  tone = 'primary',
  className,
  'aria-label': ariaLabel,
  size = 'sm',
}: ProgressProps) {
  const clamped = Math.min(max, Math.max(0, value))
  const percent = max > 0 ? (clamped / max) * 100 : 0

  return (
    <div
      role="progressbar"
      aria-label={ariaLabel}
      aria-valuemin={0}
      aria-valuemax={max}
      aria-valuenow={Math.round(clamped)}
      className={cn(
        'w-full overflow-hidden rounded-full bg-muted',
        size === 'lg' ? 'h-3' : 'h-1.5',
        className,
      )}
    >
      <div
        className={cn('h-full rounded-full transition-[width] duration-500', TONE_CLASSES[tone])}
        style={{ width: `${percent}%` }}
      />
    </div>
  )
}
