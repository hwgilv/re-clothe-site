import { cn } from '@/lib/utils'

export interface Column<T> {
  key: string
  header: string
  cell: (row: T) => React.ReactNode
  /** Выравнивание ячейки в таблице. */
  align?: 'left' | 'right' | 'center'
  className?: string
  /** Подпись на карточке (по умолчанию — заголовок колонки). */
  mobileLabel?: string
  /** Не показывать эту колонку в карточке на телефоне. */
  hideOnMobile?: boolean
  /** Заголовок карточки: колонка выводится крупно без подписи. */
  mobileTitle?: boolean
}

interface DataTableProps<T> {
  columns: readonly Column<T>[]
  rows: readonly T[]
  rowKey: (row: T) => string
  /** Клик по строке/карточке. */
  onRowClick?: (row: T) => void
  caption: string
  /** Своя карточка для телефона вместо автоматической. */
  mobileCard?: (row: T) => React.ReactNode
  empty?: React.ReactNode
  rowClassName?: (row: T) => string | undefined
  className?: string
}

const ALIGN = { left: 'text-left', right: 'text-right', center: 'text-center' } as const

/**
 * Адаптивная таблица. От 768 px — обычная таблица; на телефоне та же информация
 * перестраивается в вертикальные карточки, удобные для касаний (крупные зоны нажатия,
 * подписи «поле: значение», без горизонтальной прокрутки).
 */
export function DataTable<T>({
  columns,
  rows,
  rowKey,
  onRowClick,
  caption,
  mobileCard,
  empty,
  rowClassName,
  className,
}: DataTableProps<T>) {
  if (rows.length === 0 && empty) return <>{empty}</>

  const titleColumn = columns.find((column) => column.mobileTitle) ?? columns[0]
  const detailColumns = columns.filter((column) => column !== titleColumn && !column.hideOnMobile)

  return (
    <div className={className}>
      {/* Компьютер и планшет */}
      <div className="hidden overflow-x-auto rounded-lg border border-border bg-surface md:block scrollbar-thin">
        <table className="w-full min-w-[40rem] border-collapse text-sm">
          <caption className="sr-only">{caption}</caption>
          <thead>
            <tr className="border-b border-border">
              {columns.map((column) => (
                <th
                  key={column.key}
                  scope="col"
                  className={cn(
                    'whitespace-nowrap px-3 py-2.5 font-mono text-2xs font-medium uppercase tracking-widest text-muted-foreground',
                    ALIGN[column.align ?? 'left'],
                  )}
                >
                  {column.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr
                key={rowKey(row)}
                onClick={onRowClick ? () => onRowClick(row) : undefined}
                className={cn(
                  'border-b border-border/60 last:border-0',
                  onRowClick && 'cursor-pointer transition-colors hover:bg-muted/60',
                  rowClassName?.(row),
                )}
              >
                {columns.map((column) => (
                  <td
                    key={column.key}
                    className={cn('px-3 py-3 align-middle', ALIGN[column.align ?? 'left'], column.className)}
                  >
                    {column.cell(row)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Телефон: вертикальные карточки */}
      <ul className="space-y-2.5 md:hidden" aria-label={caption}>
        {rows.map((row) => {
          const content = mobileCard ? (
            mobileCard(row)
          ) : (
            <>
              {titleColumn ? (
                <div className="mb-2 text-sm font-medium">{titleColumn.cell(row)}</div>
              ) : null}
              <dl className="space-y-1.5">
                {detailColumns.map((column) => (
                  <div key={column.key} className="flex items-start justify-between gap-3 text-sm">
                    <dt className="shrink-0 font-mono text-2xs uppercase tracking-wider text-muted-foreground">
                      {column.mobileLabel ?? column.header}
                    </dt>
                    <dd className="min-w-0 text-right">{column.cell(row)}</dd>
                  </div>
                ))}
              </dl>
            </>
          )
          return (
            <li
              key={rowKey(row)}
              className={cn(
                'rounded-lg border border-border bg-surface p-3.5',
                onRowClick && 'cursor-pointer transition-colors active:bg-muted/60',
                rowClassName?.(row),
              )}
              onClick={onRowClick ? () => onRowClick(row) : undefined}
            >
              {content}
            </li>
          )
        })}
      </ul>
    </div>
  )
}
