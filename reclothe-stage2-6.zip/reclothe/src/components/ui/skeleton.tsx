import { cn } from '@/lib/utils'

/** Заглушка загрузки. aria-hidden: скринридеру достаточно aria-busy у контейнера. */
export function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      aria-hidden="true"
      className={cn('animate-pulse rounded-md bg-muted', className)}
      {...props}
    />
  )
}
