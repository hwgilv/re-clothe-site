'use client'

import { useId } from 'react'

import { cn } from '@/lib/utils'

export interface TabOption<T extends string> {
  value: T
  label: string
  /** Число-бейдж рядом с названием (например, новые лиды). */
  count?: number
}

interface TabsProps<T extends string> {
  value: T
  onChange: (value: T) => void
  tabs: readonly TabOption<T>[]
  'aria-label': string
  className?: string
}

/** Вкладки-переключатель. Горизонтально прокручиваются на узком экране. */
export function Tabs<T extends string>({
  value,
  onChange,
  tabs,
  'aria-label': ariaLabel,
  className,
}: TabsProps<T>) {
  const id = useId()
  return (
    <div
      role="tablist"
      aria-label={ariaLabel}
      className={cn('-mx-1 flex gap-1 overflow-x-auto px-1 pb-1 scrollbar-thin', className)}
    >
      {tabs.map((tab) => {
        const active = tab.value === value
        return (
          <button
            key={tab.value}
            id={`${id}-${tab.value}`}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(tab.value)}
            className={cn(
              'inline-flex h-9 shrink-0 items-center gap-2 rounded-md border px-3 font-mono text-xs uppercase tracking-wider transition-colors',
              active
                ? 'border-primary bg-primary/10 text-primary-text'
                : 'border-border text-muted-foreground hover:bg-muted hover:text-foreground',
            )}
          >
            {tab.label}
            {tab.count !== undefined && tab.count > 0 ? (
              <span className="rounded-full bg-primary px-1.5 text-2xs font-semibold text-primary-foreground">
                {tab.count}
              </span>
            ) : null}
          </button>
        )
      })}
    </div>
  )
}
