'use client'

import { cn } from '@/lib/utils'

interface ChipToggleProps {
  pressed: boolean
  onPressedChange: (pressed: boolean) => void
  children: React.ReactNode
  className?: string
  disabled?: boolean
  title?: string
}

/** Кнопка-переключатель (чекбокс) — крупная цель для пальца. */
export function ChipToggle({ pressed, onPressedChange, children, className, disabled, title }: ChipToggleProps) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={pressed}
      disabled={disabled}
      title={title}
      onClick={() => onPressedChange(!pressed)}
      className={cn(
        'flex min-h-10 items-center gap-2.5 rounded-md border px-3 py-2 text-left text-sm transition-colors disabled:opacity-50',
        pressed
          ? 'border-primary bg-primary/10 text-foreground'
          : 'border-input bg-background text-muted-foreground hover:bg-muted hover:text-foreground',
        className,
      )}
    >
      <span
        aria-hidden="true"
        className={cn(
          'flex size-4 shrink-0 items-center justify-center rounded-sm border text-2xs font-bold leading-none',
          pressed ? 'border-primary bg-primary text-primary-foreground' : 'border-input',
        )}
      >
        {pressed ? '✓' : ''}
      </span>
      <span className="min-w-0 flex-1">{children}</span>
    </button>
  )
}
