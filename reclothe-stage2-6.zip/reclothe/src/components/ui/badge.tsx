import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'

import { cn } from '@/lib/utils'

const badgeVariants = cva(
  'inline-flex items-center gap-1 rounded-sm border px-1.5 py-0.5 font-mono text-2xs font-medium uppercase tracking-wide',
  {
    variants: {
      variant: {
        default: 'border-primary/30 bg-primary/10 text-primary-text',
        success: 'border-success/30 bg-success/10 text-success-text',
        warning: 'border-warning/30 bg-warning/10 text-warning-text',
        destructive: 'border-destructive/30 bg-destructive/10 text-destructive-text',
        denim: 'border-denim/40 bg-denim/15 text-denim-text',
        muted: 'border-border bg-muted text-muted-foreground',
        outline: 'border-border text-foreground',
      },
    },
    defaultVariants: { variant: 'default' },
  },
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>, VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />
}

export { badgeVariants }
