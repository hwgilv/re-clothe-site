'use client'

import { Minus, Plus } from 'lucide-react'

import { cn } from '@/lib/utils'

interface StepperProps {
  value: number
  onChange: (value: number) => void
  /** Что считаем — нужно для озвучки кнопок: «Больше: Люверс». */
  label: string
  min?: number
  max?: number
  step?: number
  className?: string
}

function round(value: number): number {
  return Math.round(value * 100) / 100
}

/** Счётчик количества с крупными кнопками, удобными для пальца. */
export function Stepper({ value, onChange, label, min = 0, max = 999, step = 1, className }: StepperProps) {
  const set = (next: number): void => onChange(Math.min(max, Math.max(min, round(next))))

  return (
    <div
      className={cn('inline-flex items-center overflow-hidden rounded-md border border-input', className)}
      role="group"
      aria-label={label}
    >
      <button
        type="button"
        onClick={() => set(value - step)}
        disabled={value <= min}
        aria-label={`Меньше: ${label}`}
        className="flex size-9 items-center justify-center bg-background text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:opacity-40"
      >
        <Minus className="size-4" aria-hidden="true" />
      </button>
      <output
        aria-live="polite"
        className="min-w-9 bg-surface px-2 text-center font-mono text-sm tabular-nums"
      >
        {value}
      </output>
      <button
        type="button"
        onClick={() => set(value + step)}
        disabled={value >= max}
        aria-label={`Больше: ${label}`}
        className="flex size-9 items-center justify-center bg-background text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:opacity-40"
      >
        <Plus className="size-4" aria-hidden="true" />
      </button>
    </div>
  )
}
