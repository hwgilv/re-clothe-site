'use client'

import { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react'
import { CircleAlert, CircleCheck, Info, X } from 'lucide-react'

import { cn } from '@/lib/utils'

type ToastTone = 'success' | 'info' | 'danger'

interface ToastItem {
  id: number
  tone: ToastTone
  title: string
  description?: string | undefined
}

interface ToastApi {
  toast: (input: { title: string; description?: string; tone?: ToastTone }) => void
}

const ToastContext = createContext<ToastApi | null>(null)

const AUTO_CLOSE_MS = 4500

const TONE_STYLES: Record<ToastTone, string> = {
  success: 'border-success/40',
  info: 'border-denim/50',
  danger: 'border-destructive/50',
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([])
  const counter = useRef(0)

  const dismiss = useCallback((id: number) => {
    setItems((current) => current.filter((item) => item.id !== id))
  }, [])

  const toast = useCallback<ToastApi['toast']>(
    ({ title, description, tone = 'success' }) => {
      counter.current += 1
      const id = counter.current
      setItems((current) => [...current.slice(-3), { id, tone, title, description }])
      window.setTimeout(() => dismiss(id), AUTO_CLOSE_MS)
    },
    [dismiss],
  )

  const api = useMemo(() => ({ toast }), [toast])

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div
        aria-live="polite"
        className="no-print pointer-events-none fixed inset-x-3 bottom-3 z-[70] flex flex-col items-center gap-2 sm:inset-x-auto sm:right-4 sm:items-end"
      >
        {items.map((item) => (
          <div
            key={item.id}
            role="status"
            className={cn(
              'pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-lg border bg-surface p-3 shadow-xl animate-in fade-in-0 slide-in-from-bottom-2',
              TONE_STYLES[item.tone],
            )}
          >
            {item.tone === 'success' ? (
              <CircleCheck className="mt-0.5 size-4 shrink-0 text-success-text" aria-hidden="true" />
            ) : item.tone === 'danger' ? (
              <CircleAlert className="mt-0.5 size-4 shrink-0 text-destructive-text" aria-hidden="true" />
            ) : (
              <Info className="mt-0.5 size-4 shrink-0 text-denim-text" aria-hidden="true" />
            )}
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium">{item.title}</p>
              {item.description ? (
                <p className="mt-0.5 text-xs text-muted-foreground">{item.description}</p>
              ) : null}
            </div>
            <button
              type="button"
              onClick={() => dismiss(item.id)}
              aria-label="Закрыть уведомление"
              className="text-muted-foreground transition-colors hover:text-foreground"
            >
              <X className="size-4" aria-hidden="true" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export function useToast(): ToastApi['toast'] {
  const api = useContext(ToastContext)
  if (!api) throw new Error('useToast должен вызываться внутри <ToastProvider>')
  return api.toast
}
