'use client'

import { useMemo, useRef, useState } from 'react'
import { Download, KeyRound, RotateCcw, Trash2, Upload } from 'lucide-react'

import { useSession } from '@/components/auth/SessionProvider'
import { PageHeader } from '@/components/common/PageHeader'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { DataTable, type Column } from '@/components/ui/data-table'
import { Field } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Modal } from '@/components/ui/modal'
import { Select } from '@/components/ui/select'
import { Tabs } from '@/components/ui/tabs'
import { useToast } from '@/components/ui/toast'
import { MIN_PASSWORD_LENGTH, setAdminPassword, verifyAdminPassword } from '@/lib/auth/password'
import { CATEGORIES, SERVICES, getBaseService } from '@/lib/domain/catalog'
import { resolveService } from '@/lib/domain/orders'
import type { Master, Service } from '@/lib/domain/types'
import { toDateString } from '@/lib/date'
import { formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'
import { useActions, useApp } from '@/store/AppProvider'
import { serializeState } from '@/store/storage'

type TabId = 'tariffs' | 'masters' | 'security' | 'data'

/** Числовое поле, которое применяется по уходу фокуса или Enter. */
function RateInput({
  label,
  value,
  onCommit,
  changed,
}: {
  label: string
  value: number
  onCommit: (value: number) => void
  changed: boolean
}) {
  const [text, setText] = useState(String(value))
  const commit = (): void => {
    const parsed = Number.parseInt(text.replace(/\D/g, ''), 10)
    if (!Number.isFinite(parsed) || parsed <= 0) {
      setText(String(value))
      return
    }
    if (parsed !== value) onCommit(parsed)
    setText(String(parsed))
  }
  return (
    <Input
      aria-label={label}
      inputMode="numeric"
      value={text}
      onChange={(event) => setText(event.target.value.replace(/[^\d]/g, ''))}
      onBlur={commit}
      onKeyDown={(event) => {
        if (event.key === 'Enter') {
          event.preventDefault()
          commit()
        }
      }}
      className={cn('h-9 w-28 text-right font-mono', changed && 'border-primary')}
    />
  )
}

function TariffsTab() {
  const { state } = useApp()
  const actions = useActions()
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('all')

  const rows = useMemo(() => {
    const text = query.trim().toLowerCase()
    return SERVICES.filter(
      (service) =>
        (category === 'all' || service.categoryId === category) &&
        (!text || service.name.toLowerCase().includes(text) || service.id.includes(text)),
    ).map((service) => resolveService(service.id, state.serviceOverrides) ?? service)
  }, [query, category, state.serviceOverrides])

  const commit = (service: Service, patch: { masterRate?: number; clientPrice?: number }): void => {
    const base = getBaseService(service.id)
    if (!base) return
    const masterRate = patch.masterRate ?? service.masterRate
    const clientPrice = patch.clientPrice ?? service.clientPrice
    const override = {
      ...(masterRate !== base.masterRate ? { masterRate } : {}),
      ...(clientPrice !== base.clientPrice ? { clientPrice } : {}),
    }
    actions.setServiceOverride(service.id, Object.keys(override).length > 0 ? override : null)
  }

  const columns: Column<Service>[] = [
    { key: 'id', header: '№', cell: (service) => <span className="font-mono text-xs text-muted-foreground">{service.id}</span> },
    {
      key: 'name',
      header: 'Услуга',
      mobileTitle: true,
      cell: (service) => (
        <div className="min-w-0">
          <p className="leading-tight">{service.name}</p>
          <p className="text-xs text-muted-foreground">{CATEGORIES.find((item) => item.id === service.categoryId)?.title}</p>
        </div>
      ),
    },
    {
      key: 'master',
      header: 'Ставка мастера, ₽',
      align: 'right',
      cell: (service) => {
        const base = getBaseService(service.id)
        return (
          <RateInput
            key={`m-${service.id}-${service.masterRate}`}
            label={`Ставка мастера: ${service.name}`}
            value={service.masterRate}
            changed={base?.masterRate !== service.masterRate}
            onCommit={(masterRate) => commit(service, { masterRate })}
          />
        )
      },
    },
    {
      key: 'client',
      header: 'Цена клиента, ₽',
      align: 'right',
      cell: (service) => {
        const base = getBaseService(service.id)
        return (
          <RateInput
            key={`c-${service.id}-${service.clientPrice}`}
            label={`Цена клиента: ${service.name}`}
            value={service.clientPrice}
            changed={base?.clientPrice !== service.clientPrice}
            onCommit={(clientPrice) => commit(service, { clientPrice })}
          />
        )
      },
    },
    {
      key: 'margin',
      header: 'Маржа при К=1',
      align: 'right',
      cell: (service) => {
        const margin = service.clientPrice - service.masterRate
        return (
          <span className={cn('font-mono text-xs tabular-nums', margin < 0 ? 'text-destructive-text' : 'text-success-text')}>
            {formatRub(margin)} · {Math.round((margin / service.clientPrice) * 100)}%
          </span>
        )
      },
    },
    {
      key: 'reset',
      header: '',
      align: 'right',
      cell: (service) =>
        state.serviceOverrides[service.id] ? (
          <Button variant="ghost" size="sm" onClick={() => actions.setServiceOverride(service.id, null)}>
            <RotateCcw aria-hidden="true" />
            Сбросить
          </Button>
        ) : null,
    },
  ]

  const changed = Object.keys(state.serviceOverrides).length

  return (
    <div className="space-y-4">
      <p className="rounded-lg border border-border bg-surface p-3 text-sm text-muted-foreground">
        Ставки мастеров — из таблицы 7.3 бизнес-плана; цены клиентов для услуг, где плана нет, рассчитаны как ставка × 2,3.
        Новая цена применяется к <strong className="text-foreground">новым заказам</strong>; уже созданные заказы сохраняют тариф,
        согласованный с клиентом. Изменено позиций: <span className="font-mono text-foreground">{changed}</span>.
      </p>
      <div className="grid gap-2 sm:grid-cols-[1fr_16rem]">
        <Input type="search" aria-label="Поиск услуги" placeholder="Поиск по названию или номеру…" value={query} onChange={(event) => setQuery(event.target.value)} />
        <Select aria-label="Категория" value={category} onChange={(event) => setCategory(event.target.value)}>
          <option value="all">Все категории</option>
          {CATEGORIES.map((item) => (
            <option key={item.id} value={item.id}>
              {item.title}
            </option>
          ))}
        </Select>
      </div>
      <DataTable caption="Тарифная сетка" columns={columns} rows={rows} rowKey={(service) => service.id} />
    </div>
  )
}

function MastersTab() {
  const { state, derived } = useApp()
  const actions = useActions()
  const toast = useToast()

  const columns: Column<Master>[] = [
    { key: 'name', header: 'Мастер', mobileTitle: true, cell: (master) => <span className="font-medium">{master.name}</span> },
    { key: 'role', header: 'Специализация', cell: (master) => <span className="text-xs text-muted-foreground">{master.role}</span> },
    { key: 'contract', header: 'Договор', cell: (master) => <span className="font-mono text-xs">{master.contractNo}</span> },
    {
      key: 'capacity',
      header: 'Задач одновременно (=100%)',
      align: 'right',
      cell: (master) => (
        <RateInput
          key={`${master.id}-${master.capacity}`}
          label={`Ёмкость мастера ${master.name}`}
          value={master.capacity}
          changed={false}
          onCommit={(capacity) => {
            actions.updateMaster(master.id, { capacity })
            toast({ title: `${master.name}: ёмкость ${capacity}`, description: 'Загрузка и сроки APS пересчитаны.' })
          }}
        />
      ),
    },
    {
      key: 'load',
      header: 'Загрузка сейчас',
      align: 'right',
      cell: (master) => <span className="font-mono tabular-nums">{derived.masterById.get(master.id)?.load ?? 0}%</span>,
    },
  ]

  return (
    <div className="space-y-4">
      <p className="rounded-lg border border-border bg-surface p-3 text-sm text-muted-foreground">
        Загрузка мастера = число активных задач ÷ ёмкость. Если после нового заказа загрузка выше 80%, срок автоматически сдвигается на +14 дней.
      </p>
      <DataTable caption="Мастера" columns={columns} rows={state.masters} rowKey={(master) => master.id} />
    </div>
  )
}

function SecurityTab() {
  const toast = useToast()
  const { logout } = useSession()
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [repeat, setRepeat] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (event: React.FormEvent): Promise<void> => {
    event.preventDefault()
    setError(null)
    if (next.length < MIN_PASSWORD_LENGTH) {
      setError(`Новый пароль — не короче ${MIN_PASSWORD_LENGTH} символов.`)
      return
    }
    if (next !== repeat) {
      setError('Новые пароли не совпадают.')
      return
    }
    setBusy(true)
    const valid = await verifyAdminPassword(current)
    if (!valid) {
      setBusy(false)
      setError('Текущий пароль неверный.')
      return
    }
    const saved = await setAdminPassword(next)
    setBusy(false)
    if (!saved) {
      setError('Браузер не дал сохранить пароль.')
      return
    }
    setCurrent('')
    setNext('')
    setRepeat('')
    toast({ title: 'Мастер-пароль изменён', description: 'Новый пароль сохранён в браузере навсегда.' })
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Мастер-пароль</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} noValidate className="space-y-3">
            <Field label="Текущий пароль" htmlFor="pw-current">
              <Input id="pw-current" type="password" autoComplete="current-password" value={current} onChange={(event) => setCurrent(event.target.value)} />
            </Field>
            <Field label="Новый пароль" htmlFor="pw-new">
              <Input id="pw-new" type="password" autoComplete="new-password" value={next} onChange={(event) => setNext(event.target.value)} />
            </Field>
            <Field label="Повторите новый пароль" htmlFor="pw-repeat" error={error ?? undefined}>
              <Input
                id="pw-repeat"
                type="password"
                autoComplete="new-password"
                value={repeat}
                onChange={(event) => setRepeat(event.target.value)}
                aria-invalid={Boolean(error) || undefined}
                aria-describedby={error ? 'pw-repeat-error' : undefined}
              />
            </Field>
            <Button type="submit" disabled={busy}>
              <KeyRound aria-hidden="true" />
              Сменить пароль
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Сессия</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <p>
            Пока вы в админ-панели, вход администратора в других вкладках этого браузера блокируется («Доступ ограничен,
            сессия активна»). Выйдите, чтобы освободить доступ.
          </p>
          <p className="rounded-md border border-border bg-background p-2.5 text-xs">
            Это защита уровня «чужой не зайдёт по ошибке»: пароль и данные хранятся в браузере. Для настоящей защиты нужен
            сервер с авторизацией — он появится вместе с базой данных.
          </p>
          <Button variant="outline" onClick={logout}>
            Выйти из админ-панели
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

function DataTab() {
  const { state } = useApp()
  const actions = useActions()
  const toast = useToast()
  const fileRef = useRef<HTMLInputElement>(null)
  const [confirm, setConfirm] = useState<'demo' | 'clear' | null>(null)

  const exportJson = (): void => {
    const blob = new Blob([serializeState(state)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `reclothe-backup-${toDateString(new Date())}.json`
    document.body.appendChild(link)
    link.click()
    link.remove()
    URL.revokeObjectURL(url)
    toast({ title: 'Резервная копия сохранена', description: 'JSON-файл со всеми заказами, клиентами и финансами.' })
  }

  const importJson = async (file: File | undefined): Promise<void> => {
    if (!file) return
    const ok = actions.importState(await file.text())
    toast({
      title: ok ? 'Данные загружены' : 'Файл не подошёл',
      description: ok ? 'Все расчёты обновлены.' : 'Выберите JSON-файл, сохранённый этой программой.',
      tone: ok ? 'success' : 'danger',
    })
    if (fileRef.current) fileRef.current.value = ''
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Резервная копия</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <p>
            Все данные лежат в этом браузере. Сохраняйте копию перед защитой и после важных изменений: перенос на другой
            компьютер — через файл.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button onClick={exportJson}>
              <Download aria-hidden="true" />
              Скачать JSON
            </Button>
            <Button variant="outline" onClick={() => fileRef.current?.click()}>
              <Upload aria-hidden="true" />
              Загрузить из файла
            </Button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              className="sr-only"
              aria-label="Файл резервной копии"
              onChange={(event) => void importJson(event.target.files?.[0])}
            />
          </div>
          <p className="font-mono text-xs">
            Записей: заказов {state.orders.length}, клиентов {state.clients.length}, выплат {state.payouts.length}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Сброс данных</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <p>Мастер-пароль при сбросе не меняется.</p>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => setConfirm('demo')}>
              <RotateCcw aria-hidden="true" />
              Вернуть демо-данные
            </Button>
            <Button variant="destructive" onClick={() => setConfirm('clear')}>
              <Trash2 aria-hidden="true" />
              Очистить всё
            </Button>
          </div>
        </CardContent>
      </Card>

      <Modal
        open={confirm !== null}
        onOpenChange={(open) => {
          if (!open) setConfirm(null)
        }}
        size="sm"
        title={confirm === 'clear' ? 'Очистить все данные?' : 'Вернуть демо-данные?'}
        description="Текущие заказы, клиенты, склад и финансы будут заменены. Действие нельзя отменить — сначала скачайте копию."
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirm(null)}>
              Отмена
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (confirm === 'clear') actions.clearAll()
                else actions.resetDemo()
                toast({ title: confirm === 'clear' ? 'Данные очищены' : 'Демо-данные восстановлены', tone: 'info' })
                setConfirm(null)
              }}
            >
              {confirm === 'clear' ? 'Очистить' : 'Заменить на демо'}
            </Button>
          </>
        }
      >
        <p className="text-sm text-muted-foreground">Кабинеты клиентов, открытые в других вкладках, вернутся на экран входа.</p>
      </Modal>
    </div>
  )
}

export function SettingsView() {
  const [tab, setTab] = useState<TabId>('tariffs')
  return (
    <div>
      <PageHeader title="Настройки" description="Тарифная сетка, мастера, пароль администратора и данные." />
      <Tabs<TabId>
        aria-label="Раздел настроек"
        value={tab}
        onChange={setTab}
        className="mb-4"
        tabs={[
          { value: 'tariffs', label: 'Тарифы' },
          { value: 'masters', label: 'Мастера' },
          { value: 'security', label: 'Безопасность' },
          { value: 'data', label: 'Данные' },
        ]}
      />
      {tab === 'tariffs' ? <TariffsTab /> : null}
      {tab === 'masters' ? <MastersTab /> : null}
      {tab === 'security' ? <SecurityTab /> : null}
      {tab === 'data' ? <DataTab /> : null}
    </div>
  )
}
