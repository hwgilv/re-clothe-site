'use client'

import { Suspense, useMemo, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { FileText, Printer } from 'lucide-react'

import { PageHeader } from '@/components/common/PageHeader'
import { PageSkeleton } from '@/components/common/PageSkeleton'
import { ContractDoc, DonorAct } from '@/components/documents/OrderDocuments'
import { GphAct } from '@/components/payroll/GphAct'
import { Button } from '@/components/ui/button'
import { EmptyState } from '@/components/ui/empty-state'
import { Field } from '@/components/ui/field'
import { Select } from '@/components/ui/select'
import { Tabs } from '@/components/ui/tabs'
import { formatIsoDate, formatRub } from '@/lib/format'
import { useApp } from '@/store/AppProvider'

type TabId = 'contract' | 'donors' | 'gph'

function DocumentsInner() {
  const { state, derived } = useApp()
  const params = useSearchParams()
  const [tab, setTab] = useState<TabId>('contract')
  const [orderId, setOrderId] = useState(params.get('order') ?? '')
  const [payoutId, setPayoutId] = useState('')

  const orders = useMemo(() => derived.orders.filter((view) => view.order.state === 'active'), [derived.orders])
  const view = derived.orderById.get(orderId) ?? orders[0]
  const payouts = useMemo(() => [...state.payouts].sort((a, b) => (a.at < b.at ? 1 : -1)), [state.payouts])
  const payout = payouts.find((item) => item.id === payoutId) ?? payouts[0]

  return (
    <div>
      <PageHeader
        title="Документы"
        description="Договор, акт приёма сырья и акты ГПХ формируются из данных заказов и выплат — подставьте и распечатайте."
        actions={
          <Button onClick={() => window.print()}>
            <Printer aria-hidden="true" />
            Печать / PDF
          </Button>
        }
      />

      <div className="no-print mb-4 space-y-3">
        <Tabs<TabId>
          aria-label="Вид документа"
          value={tab}
          onChange={setTab}
          tabs={[
            { value: 'contract', label: 'Договор подряда' },
            { value: 'donors', label: 'Акт приёма сырья' },
            { value: 'gph', label: 'Акты ГПХ', count: payouts.length },
          ]}
        />

        {tab === 'gph' ? (
          payouts.length > 0 ? (
            <Field label="Акт" htmlFor="doc-payout" className="max-w-lg">
              <Select id="doc-payout" value={payout?.id ?? ''} onChange={(event) => setPayoutId(event.target.value)}>
                {payouts.map((item) => (
                  <option key={item.id} value={item.id}>
                    № {item.actNo} · {state.masters.find((master) => master.id === item.masterId)?.name ?? '—'} · {formatIsoDate(item.at)} · {formatRub(item.total)}
                  </option>
                ))}
              </Select>
            </Field>
          ) : null
        ) : orders.length > 0 ? (
          <Field label="Заказ" htmlFor="doc-order" className="max-w-lg">
            <Select id="doc-order" value={view?.order.id ?? ''} onChange={(event) => setOrderId(event.target.value)}>
              {orders.map((item) => (
                <option key={item.order.id} value={item.order.id}>
                  {item.order.number} · {item.clientName} · {item.service.name}
                </option>
              ))}
            </Select>
          </Field>
        ) : null}
      </div>

      <div className="mx-auto max-w-3xl">
        {tab === 'gph' ? (
          payout ? (
            <GphAct payout={payout} master={state.masters.find((item) => item.id === payout.masterId)} orders={state.orders} />
          ) : (
            <EmptyState
              icon={<FileText className="size-6" aria-hidden="true" />}
              title="Актов ГПХ пока нет"
              description="Акт формируется автоматически при нажатии «Выплатить ЗП» в разделе «Бухгалтерия и ЗП»."
            />
          )
        ) : view ? (
          tab === 'contract' ? <ContractDoc view={view} /> : <DonorAct view={view} />
        ) : (
          <EmptyState icon={<FileText className="size-6" aria-hidden="true" />} title="Заказов пока нет" description="Создайте заказ — документы появятся здесь." />
        )}
      </div>
    </div>
  )
}

export function DocumentsView() {
  return (
    <Suspense fallback={<PageSkeleton />}>
      <DocumentsInner />
    </Suspense>
  )
}
