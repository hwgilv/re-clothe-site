import { MATERIALS, STUDIO } from '@/lib/domain/catalog'
import type { OrderView } from '@/lib/domain/derive'
import { formatDateString, toDateString } from '@/lib/date'
import { formatRub } from '@/lib/format'

function Sheet({ title, subtitle, children, label }: { title: string; subtitle?: string; children: React.ReactNode; label: string }) {
  return (
    <article aria-label={label} className="print-area rounded-lg bg-white p-6 font-serif text-[13px] leading-relaxed text-black sm:p-8">
      <h2 className="text-center font-serif text-base font-bold uppercase tracking-wide !text-black">{title}</h2>
      {subtitle ? <p className="mt-1 text-center text-xs">{subtitle}</p> : null}
      {children}
    </article>
  )
}

const blank = (width = 'w-28'): React.ReactNode => (
  <span className={`inline-block ${width} border-b border-black align-baseline`}>&nbsp;</span>
)

/** Договор бытового подряда (Приложение А к плану), заполненный данными заказа. */
export function ContractDoc({ view }: { view: OrderView }) {
  const { order, client } = view
  const created = formatDateString(toDateString(new Date(order.createdAt)))
  const advance = order.payments.filter((payment) => payment.kind === 'advance').reduce((sum, payment) => sum + payment.amount, 0)
  const rest = Math.max(0, view.pricing.clientTotal - advance)
  const short = (full: string): string => {
    const [last = '', ...others] = full.trim().split(/\s+/)
    return `${last} ${others.map((part) => `${part.charAt(0)}.`).join('')}`.trim()
  }

  return (
    <Sheet title="Договор бытового подряда" subtitle={`№ ${order.number}`} label={`Договор по заказу ${order.number}`}>
      <p className="mt-3">г. {STUDIO.city} {created}</p>

      <p className="mt-3">
        <strong>Исполнитель:</strong> {STUDIO.owner}, самозанятый (НПД), паспорт: {blank('w-10')} № {blank('w-28')}, тел.: {STUDIO.phone}
      </p>
      <p className="mt-1">
        <strong>Заказчик:</strong> {view.clientName}, паспорт: {blank('w-10')} № {blank('w-28')}, тел.: {client?.phone ?? blank()}
      </p>

      <h3 className="mt-4 font-serif text-sm font-bold !text-black">1. ПРЕДМЕТ ДОГОВОРА</h3>
      <p>
        1.1. Исполнитель обязуется выполнить работу по перешиву/кастомизации одежды Заказчика согласно Техническому
        заданию (Приложение № 1): <em>{view.service.name}</em> ({view.service.id}), а Заказчик обязуется принять и оплатить результат.
      </p>
      <p>1.2. Работа выполняется из материалов Заказчика (давальческое сырьё).</p>

      <h3 className="mt-4 font-serif text-sm font-bold !text-black">2. СТОИМОСТЬ И ОПЛАТА</h3>
      <p>2.1. Стоимость работы: <strong>{formatRub(view.pricing.clientTotal)}</strong>.</p>
      <p>2.2. Порядок оплаты:</p>
      <ul className="list-disc pl-8">
        <li>Аванс: {advance > 0 ? <strong>{formatRub(advance)}</strong> : blank('w-24')} (при подписании договора)</li>
        <li>Окончательный расчёт: <strong>{formatRub(rest)}</strong> (при получении изделия)</li>
      </ul>
      <p>2.3. Исполнитель выдаёт чек через приложение «Мой налог».</p>

      <h3 className="mt-4 font-serif text-sm font-bold !text-black">3. СРОКИ</h3>
      <p>3.1. Начало работы: {created}.</p>
      <p>3.2. Готовность изделия: {formatDateString(order.deadline)}.</p>

      <h3 className="mt-4 font-serif text-sm font-bold !text-black">4. ОТВЕТСТВЕННОСТЬ</h3>
      <p>
        4.1. Исполнитель несёт ответственность за сохранность материалов Заказчика. В случае порчи по вине Исполнителя —
        возврат стоимости работы + бесплатная переделка из нового материала.
      </p>
      <p>4.2. Исполнитель не несёт ответственности за скрытые дефекты ткани, выявленные в процессе работы.</p>
      <p>4.3. Гарантийный срок на швы и фурнитуру: 6 месяцев.</p>

      <h3 className="mt-4 font-serif text-sm font-bold !text-black">5. ПРОЧЕЕ</h3>
      <p>5.1. Все изменения в Техническое задание — только по согласованию сторон.</p>
      <p>5.2. Споры решаются путём переговоров. При недостижении согласия — в суде.</p>

      {order.comment ? (
        <p className="mt-3">
          <strong>Пожелания Заказчика:</strong> {order.comment}
        </p>
      ) : null}

      <p className="mt-6 font-bold">ПОДПИСИ СТОРОН:</p>
      <div className="mt-3 grid gap-4 sm:grid-cols-2">
        <p>Исполнитель: ______________ / {short(STUDIO.owner)} /</p>
        <p>Заказчик: ______________ / {short(view.clientName)} /</p>
      </div>
    </Sheet>
  )
}

/** Акт приёма-передачи давальческого сырья с описанием вещей-доноров (раздел 5.3 плана). */
export function DonorAct({ view }: { view: OrderView }) {
  const { order } = view
  const date = formatDateString(toDateString(new Date(order.createdAt)))
  return (
    <Sheet
      title="Акт приёма-передачи давальческого сырья"
      subtitle={`к заказу ${order.number} от ${date}`}
      label={`Акт приёма-передачи сырья по заказу ${order.number}`}
    >
      <p className="mt-3">
        <strong>Исполнитель:</strong> {STUDIO.owner} (студия {STUDIO.name}). <strong>Заказчик:</strong> {view.clientName}
        {view.client?.phone ? `, тел.: ${view.client.phone}` : ''}.
      </p>
      <p className="mt-2">Заказчик передал, а Исполнитель принял на переработку следующие вещи:</p>

      <table className="mt-3 w-full border-collapse text-[12px]">
        <thead>
          <tr>
            {['№', 'Код', 'Наименование', 'Материал', 'Вес, кг', 'Состояние, дефекты'].map((head) => (
              <th key={head} className="border border-black px-1.5 py-1 text-left font-semibold">
                {head}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {order.donors.length === 0 ? (
            <tr>
              <td colSpan={6} className="border border-black px-1.5 py-3 text-center">
                Вещи не передавались
              </td>
            </tr>
          ) : (
            order.donors.map((donor, index) => (
              <tr key={donor.id}>
                <td className="border border-black px-1.5 py-1">{index + 1}</td>
                <td className="border border-black px-1.5 py-1 font-mono">{donor.code}</td>
                <td className="border border-black px-1.5 py-1">{donor.title}</td>
                <td className="border border-black px-1.5 py-1">
                  {MATERIALS.find((item) => item.id === donor.materialId)?.label ?? donor.materialId}
                </td>
                <td className="border border-black px-1.5 py-1 text-right">{donor.weightKg}</td>
                <td className="border border-black px-1.5 py-1">{donor.note || '—'}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
      <p className="mt-2">
        Общий вес: <strong>{view.weightKg} кг</strong>. Фотофиксация каждой вещи в 4 ракурсах выполнена: да / нет.
      </p>
      <p className="mt-2 text-xs">
        Критерии приёмки: ткань сохраняет более 60% полезной площади, отсутствуют гниль и плесень, фурнитура функциональна.
        Критические повреждения структуры и неустранимые загрязнения — основание для отбраковки.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <p>Исполнитель: ______________ / Лозовой Р.Т. /</p>
        <p>Заказчик: ______________ / ______________ /</p>
      </div>
    </Sheet>
  )
}
