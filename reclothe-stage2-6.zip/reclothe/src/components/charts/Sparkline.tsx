/** Мини-график тренда: линия 2 px, последняя точка — акцентная, с кольцом цвета поверхности. */
export function Sparkline({
  values,
  width = 96,
  height = 28,
  color = 'var(--series-revenue)',
  'aria-label': ariaLabel,
}: {
  values: readonly number[]
  width?: number
  height?: number
  color?: string
  'aria-label': string
}) {
  if (values.length < 2) return null
  const min = Math.min(...values)
  const max = Math.max(...values)
  const span = max - min || 1
  const pad = 5
  const x = (index: number): number => pad + (index / (values.length - 1)) * (width - pad * 2)
  const y = (value: number): number => pad + (1 - (value - min) / span) * (height - pad * 2)
  const points = values.map((value, index) => `${x(index)},${y(value)}`).join(' ')
  const lastIndex = values.length - 1
  return (
    <svg role="img" aria-label={ariaLabel} width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="block shrink-0">
      <polyline points={points} fill="none" stroke="var(--viz-axis)" strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={x(lastIndex)} cy={y(values[lastIndex] ?? 0)} r={4} fill={color} stroke="hsl(var(--surface))" strokeWidth={2} />
    </svg>
  )
}
