'use client'

import { useId, useMemo, useState } from 'react'

import { SegmentedControl } from '@/components/ui/segmented-control'
import { useElementWidth } from '@/hooks/use-element-width'
import { formatAxisValue, niceScale } from '@/lib/charts'
import { formatMonthKey } from '@/lib/date'
import type { FinanceMonth } from '@/lib/domain/derive'
import { formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'

const HEIGHT = 288
const PAD = { top: 14, right: 12, bottom: 28, left: 52 }
const MAX_BAR = 24
const GAP = 2

export function monthCosts(month: FinanceMonth): number {
  return month.payroll + month.materials + month.expenses + month.tax
}

function barPath(x: number, width: number, baseY: number, topY: number): string {
  const height = Math.abs(baseY - topY)
  if (height < 0.5) return ''
  const r = Math.min(4, height, width / 2)
  // Скругление — на «свободном» конце, у базовой линии угол прямой.
  if (topY < baseY) {
    return `M${x},${baseY}V${topY + r}Q${x},${topY} ${x + r},${topY}H${x + width - r}Q${x + width},${topY} ${x + width},${topY + r}V${baseY}Z`
  }
  return `M${x},${baseY}V${topY - r}Q${x},${topY} ${x + r},${topY}H${x + width - r}Q${x + width},${topY} ${x + width},${topY - r}V${baseY}Z`
}

const SERIES = [
  { id: 'revenue', label: 'Выручка', color: 'var(--series-revenue)', kind: 'bar' },
  { id: 'cost', label: 'Расходы', color: 'var(--series-cost)', kind: 'bar' },
  { id: 'profit', label: 'Прибыль', color: 'var(--series-profit)', kind: 'line' },
] as const

type View = 'chart' | 'table'

/**
 * Выручка, расходы и прибыль по месяцам. Одна ось, без вторых шкал: выручка и расходы —
 * столбцы, прибыль — линия с маркерами. Все значения считаются из состояния приложения.
 */
export function FinanceChart({ months }: { months: readonly FinanceMonth[] }) {
  const [boxRef, width] = useElementWidth<HTMLDivElement>()
  const [view, setView] = useState<View>('chart')
  const [active, setActive] = useState<number | null>(null)
  const titleId = useId()

  const rows = useMemo(
    () =>
      months.map((month) => ({
        key: month.key,
        revenue: month.revenue,
        cost: monthCosts(month),
        profit: month.profit,
      })),
    [months],
  )

  const scale = useMemo(
    () => niceScale(rows.flatMap((row) => [row.revenue, row.cost, row.profit])),
    [rows],
  )

  // Ширина поля подписей оси зависит от самой длинной подписи («−20 тыс.»), иначе её обрезает край.
  const padLeft = Math.max(
    PAD.left,
    Math.ceil(16 + 6.8 * Math.max(...scale.ticks.map((tick) => formatAxisValue(tick).length))),
  )
  const innerW = Math.max(10, width - padLeft - PAD.right)
  const innerH = HEIGHT - PAD.top - PAD.bottom
  const band = innerW / Math.max(1, rows.length)
  const barW = Math.max(6, Math.min(MAX_BAR, (band - 14) / 2 - GAP / 2))
  const y = (value: number): number => PAD.top + ((scale.max - value) / (scale.max - scale.min)) * innerH
  const zeroY = y(0)
  const centerX = (index: number): number => padLeft + band * index + band / 2

  const profitPoints = rows.map((row, index) => `${centerX(index)},${y(row.profit)}`).join(' ')
  const last = rows[rows.length - 1]
  const hasData = rows.some((row) => row.revenue !== 0 || row.cost !== 0)
  const activeRow = active !== null ? rows[active] : undefined

  // Подпись ниже графика для скринридера: полное содержание — в табличном виде.
  const summary = last
    ? `За ${formatMonthKey(last.key, 'long')}: выручка ${formatRub(last.revenue)}, расходы ${formatRub(last.cost)}, прибыль ${formatRub(last.profit)}.`
    : 'Данных нет.'

  const tooltipLeft = activeRow && active !== null ? Math.min(Math.max(centerX(active), 96), width - 96) : 0

  return (
    <figure aria-labelledby={titleId} className="m-0">
      <figcaption className="mb-3 flex flex-wrap items-center justify-between gap-x-4 gap-y-2">
        <span id={titleId} className="sr-only">
          Выручка, расходы и прибыль по месяцам
        </span>
        <ul className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground" aria-label="Легенда">
          {SERIES.map((series) => (
            <li key={series.id} className="flex items-center gap-1.5">
              {series.kind === 'bar' ? (
                <span aria-hidden="true" className="inline-block h-2.5 w-2.5 rounded-sm" style={{ background: series.color }} />
              ) : (
                <span aria-hidden="true" className="inline-block h-0.5 w-4 rounded-full" style={{ background: series.color }} />
              )}
              {series.label}
            </li>
          ))}
        </ul>
        <SegmentedControl<View>
          aria-label="Вид графика"
          value={view}
          onChange={setView}
          options={[
            { value: 'chart', label: 'График' },
            { value: 'table', label: 'Таблица' },
          ]}
        />
      </figcaption>

      {view === 'table' ? (
        <div className="overflow-x-auto rounded-lg border border-border">
          <table className="w-full min-w-[28rem] border-collapse text-sm">
            <caption className="sr-only">Выручка, расходы и прибыль по месяцам</caption>
            <thead>
              <tr className="border-b border-border">
                <th scope="col" className="px-3 py-2 text-left font-mono text-2xs uppercase tracking-widest text-muted-foreground">Месяц</th>
                {SERIES.map((series) => (
                  <th key={series.id} scope="col" className="px-3 py-2 text-right font-mono text-2xs uppercase tracking-widest text-muted-foreground">
                    {series.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.key} className="border-b border-border/60 last:border-0">
                  <th scope="row" className="px-3 py-2 text-left font-normal">{formatMonthKey(row.key)}</th>
                  <td className="px-3 py-2 text-right font-mono tabular-nums">{formatRub(row.revenue)}</td>
                  <td className="px-3 py-2 text-right font-mono tabular-nums">{formatRub(row.cost)}</td>
                  <td className={cn('px-3 py-2 text-right font-mono tabular-nums', row.profit < 0 && 'text-destructive-text')}>
                    {formatRub(row.profit)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div ref={boxRef} className="relative" onPointerLeave={() => setActive(null)}>
          <svg
            role="img"
            aria-label={`График по месяцам. ${summary}`}
            width={width}
            height={HEIGHT}
            viewBox={`0 0 ${width} ${HEIGHT}`}
            className="block max-w-full select-none"
          >
            {/* сетка: тонкие сплошные линии, на тон светлее поверхности */}
            {scale.ticks.map((tick) => (
              <g key={tick}>
                <line
                  x1={padLeft}
                  x2={width - PAD.right}
                  y1={y(tick)}
                  y2={y(tick)}
                  stroke={tick === 0 ? 'var(--viz-axis)' : 'var(--viz-grid)'}
                  strokeWidth={1}
                />
                <text x={padLeft - 8} y={y(tick)} textAnchor="end" dominantBaseline="middle" fontSize={11} fill="var(--viz-text)" className="font-mono">
                  {formatAxisValue(tick)}
                </text>
              </g>
            ))}

            {rows.map((row, index) => {
              const cx = centerX(index)
              const isActive = active === index
              return (
                <g key={row.key}>
                  {isActive ? (
                    <rect x={padLeft + band * index} y={PAD.top} width={band} height={innerH} fill="hsl(0 0% 100% / 0.04)" />
                  ) : null}
                  <path
                    d={barPath(cx - barW - GAP / 2, barW, zeroY, y(row.revenue))}
                    fill="var(--series-revenue)"
                    opacity={active === null || isActive ? 1 : 0.55}
                  />
                  <path
                    d={barPath(cx + GAP / 2, barW, zeroY, y(row.cost))}
                    fill="var(--series-cost)"
                    opacity={active === null || isActive ? 1 : 0.55}
                  />
                  <text x={cx} y={HEIGHT - 8} textAnchor="middle" fontSize={11} fill="var(--viz-text)">
                    {formatMonthKey(row.key).split(' ')[0]}
                  </text>
                </g>
              )
            })}

            {active !== null ? (
              <line x1={centerX(active)} x2={centerX(active)} y1={PAD.top} y2={PAD.top + innerH} stroke="var(--viz-axis)" strokeWidth={1} />
            ) : null}

            {rows.length > 1 ? (
              <polyline points={profitPoints} fill="none" stroke="var(--series-profit)" strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
            ) : null}
            {rows.map((row, index) => (
              <circle
                key={row.key}
                cx={centerX(index)}
                cy={y(row.profit)}
                r={4}
                fill="var(--series-profit)"
                stroke="hsl(var(--surface))"
                strokeWidth={2}
              />
            ))}

            {/* зоны наведения шире самих столбцов; фокусируются с клавиатуры */}
            {rows.map((row, index) => (
              <rect
                key={`hit-${row.key}`}
                x={padLeft + band * index}
                y={PAD.top}
                width={band}
                height={innerH}
                fill="transparent"
                tabIndex={0}
                role="img"
                aria-label={`${formatMonthKey(row.key, 'long')}: выручка ${formatRub(row.revenue)}, расходы ${formatRub(row.cost)}, прибыль ${formatRub(row.profit)}`}
                onPointerEnter={() => setActive(index)}
                onPointerMove={() => setActive(index)}
                onFocus={() => setActive(index)}
                onBlur={() => setActive(null)}
                className="outline-none focus-visible:stroke-[hsl(var(--ring))]"
                strokeWidth={2}
              />
            ))}
          </svg>

          {!hasData ? (
            <p className="pointer-events-none absolute inset-x-0 top-1/2 text-center text-sm text-muted-foreground">
              Данных за последние месяцы пока нет
            </p>
          ) : null}

          {activeRow ? (
            <div
              role="status"
              className="pointer-events-none absolute z-10 w-48 -translate-x-1/2 rounded-lg border border-border bg-background p-2.5 shadow-xl"
              style={{ left: tooltipLeft, top: 4 }}
            >
              <p className="mb-1.5 font-mono text-2xs uppercase tracking-widest text-muted-foreground">
                {formatMonthKey(activeRow.key, 'long')}
              </p>
              {SERIES.map((series) => (
                <p key={series.id} className="flex items-center justify-between gap-2 text-xs">
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <span aria-hidden="true" className="inline-block h-0.5 w-3 rounded-full" style={{ background: series.color }} />
                    {series.label}
                  </span>
                  <span className={cn('font-mono text-sm font-semibold tabular-nums', series.id === 'profit' && activeRow.profit < 0 && 'text-destructive-text')}>
                    {formatRub(activeRow[series.id])}
                  </span>
                </p>
              ))}
            </div>
          ) : null}
        </div>
      )}

      <p className="mt-2 text-xs text-muted-foreground">{summary}</p>
    </figure>
  )
}
