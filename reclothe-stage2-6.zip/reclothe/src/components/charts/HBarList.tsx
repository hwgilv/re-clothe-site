import { cn } from '@/lib/utils'

export interface HBarItem {
  key: string
  label: string
  value: number
  /** Текст значения у конца полосы. */
  display: string
  /** Подсказка при наведении. */
  title?: string
}

/**
 * Горизонтальные полосы одного цвета: сравнение величин по категориям.
 * Цвет не кодирует величину (длина уже кодирует) — все полосы одного оттенка.
 * Полоса тонкая, скругление 4 px на свободном конце, у базовой линии — прямой угол.
 */
export function HBarList({
  items,
  color = 'var(--series-cost)',
  emptyText = 'Нет данных',
  className,
  'aria-label': ariaLabel,
}: {
  items: readonly HBarItem[]
  color?: string
  emptyText?: string
  className?: string
  'aria-label': string
}) {
  const max = Math.max(0, ...items.map((item) => item.value))
  if (items.length === 0 || max === 0) {
    return <p className="py-6 text-center text-sm text-muted-foreground">{emptyText}</p>
  }
  return (
    <ul aria-label={ariaLabel} className={cn('space-y-2.5', className)}>
      {items.map((item) => (
        <li key={item.key} title={item.title} className="grid grid-cols-[minmax(7rem,38%)_1fr_auto] items-center gap-x-3 text-sm">
          <span className="truncate text-muted-foreground">{item.label}</span>
          <span className="relative h-3">
            <span
              className="absolute inset-y-0 left-0 rounded-r-[4px] transition-[width] duration-500"
              style={{ width: `${Math.max(item.value > 0 ? 1 : 0, (item.value / max) * 100)}%`, background: color }}
            />
          </span>
          <span className="min-w-16 text-right font-mono text-xs font-semibold tabular-nums">{item.display}</span>
        </li>
      ))}
    </ul>
  )
}
