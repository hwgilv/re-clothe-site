'use client'

import { Archive, Check, Copy, Mail, Phone, ShoppingBag } from 'lucide-react'

import { MessengerIcon } from '@/components/common/MessengerIcon'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/toast'
import { copyText } from '@/lib/clipboard'
import { MESSENGERS, messengerLabel } from '@/lib/domain/catalog'
import { initialsOf } from '@/lib/domain/client'
import type { LeadView } from '@/lib/domain/derive'
import { buildMessengerLink, leadMessageTemplate } from '@/lib/domain/messenger'
import type { MessengerId } from '@/lib/domain/types'
import { formatTimeAgo, formatIsoDateTime } from '@/lib/format'
import { cn } from '@/lib/utils'
import { useActions } from '@/store/AppProvider'
import { useUI } from '@/store/ui'

const STATUS_LABEL = {
  new: 'Новая заявка',
  contacted: 'Связались',
  converted: 'Оформлена',
  archived: 'В архиве',
} as const

const STATUS_VARIANT = {
  new: 'default',
  contacted: 'denim',
  converted: 'success',
  archived: 'muted',
} as const

/**
 * Карточка нового лида (модуль 4). «Связь в один клик»: значок мессенджера клиента открывает
 * официальное веб-окно и копирует шаблон приветствия в буфер обмена.
 */
export function LeadCard({ item, now }: { item: LeadView; now: number }) {
  const actions = useActions()
  const toast = useToast()
  const { openOrderModal } = useUI()
  const { client, lead } = item
  if (!client) return null

  const message = leadMessageTemplate(client.firstName)
  const open = lead.status === 'new' || lead.status === 'contacted'

  const contact = async (id: MessengerId): Promise<void> => {
    const link = buildMessengerLink(id, client, message)
    // Окно открываем сразу, в том же клике, — иначе браузер примет его за всплывающую рекламу.
    if (link.url.startsWith('tel:')) window.location.href = link.url
    else window.open(link.url, '_blank', 'noopener,noreferrer')
    const copied = await copyText(message)
    if (lead.status === 'new') actions.setLeadStatus(lead.id, 'contacted')
    toast({
      title: `${messengerLabel(id)}: окно открыто`,
      description: copied
        ? 'Шаблон приветствия скопирован — вставьте его в чат (Ctrl+V).'
        : 'Не удалось скопировать шаблон — скопируйте его вручную из карточки.',
      tone: copied ? 'success' : 'info',
    })
  }

  const copyOnly = async (): Promise<void> => {
    const copied = await copyText(message)
    toast({
      title: copied ? 'Шаблон скопирован' : 'Не удалось скопировать',
      description: copied ? undefined : 'Выделите текст в карточке и скопируйте вручную.',
      tone: copied ? 'success' : 'danger',
    })
  }

  return (
    <article
      aria-label={`Заявка: ${item.name}`}
      className={cn(
        'rounded-xl border bg-surface p-4',
        lead.status === 'new' ? 'border-primary/50 shadow-[0_0_0_1px_hsl(var(--primary)/0.15)]' : 'border-border',
      )}
    >
      <div className="flex items-start gap-3">
        <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-primary/15 font-mono text-sm font-bold text-primary-text">
          {initialsOf(item.name)}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-base font-semibold">{item.name}</h3>
            <Badge variant={STATUS_VARIANT[lead.status]}>{STATUS_LABEL[lead.status]}</Badge>
          </div>
          <p className="mt-0.5 text-xs text-muted-foreground" title={formatIsoDateTime(lead.createdAt)}>
            Заявка с сайта · {formatTimeAgo(new Date(lead.createdAt), new Date(now))}
          </p>
          <dl className="mt-2 space-y-1 text-sm">
            <div className="flex items-center gap-2">
              <Phone className="size-3.5 text-muted-foreground" aria-hidden="true" />
              <dt className="sr-only">Телефон</dt>
              <dd>
                <a href={`tel:${client.phone.replace(/[^\d+]/g, '')}`} className="font-mono hover:underline">
                  {client.phone}
                </a>
              </dd>
            </div>
            {client.email ? (
              <div className="flex items-center gap-2">
                <Mail className="size-3.5 text-muted-foreground" aria-hidden="true" />
                <dt className="sr-only">Email</dt>
                <dd className="truncate">
                  <a href={`mailto:${client.email}`} className="hover:underline">
                    {client.email}
                  </a>
                </dd>
              </div>
            ) : null}
          </dl>
        </div>
      </div>

      {open ? (
        <>
          <div className="mt-4 rounded-lg border border-border bg-background p-3">
            <p className="font-mono text-2xs uppercase tracking-widest text-muted-foreground">Связь в один клик</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Клиент просит связаться через <strong className="text-foreground">{messengerLabel(client.contact)}</strong>.
              Нажмите на значок — откроется мессенджер, а текст приветствия окажется в буфере обмена.
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {[...MESSENGERS]
                .sort((a, b) => Number(b.id === client.contact) - Number(a.id === client.contact))
                .map((messenger) => {
                  const preferred = messenger.id === client.contact
                  return (
                    <button
                      key={messenger.id}
                      type="button"
                      onClick={() => void contact(messenger.id)}
                      aria-label={`Написать через ${messenger.label}`}
                      className={cn(
                        'flex min-h-11 items-center gap-2 rounded-lg border px-2.5 py-1 text-sm transition-colors',
                        preferred
                          ? 'border-primary bg-primary/10 hover:bg-primary/20'
                          : 'border-border hover:bg-muted',
                      )}
                    >
                      <MessengerIcon id={messenger.id} />
                      <span className="text-left leading-tight">
                        <span className="block font-medium">{messenger.label}</span>
                        {preferred ? <span className="block text-2xs text-primary-text">предпочитает клиент</span> : null}
                      </span>
                    </button>
                  )
                })}
            </div>
            <p className="mt-3 rounded-md bg-surface p-2 text-xs leading-relaxed text-muted-foreground">{message}</p>
            <Button variant="ghost" size="sm" className="mt-1" onClick={() => void copyOnly()}>
              <Copy aria-hidden="true" />
              Копировать шаблон
            </Button>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            <Button onClick={() => openOrderModal({ leadId: lead.id })}>
              <ShoppingBag aria-hidden="true" />
              Оформить заказ
            </Button>
            {lead.status === 'new' ? (
              <Button variant="outline" onClick={() => actions.setLeadStatus(lead.id, 'contacted')}>
                <Check aria-hidden="true" />
                Отметить: связались
              </Button>
            ) : null}
            <Button variant="ghost" onClick={() => actions.setLeadStatus(lead.id, 'archived')}>
              <Archive aria-hidden="true" />
              В архив
            </Button>
          </div>
        </>
      ) : lead.status === 'archived' ? (
        <div className="mt-3">
          <Button variant="outline" size="sm" onClick={() => actions.setLeadStatus(lead.id, 'new')}>
            Вернуть в новые
          </Button>
        </div>
      ) : null}
    </article>
  )
}
