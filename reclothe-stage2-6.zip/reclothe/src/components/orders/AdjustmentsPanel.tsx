'use client'

import { useState } from 'react'
import { Lock, Plus, X } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Stepper } from '@/components/ui/stepper'
import { useToast } from '@/components/ui/toast'
import { BONUS_DEFS, PENALTY_DEFS, type AdjustmentDef } from '@/lib/domain/catalog'
import type { OrderView } from '@/lib/domain/derive'
import { adjustmentAmount } from '@/lib/domain/payroll'
import { formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'
import { useActions } from '@/store/AppProvider'

function CustomAmountInput({
  def,
  value,
  disabled,
  onCommit,
}: {
  def: AdjustmentDef
  value: number
  disabled: boolean
  onCommit: (amount: number) => void
}) {
  const [text, setText] = useState(String(value))
  const commit = (): void => {
    const parsed = Number.parseInt(text.replace(/\D/g, ''), 10)
    const clamped = Math.min(def.customMax ?? Infinity, Math.max(def.customMin ?? 0, Number.isFinite(parsed) ? parsed : 0))
    setText(String(clamped))
    if (clamped !== value) onCommit(clamped)
  }
  return (
    <div className="flex items-center gap-1.5">
      <Input
        aria-label={`${def.label}: сумма, ₽`}
        inputMode="numeric"
        value={text}
        disabled={disabled}
        onChange={(event) => setText(event.target.value.replace(/[^\d]/g, ''))}
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === 'Enter') {
            event.preventDefault()
            commit()
          }
        }}
        className="h-9 w-24 text-right font-mono"
      />
      <span className="text-xs text-muted-foreground">₽</span>
    </div>
  )
}

function AdjustmentRow({ def, view, locked }: { def: AdjustmentDef; view: OrderView; locked: boolean }) {
  const actions = useActions()
  const toast = useToast()
  const orderId = view.order.id
  const applied = view.order.adjustments.find((item) => item.code === def.code)
  const sign = def.kind === 'bonus' ? '+' : '−'
  const amount = adjustmentAmount(
    def,
    applied ?? { id: 'preview', kind: def.kind, code: def.code, qty: 1, customAmount: null, at: '' },
    view.pricing.masterTotal,
  )
  const tone = def.kind === 'bonus' ? 'success' : 'destructive'

  const preview =
    def.mode === 'percent'
      ? `${sign}${def.value}% = ${sign}${formatRub(amount)}`
      : def.mode === 'fixed'
        ? `${sign}${formatRub(def.value)}`
        : def.mode === 'per-unit'
          ? `${sign}${formatRub(def.value)} / ${def.unitLabel ?? 'ед.'}`
          : def.mode === 'custom'
            ? `${sign}${formatRub(def.customMin ?? 0)}–${formatRub(def.customMax ?? 0)}`
            : 'без суммы'

  const apply = (extra?: { qty?: number; customAmount?: number }): void => {
    actions.toggleAdjustment(orderId, { code: def.code, ...extra })
  }

  const isToggle = def.mode === 'percent' || def.mode === 'fixed' || def.mode === 'info'

  return (
    <li
      className={cn(
        'rounded-lg border p-2.5 transition-colors',
        applied
          ? tone === 'success'
            ? 'border-success/60 bg-success/10'
            : 'border-destructive/60 bg-destructive/10'
          : 'border-border bg-background',
      )}
    >
      <div className="flex items-start justify-between gap-2">
        {isToggle ? (
          <button
            type="button"
            role="checkbox"
            aria-checked={Boolean(applied)}
            disabled={locked}
            onClick={() => {
              apply()
              if (!applied) {
                toast({
                  title: `${def.kind === 'bonus' ? 'Премия начислена' : 'Штраф удержан'}: ${def.label}`,
                  description:
                    def.mode === 'info' ? 'Запись в журнале, сумма не удерживается.' : `${sign}${formatRub(amount)} — ЗП пересчитана.`,
                })
              }
            }}
            className="flex min-h-9 min-w-0 flex-1 items-start gap-2 text-left disabled:cursor-not-allowed"
          >
            <span
              aria-hidden="true"
              className={cn(
                'mt-0.5 flex size-4 shrink-0 items-center justify-center rounded-sm border text-2xs font-bold leading-none',
                applied
                  ? tone === 'success'
                    ? 'border-success bg-success text-primary-foreground'
                    : 'border-destructive bg-destructive text-white'
                  : 'border-input',
              )}
            >
              {applied ? '✓' : ''}
            </span>
            <span className="min-w-0">
              <span className="block text-sm leading-tight">{def.label}</span>
              <span className="block text-xs text-muted-foreground">{def.hint}</span>
            </span>
          </button>
        ) : (
          <div className="min-w-0 flex-1">
            <span className="block text-sm leading-tight">{def.label}</span>
            <span className="block text-xs text-muted-foreground">{def.hint}</span>
          </div>
        )}
        <span
          className={cn(
            'shrink-0 whitespace-nowrap font-mono text-xs tabular-nums',
            applied ? (tone === 'success' ? 'text-success-text' : 'text-destructive-text') : 'text-muted-foreground',
          )}
        >
          {preview}
        </span>
      </div>

      {def.mode === 'per-unit' || def.mode === 'custom' ? (
        <div className="mt-2 flex flex-wrap items-center gap-2">
          {applied ? (
            <>
              {def.mode === 'per-unit' ? (
                <Stepper
                  label={`${def.label}, ${def.unitLabel ?? 'ед.'}`}
                  value={applied.qty}
                  min={1}
                  max={40}
                  onChange={(qty) => apply({ qty })}
                  className={locked ? 'pointer-events-none opacity-50' : undefined}
                />
              ) : (
                <CustomAmountInput
                  def={def}
                  value={amount}
                  disabled={locked}
                  onCommit={(customAmount) => apply({ customAmount })}
                />
              )}
              <span className="font-mono text-xs text-muted-foreground">
                итого {sign}
                {formatRub(amount)}
              </span>
              <Button
                variant="ghost"
                size="sm"
                disabled={locked}
                aria-label={`Убрать: ${def.label}`}
                onClick={() => actions.removeAdjustment(orderId, applied.id)}
              >
                <X aria-hidden="true" />
              </Button>
            </>
          ) : (
            <Button
              variant="outline"
              size="sm"
              disabled={locked}
              onClick={() => {
                apply(def.mode === 'per-unit' ? { qty: 1 } : { customAmount: def.customMin ?? def.value })
                toast({
                  title: `${def.kind === 'bonus' ? 'Премия начислена' : 'Штраф удержан'}: ${def.label}`,
                  description: 'ЗП мастера пересчитана.',
                })
              }}
            >
              <Plus aria-hidden="true" />
              Добавить
            </Button>
          )}
        </div>
      ) : null}
    </li>
  )
}

/**
 * Премии (табл. 7.8.1) и штрафы (табл. 7.8.2) по заказу. Любое нажатие мгновенно меняет
 * «Итого к выплате» мастеру, баланс в «Бухгалтерии» и прибыль в финансах.
 */
export function AdjustmentsPanel({ view }: { view: OrderView }) {
  const locked = view.payrollLocked
  const { payroll } = view

  return (
    <div>
      {locked ? (
        <p className="mb-3 flex items-center gap-2 rounded-lg border border-border bg-background p-2.5 text-xs text-muted-foreground">
          <Lock className="size-3.5 shrink-0" aria-hidden="true" />
          ЗП по заказу выплачена и закреплена в акте — премии и штрафы больше не меняются.
        </p>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-2">
        <section aria-label="Премии">
          <h3 className="mb-2 font-mono text-xs uppercase tracking-wider text-success-text">Премии (+)</h3>
          <ul className="space-y-1.5">
            {BONUS_DEFS.map((def) => (
              <AdjustmentRow key={def.code} def={def} view={view} locked={locked} />
            ))}
          </ul>
        </section>
        <section aria-label="Штрафы и удержания">
          <h3 className="mb-2 font-mono text-xs uppercase tracking-wider text-destructive-text">Штрафы и удержания (−)</h3>
          <ul className="space-y-1.5">
            {PENALTY_DEFS.map((def) => (
              <AdjustmentRow key={def.code} def={def} view={view} locked={locked} />
            ))}
          </ul>
        </section>
      </div>

      <div className="mt-4 rounded-lg border border-border bg-background p-3" aria-live="polite">
        <p className="font-mono text-2xs uppercase tracking-widest text-muted-foreground">ЗП мастера по заказу</p>
        <p className="mt-1 flex flex-wrap items-baseline gap-x-2 gap-y-1 font-mono text-sm tabular-nums">
          <span>{formatRub(payroll.base)}</span>
          <span className="text-success-text">+ {formatRub(payroll.bonusTotal)}</span>
          <span className="text-destructive-text">− {formatRub(payroll.penaltyTotal)}</span>
          <span className="text-muted-foreground">=</span>
          <span className="text-lg font-bold text-foreground" data-testid="order-payroll-total">
            {formatRub(payroll.total)}
          </span>
        </p>
      </div>
    </div>
  )
}
