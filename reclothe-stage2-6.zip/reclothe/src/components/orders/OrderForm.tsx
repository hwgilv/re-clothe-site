'use client'

import { useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { CalendarClock, TriangleAlert } from 'lucide-react'

import { ClientPicker } from '@/components/orders/form/ClientPicker'
import { DonorsEditor } from '@/components/orders/form/DonorsEditor'
import {
  clientToDraft,
  donorFromService,
  donorsFromOrder,
  EMPTY_CLIENT,
  parseDecimal,
  parseMoney,
  type ClientDraft,
  type OrderDraft,
} from '@/components/orders/form/draft'
import { ArtPicker, ExtraOpsPicker, SpecialPicker } from '@/components/orders/form/OptionsPicker'
import { PricingSummary } from '@/components/orders/form/PricingSummary'
import { ServicePicker } from '@/components/orders/form/ServicePicker'
import { Button } from '@/components/ui/button'
import { Field } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Modal } from '@/components/ui/modal'
import { Progress } from '@/components/ui/progress'
import { Select } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { useToast } from '@/components/ui/toast'
import { COMPLEXITY_LEVELS, MATERIALS, SERVICES } from '@/lib/domain/catalog'
import { applyShift, assessLoad, suggestDeadline } from '@/lib/domain/aps'
import { formatPhone, isValidEmail, isValidPhone, normalizeEmail, phoneDigits } from '@/lib/domain/client'
import { formatOrderNumber, resolveService } from '@/lib/domain/orders'
import { calcPricing, emptyOptions, normHours } from '@/lib/domain/pricing'
import { orderConsumption } from '@/lib/domain/stock'
import type { Client, ComplexityId, MaterialId } from '@/lib/domain/types'
import { addDaysToDateString, formatDateString, isDateString } from '@/lib/date'
import { formatRub, pluralDays } from '@/lib/format'
import { cn } from '@/lib/utils'
import { newId, useApp } from '@/store/AppProvider'
import type { OrderModalRequest } from '@/store/ui'

interface OrderFormProps {
  request: OrderModalRequest
  onClose: () => void
}

type Errors = {
  client: Partial<Record<keyof ClientDraft, string>>
  service?: string
  master?: string
  deadline?: string
  advance?: string
  donors: Record<string, string>
}

const NO_ERRORS: Errors = { client: {}, donors: {} }
const DEFAULT_LEAD_DAYS = 14

function Section({ n, title, hint, children }: { n: number; title: string; hint?: string; children: React.ReactNode }) {
  return (
    <section aria-label={title}>
      <h3 className="mb-3 flex items-center gap-2 font-mono text-sm font-semibold">
        <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-primary/15 text-xs text-primary-text">
          {n}
        </span>
        {title}
      </h3>
      {hint ? <p className="-mt-1 mb-3 text-xs text-muted-foreground">{hint}</p> : null}
      {children}
    </section>
  )
}

/** Окно «+ Новый заказ»: калькулятор стоимости, ЗП мастера и сроков (APS). */
export function OrderForm({ request, onClose }: OrderFormProps) {
  const { state, derived, actions } = useApp()
  const router = useRouter()
  const toast = useToast()

  const editing = request.editOrderId ? state.orders.find((order) => order.id === request.editOrderId) : undefined
  const editView = editing ? derived.orderById.get(editing.id) : undefined
  const locked = editView?.payrollLocked ?? false

  // Для заказа в работе цена услуги — по тарифу, согласованному при создании.
  const services = useMemo(
    () =>
      SERVICES.map((service) => {
        const current = resolveService(service.id, state.serviceOverrides) ?? service
        return editing?.tariff && editing.serviceId === service.id ? { ...current, ...editing.tariff } : current
      }),
    [state.serviceOverrides, editing?.tariff, editing?.serviceId],
  )

  const [draft, setDraft] = useState<OrderDraft>(() => {
    if (editing) {
      const client = state.clients.find((item) => item.id === editing.clientId)
      return {
        clientId: editing.clientId,
        client: client ? clientToDraft(client) : EMPTY_CLIENT,
        leadId: undefined,
        serviceId: editing.serviceId,
        complexityId: editing.complexityId,
        materialId: editing.materialId,
        options: editing.options,
        donors: donorsFromOrder(editing),
        masterId: editing.masterId,
        requestedDeadline: editing.requestedDeadline,
        advance: '',
        comment: editing.comment,
        touched: { master: true, deadline: true, donors: true, material: true },
      }
    }
    const lead = request.leadId ? state.leads.find((item) => item.id === request.leadId) : undefined
    const clientId = request.clientId ?? lead?.clientId ?? null
    const client = clientId ? state.clients.find((item) => item.id === clientId) : undefined
    return {
      clientId: client ? client.id : null,
      client: client ? clientToDraft(client) : EMPTY_CLIENT,
      leadId: lead?.id,
      serviceId: '',
      complexityId: 'base',
      materialId: 'cotton',
      options: emptyOptions(),
      donors: [],
      masterId: '',
      requestedDeadline: addDaysToDateString(derived.today, DEFAULT_LEAD_DAYS),
      advance: '',
      comment: '',
      touched: { master: false, deadline: false, donors: false, material: false },
    }
  })
  const [errors, setErrors] = useState<Errors>(NO_ERRORS)
  const [formError, setFormError] = useState<string | null>(null)

  const patch = (changes: Partial<OrderDraft>): void => setDraft((current) => ({ ...current, ...changes }))

  /* ------------------------------------------------------------------ расчёт */

  const service = services.find((item) => item.id === draft.serviceId)
  const pricing = useMemo(
    () =>
      service
        ? calcPricing({
            service,
            complexityId: draft.complexityId,
            materialId: draft.materialId,
            options: draft.options,
          })
        : null,
    [service, draft.complexityId, draft.materialId, draft.options],
  )

  const suggested = pricing && service
    ? suggestDeadline(derived.today, normHours(pricing), pricing.kComplexity)
    : addDaysToDateString(derived.today, DEFAULT_LEAD_DAYS)
  const requestedDeadline = draft.touched.deadline ? draft.requestedDeadline : suggested

  const master = state.masters.find((item) => item.id === draft.masterId)
  const assessment = master
    ? assessLoad({
        masterId: master.id,
        capacity: master.capacity,
        orders: state.orders,
        ...(editing ? { excludeOrderId: editing.id } : {}),
      })
    : null
  const shiftDays = assessment?.shiftDays ?? 0
  const finalDeadline = isDateString(requestedDeadline) ? applyShift(requestedDeadline, shiftDays) : requestedDeadline

  const consumption = useMemo(
    () => (service ? orderConsumption({ options: draft.options }, service.hoursMax) : {}),
    [service, draft.options],
  )

  const advanceValue = editing ? 0 : parseMoney(draft.advance)
  const alreadyPaid = editView?.paid ?? 0
  const total = pricing?.clientTotal ?? 0

  const newLeadClientIds = useMemo(() => new Set(derived.newLeads.map((item) => item.lead.clientId)), [derived.newLeads])

  /* ---------------------------------------------------------------- обработчики */

  const chooseService = (id: string): void => {
    const next = services.find((item) => item.id === id)
    if (!next) return
    setDraft((current) => ({
      ...current,
      serviceId: id,
      complexityId: next.defaultComplexity,
      materialId: current.touched.material ? current.materialId : next.donor.materialId,
      masterId: current.touched.master && current.masterId ? current.masterId : next.defaultMasterId,
      donors: current.touched.donors ? current.donors : [donorFromService(next)],
    }))
    setErrors((current) => ({ ...current, service: undefined, master: undefined }))
  }

  const validate = (): Errors | null => {
    const found: Errors = { client: {}, donors: {} }
    const c = draft.client
    if (c.lastName.trim().length < 2) found.client.lastName = 'Введите фамилию'
    if (c.firstName.trim().length < 2) found.client.firstName = 'Введите имя'
    if (!isValidPhone(c.phone)) found.client.phone = 'Телефон в формате +7 900 000-00-00'
    if (c.email.trim() && !isValidEmail(c.email)) found.client.email = 'Проверьте e-mail'
    if (!draft.clientId && isValidPhone(c.phone)) {
      const duplicate = state.clients.find((item) => phoneDigits(item.phone) === phoneDigits(c.phone))
      if (duplicate) found.client.phone = `Клиент с таким телефоном уже есть: ${duplicate.lastName} ${duplicate.firstName}. Выберите его из списка.`
    }
    if (!service) found.service = 'Выберите услугу из каталога'
    if (!master) found.master = 'Выберите мастера'
    if (!isDateString(requestedDeadline)) found.deadline = 'Укажите срок'
    else if (!editing && requestedDeadline < derived.today) found.deadline = 'Срок не может быть в прошлом'
    if (advanceValue > total && total > 0) found.advance = 'Аванс больше стоимости заказа'
    for (const donor of draft.donors) {
      if (donor.title.trim().length === 0) found.donors[donor.key] = 'Укажите, что за вещь'
    }
    const hasErrors =
      Object.keys(found.client).length > 0 ||
      found.service !== undefined ||
      found.master !== undefined ||
      found.deadline !== undefined ||
      found.advance !== undefined ||
      Object.keys(found.donors).length > 0
    return hasErrors ? found : null
  }

  const submit = (event: React.FormEvent): void => {
    event.preventDefault()
    if (locked) return
    const found = validate()
    if (found) {
      setErrors(found)
      setFormError('Проверьте выделенные поля — заказ пока не сохранён.')
      const target =
        found.service !== undefined || found.master !== undefined
          ? document.getElementById('order-service-anchor')
          : document.getElementById('order-client-anchor')
      target?.scrollIntoView({ behavior: 'smooth', block: 'start' })
      return
    }
    if (!service || !master) return
    setErrors(NO_ERRORS)
    setFormError(null)

    const fields = {
      lastName: draft.client.lastName.trim(),
      firstName: draft.client.firstName.trim(),
      middleName: draft.client.middleName.trim(),
      phone: formatPhone(draft.client.phone),
      email: normalizeEmail(draft.client.email),
      contact: draft.client.contact,
    }
    const donors = draft.donors.map((donor) => ({
      ...(donor.code ? { code: donor.code } : {}),
      id: donor.id ?? newId('d'),
      title: donor.title.trim(),
      materialId: donor.materialId as MaterialId,
      weightKg: parseDecimal(donor.weight),
      note: donor.note.trim(),
    }))

    if (editing) {
      actions.updateOrder(editing.id, {
        serviceId: service.id,
        complexityId: draft.complexityId,
        materialId: draft.materialId,
        options: draft.options,
        masterId: master.id,
        deadline: finalDeadline,
        requestedDeadline,
        apsShiftDays: shiftDays,
        comment: draft.comment.trim(),
        donors,
      })
      toast({ title: `Заказ ${editing.number} обновлён`, description: 'Расчёты, ЗП и остатки склада пересчитаны.' })
      onClose()
      return
    }

    let clientId = draft.clientId
    if (clientId) {
      const existing = state.clients.find((item) => item.id === clientId)
      if (existing) {
        const changed = (Object.keys(fields) as (keyof typeof fields)[]).some((key) => existing[key] !== fields[key])
        if (changed) actions.saveClient({ ...existing, ...fields } satisfies Client)
      }
    } else {
      clientId = newId('c')
      actions.saveClient({
        id: clientId,
        ...fields,
        createdAt: new Date().toISOString(),
        source: 'admin',
        tierOverride: null,
      })
    }

    const openLead =
      draft.leadId ??
      state.leads.find(
        (lead) => lead.clientId === clientId && (lead.status === 'new' || lead.status === 'contacted'),
      )?.id

    const id = actions.createOrder({
      clientId,
      serviceId: service.id,
      complexityId: draft.complexityId,
      materialId: draft.materialId,
      options: draft.options,
      donors: donors.map(({ title, materialId, weightKg, note }) => ({ title, materialId, weightKg, note })),
      masterId: master.id,
      requestedDeadline,
      deadline: finalDeadline,
      apsShiftDays: shiftDays,
      comment: draft.comment.trim(),
      advance: advanceValue,
      ...(openLead ? { leadId: openLead } : {}),
    })
    const number = formatOrderNumber(new Date().toISOString(), state.counters.order + 1)
    toast({
      title: `Заказ ${number} создан`,
      description: `${fields.lastName} ${fields.firstName} · ${formatRub(total)}${
        donors.length > 0 ? ` · вещей-доноров на склад: ${donors.length}` : ''
      }`,
    })
    onClose()
    router.push(`/orders/${id}`)
  }

  /* ---------------------------------------------------------------------- вид */

  const remaining = Math.max(0, total - alreadyPaid - advanceValue)
  const load = assessment
  const loadTone = !load ? 'success' : load.overloaded ? 'destructive' : load.projectedLoad > 60 ? 'warning' : 'success'

  const footer = (
    <>
      <div className="mr-auto min-w-0 text-left">
        {formError ? (
          <p role="alert" className="text-xs text-destructive-text">
            {formError}
          </p>
        ) : (
          <p className="font-mono text-xs text-muted-foreground">
            Итого <span className="font-semibold text-foreground tabular-nums">{formatRub(total)}</span> · остаток{' '}
            <span className="font-semibold text-foreground tabular-nums">{formatRub(remaining)}</span>
          </p>
        )}
      </div>
      <Button variant="ghost" onClick={onClose}>
        Отмена
      </Button>
      {locked ? null : (
        <Button type="submit" form="order-form">
          {editing ? 'Сохранить изменения' : 'Создать заказ'}
        </Button>
      )}
    </>
  )

  return (
    <Modal
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      size="xl"
      title={editing ? `Изменить заказ ${editing.number}` : 'Новый заказ'}
      description="Калькулятор считает цену, ЗП мастера, срок и расход материалов сразу — по мере выбора."
      footer={footer}
    >
      {locked ? (
        <p role="alert" className="flex gap-2 rounded-lg border border-warning/40 bg-warning/10 p-3 text-sm">
          <TriangleAlert className="mt-0.5 size-4 shrink-0 text-warning-text" aria-hidden="true" />
          ЗП по этому заказу уже выплачена, акт подписан — менять состав и цену нельзя.
        </p>
      ) : (
        <form id="order-form" onSubmit={submit} noValidate className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_21rem]">
          <div className="min-w-0 space-y-7">
            <div id="order-client-anchor">
              <Section n={1} title="Клиент">
                <ClientPicker
                  clients={derived.clients}
                  newLeadClientIds={newLeadClientIds}
                  clientId={draft.clientId}
                  draft={draft.client}
                  errors={errors.client}
                  locked={Boolean(editing)}
                  onSelect={(clientId, client) => patch({ clientId, client })}
                  onChange={(client) => patch({ client })}
                />
              </Section>
            </div>

            <div id="order-service-anchor">
              <Section n={2} title="Услуга" hint="Выбор подставляет базовую цену, ставку мастера и норму времени.">
                <ServicePicker services={services} value={draft.serviceId} onChange={chooseService} error={errors.service} />
              </Section>
            </div>

            <Section n={3} title="Сложность и материал">
              <fieldset>
                <legend className="mb-1.5 font-mono text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  К сложности
                </legend>
                <div role="radiogroup" aria-label="Коэффициент сложности" className="grid grid-cols-3 gap-1.5 sm:grid-cols-6">
                  {COMPLEXITY_LEVELS.map((level) => {
                    const active = draft.complexityId === level.id
                    return (
                      <button
                        key={level.id}
                        type="button"
                        role="radio"
                        aria-checked={active}
                        title={level.hint}
                        onClick={() => patch({ complexityId: level.id as ComplexityId })}
                        className={cn(
                          'flex min-h-14 flex-col items-center justify-center rounded-md border px-1 py-1.5 transition-colors',
                          active
                            ? 'border-primary bg-primary/10'
                            : 'border-input bg-background text-muted-foreground hover:bg-muted hover:text-foreground',
                        )}
                      >
                        <span className="font-mono text-base font-bold tabular-nums">{level.k.toFixed(1)}</span>
                        <span className="text-2xs leading-tight">{level.label}</span>
                      </button>
                    )
                  })}
                </div>
                <p className="mt-1.5 text-xs text-muted-foreground">
                  {COMPLEXITY_LEVELS.find((level) => level.id === draft.complexityId)?.hint}
                </p>
              </fieldset>
              <div className="mt-3 max-w-md">
                <Field label="К материала" htmlFor="o-material">
                  <Select
                    id="o-material"
                    value={draft.materialId}
                    onChange={(event) =>
                      setDraft((current) => ({
                        ...current,
                        materialId: event.target.value as MaterialId,
                        touched: { ...current.touched, material: true },
                      }))
                    }
                  >
                    {MATERIALS.map((material) => (
                      <option key={material.id} value={material.id}>
                        {material.label} (×{material.k.toFixed(1)})
                      </option>
                    ))}
                  </Select>
                </Field>
              </div>
            </Section>

            <Section n={4} title="Дополнительные операции" hint="Утепление, фурнитура, карманы, декор, обработка краёв — идут и в цену, и в ЗП мастера.">
              <ExtraOpsPicker options={draft.options} onChange={(options) => patch({ options })} />
            </Section>

            <Section n={5} title="Арт-опции" hint="Роспись, вышивка, деструкция — добавляются к цене клиента.">
              <ArtPicker options={draft.options} onChange={(options) => patch({ options })} />
            </Section>

            <Section n={6} title="Спецдоплаты и срочность">
              <SpecialPicker options={draft.options} onChange={(options) => patch({ options })} />
            </Section>

            <Section n={7} title="Вещи-доноры" hint="После сохранения попадут на склад — вкладка «Вещи-доноры».">
              <DonorsEditor
                donors={draft.donors}
                errors={errors.donors}
                onChange={(donors) => setDraft((current) => ({ ...current, donors, touched: { ...current.touched, donors: true } }))}
              />
            </Section>

            <Section n={8} title="Мастер и срок (APS)">
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Мастер" htmlFor="o-master" error={errors.master}>
                  <Select
                    id="o-master"
                    value={draft.masterId}
                    aria-invalid={Boolean(errors.master) || undefined}
                    onChange={(event) =>
                      setDraft((current) => ({
                        ...current,
                        masterId: event.target.value,
                        touched: { ...current.touched, master: true },
                      }))
                    }
                  >
                    <option value="">Выберите мастера…</option>
                    {derived.masters.map((item) => (
                      <option key={item.master.id} value={item.master.id}>
                        {item.master.name} — {item.master.role} · {item.load}%
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Желаемый срок" htmlFor="o-deadline" error={errors.deadline}>
                  <Input
                    id="o-deadline"
                    type="date"
                    min={editing ? undefined : derived.today}
                    value={requestedDeadline}
                    onChange={(event) =>
                      setDraft((current) => ({
                        ...current,
                        requestedDeadline: event.target.value,
                        touched: { ...current.touched, deadline: true },
                      }))
                    }
                    aria-invalid={Boolean(errors.deadline) || undefined}
                  />
                </Field>
              </div>

              {load && master ? (
                <div className="mt-3 rounded-lg border border-border bg-background p-3">
                  <div className="flex flex-wrap items-baseline justify-between gap-2 text-xs">
                    <span className="text-muted-foreground">
                      Загрузка {master.name}: сейчас {load.currentLoad}% ({load.activeTasks} из {master.capacity} задач)
                    </span>
                    <span className="font-mono font-semibold tabular-nums">после заказа — {load.projectedLoad}%</span>
                  </div>
                  <Progress
                    value={Math.min(100, load.projectedLoad)}
                    tone={loadTone}
                    size="lg"
                    aria-label={`Загрузка мастера после заказа: ${load.projectedLoad}%`}
                    className="mt-2"
                  />
                  {load.overloaded ? (
                    <p
                      role="alert"
                      className="mt-3 flex gap-2 rounded-md border border-destructive/60 bg-destructive/15 p-2.5 text-sm text-destructive-text"
                    >
                      <TriangleAlert className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
                      <span>
                        Внимание: Загруженность мастера {load.projectedLoad}%. Срок выполнения автоматически смещается на +{load.shiftDays}{' '}
                        дней к выбранному дедлайну
                      </span>
                    </p>
                  ) : null}
                  <p className="mt-3 flex items-center gap-2 text-sm">
                    <CalendarClock className="size-4 text-muted-foreground" aria-hidden="true" />
                    Итоговый срок:{' '}
                    <strong className="font-mono" data-testid="final-deadline">
                      {isDateString(finalDeadline) ? formatDateString(finalDeadline) : '—'}
                    </strong>
                    {shiftDays > 0 ? (
                      <span className="text-xs text-destructive-text">(+{pluralDays(shiftDays)} из-за загрузки)</span>
                    ) : null}
                  </p>
                </div>
              ) : null}
            </Section>

            {editing ? null : (
              <Section n={9} title="Оплата">
                <div className="grid gap-3 sm:grid-cols-[14rem_1fr] sm:items-end">
                  <Field label="Аванс, ₽" htmlFor="o-advance" error={errors.advance}>
                    <Input
                      id="o-advance"
                      inputMode="numeric"
                      placeholder="0"
                      value={draft.advance}
                      onChange={(event) => {
                        patch({ advance: event.target.value.replace(/[^\d]/g, '') })
                        setErrors((current) => ({ ...current, advance: undefined }))
                      }}
                      aria-invalid={Boolean(errors.advance) || undefined}
                      aria-describedby={errors.advance ? 'o-advance-error' : undefined}
                    />
                  </Field>
                  <div className="flex flex-wrap gap-1.5" role="group" aria-label="Быстрый аванс">
                    {[0, 30, 50, 100].map((percent) => (
                      <Button
                        key={percent}
                        variant="outline"
                        size="sm"
                        disabled={total === 0}
                        onClick={() => patch({ advance: percent === 0 ? '' : String(Math.round((total * percent) / 100)) })}
                      >
                        {percent === 0 ? 'Без аванса' : percent === 100 ? 'Вся сумма' : `${percent}%`}
                      </Button>
                    ))}
                  </div>
                </div>
              </Section>
            )}

            <Section n={editing ? 9 : 10} title="Комментарий заказчика">
              <Textarea
                id="o-comment"
                aria-label="Комментарий заказчика"
                placeholder="Пожелания по дизайну, примерки, особые требования…"
                value={draft.comment}
                onChange={(event) => patch({ comment: event.target.value })}
              />
            </Section>
          </div>

          <aside aria-label="Расчёт заказа" className="lg:sticky lg:top-0 lg:self-start">
            <div className="rounded-xl border border-border bg-background/60 p-4">
              <PricingSummary
                pricing={pricing}
                advance={advanceValue}
                alreadyPaid={alreadyPaid}
                consumption={consumption}
                stock={derived.stockById}
                consumptionCounted={Boolean(editing)}
              />
            </div>
          </aside>
        </form>
      )}
    </Modal>
  )
}
