'use client'

import { Check } from 'lucide-react'

import { STAGE_BORDER_CLASS, STAGE_FILL_CLASS, STAGE_TEXT_CLASS, stageTone } from '@/components/orders/stage-ui'
import { STAGES } from '@/lib/domain/catalog'
import type { OrderView } from '@/lib/domain/derive'
import { cn } from '@/lib/utils'

interface StageTrackProps {
  view: OrderView
  /** Если задан — каждый этап превращается в кнопку (админ переводит заказ по этапам). */
  onSelect?: (stage: number) => void
  disabled?: boolean
}

/**
 * Лента из 8 этапов. Пройденные — залиты, текущий подсвечен цветом этапа
 * (раскрой — деним, ОТК/«Готово» — изумруд), будущие — приглушены.
 */
export function StageTrack({ view, onSelect, disabled = false }: StageTrackProps) {
  const current = view.order.stage
  const cancelled = view.order.state === 'cancelled'

  return (
    <ol className="grid grid-cols-2 gap-2 sm:grid-cols-4" aria-label="Этапы производства">
      {STAGES.map((stage) => {
        const done = stage.n < current || (stage.n === current && stage.n === STAGES.length)
        const active = stage.n === current && !done
        const tone = stageTone(stage.n)
        const body = (
          <>
            <span className="flex items-center justify-between gap-1">
              <span
                className={cn(
                  'flex size-5 items-center justify-center rounded-full font-mono text-2xs font-bold',
                  done
                    ? cn(STAGE_FILL_CLASS[tone], tone === 'denim' ? 'text-white' : 'text-primary-foreground')
                    : active
                      ? cn(STAGE_FILL_CLASS[tone], tone === 'denim' ? 'text-white' : 'text-primary-foreground')
                      : 'bg-muted text-muted-foreground',
                )}
              >
                {done ? <Check className="size-3" aria-hidden="true" /> : stage.n}
              </span>
              {active ? (
                <span className={cn('font-mono text-2xs font-semibold', STAGE_TEXT_CLASS[tone])}>
                  {view.order.stageProgress}%
                </span>
              ) : null}
            </span>
            <span className="mt-1.5 block break-words text-xs font-medium leading-tight">{stage.title}</span>
          </>
        )

        const className = cn(
          'block min-h-[4.25rem] w-full rounded-lg border p-2 text-left transition-colors',
          done || active
            ? cn(STAGE_BORDER_CLASS[tone], active && 'ring-1 ring-inset', active && tone === 'denim' && 'ring-denim')
            : 'border-border bg-background text-muted-foreground',
          active && tone === 'primary' && 'ring-primary',
          active && tone === 'success' && 'ring-success',
          cancelled && 'opacity-50',
          onSelect && !disabled && 'cursor-pointer hover:brightness-125',
        )

        return (
          <li key={stage.n} aria-current={active ? 'step' : undefined}>
            {onSelect ? (
              <button
                type="button"
                disabled={disabled}
                onClick={() => onSelect(stage.n)}
                aria-label={`Перевести на этап ${stage.n}: ${stage.title}`}
                className={cn(className, 'disabled:cursor-not-allowed disabled:opacity-60')}
              >
                {body}
              </button>
            ) : (
              <div className={className}>{body}</div>
            )}
          </li>
        )
      })}
    </ol>
  )
}
