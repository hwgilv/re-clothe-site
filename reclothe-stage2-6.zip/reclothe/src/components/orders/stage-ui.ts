import type { ProgressTone } from '@/components/ui/progress'
import { FINAL_STAGE } from '@/lib/domain/catalog'

/**
 * Цвет этапа: раскрой — джинсовый синий, ОТК и «Готово» — изумрудный, остальные — оранжевый.
 * Единое правило для клиентского кабинета, карточек заказов и производства.
 */
export function stageTone(stage: number): ProgressTone {
  if (stage === 4) return 'denim'
  if (stage >= 7 || stage === FINAL_STAGE) return 'success'
  return 'primary'
}

export const STAGE_TEXT_CLASS: Record<ProgressTone, string> = {
  primary: 'text-primary-text',
  success: 'text-success-text',
  warning: 'text-warning-text',
  destructive: 'text-destructive-text',
  denim: 'text-denim-text',
}

export const STAGE_BORDER_CLASS: Record<ProgressTone, string> = {
  primary: 'border-primary/50 bg-primary/10',
  success: 'border-success/50 bg-success/10',
  warning: 'border-warning/50 bg-warning/10',
  destructive: 'border-destructive/50 bg-destructive/10',
  denim: 'border-denim/60 bg-denim/15',
}

export const STAGE_FILL_CLASS: Record<ProgressTone, string> = {
  primary: 'bg-primary',
  success: 'bg-success',
  warning: 'bg-warning',
  destructive: 'bg-destructive',
  denim: 'bg-denim',
}
