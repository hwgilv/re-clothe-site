import { TriangleAlert } from 'lucide-react'

import { Progress } from '@/components/ui/progress'
import { getStockItem } from '@/lib/domain/catalog'
import type { StockView } from '@/lib/domain/derive'
import { normHours, type Pricing, type PriceLine } from '@/lib/domain/pricing'
import { formatNumber, formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'

function Lines({ lines }: { lines: readonly PriceLine[] }) {
  return (
    <ul className="space-y-1">
      {lines.map((line) => (
        <li key={line.key} className="flex items-start justify-between gap-3 text-xs">
          <span className="min-w-0 text-muted-foreground">
            {line.label}
            {line.qty !== 1 && line.key !== 'base' ? ` × ${line.qty}` : ''}
          </span>
          <span className="shrink-0 font-mono tabular-nums">{formatRub(line.amount)}</span>
        </li>
      ))}
    </ul>
  )
}

interface PricingSummaryProps {
  pricing: Pricing | null
  advance: number
  /** Сколько уже оплачено по заказу (при редактировании). */
  alreadyPaid?: number
  consumption: Record<string, number>
  stock: ReadonlyMap<string, StockView>
  /** При редактировании расход уже учтён в остатках — добавлять его повторно не нужно. */
  consumptionCounted?: boolean
}

/**
 * Живой расчёт: цена клиента, оплата мастеру, маржа, остаток к оплате.
 * Пересчитывается при каждом нажатии в форме — все цифры берутся из pricing.ts и каталога.
 */
export function PricingSummary({
  pricing,
  advance,
  alreadyPaid = 0,
  consumption,
  stock,
  consumptionCounted = false,
}: PricingSummaryProps) {
  if (!pricing) {
    return (
      <div className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
        Выберите услугу — здесь появится расчёт стоимости.
      </div>
    )
  }

  const paid = alreadyPaid + advance
  const remaining = Math.max(0, pricing.clientTotal - paid)
  const paidPercent = pricing.clientTotal > 0 ? Math.min(100, Math.round((paid / pricing.clientTotal) * 100)) : 0
  const negative = pricing.margin < 0

  const shortages = consumptionCounted
    ? []
    : Object.entries(consumption)
        .map(([itemId, need]) => {
          const view = stock.get(itemId)
          const info = getStockItem(itemId)
          return view && info && need > view.balance.balance
            ? { name: info.name, unit: info.unit, need, have: Math.max(0, view.balance.balance) }
            : null
        })
        .filter((item): item is NonNullable<typeof item> => item !== null)

  return (
    <div className="space-y-4">
      <section aria-label="Стоимость для клиента">
        <h3 className="mb-2 font-mono text-xs uppercase tracking-wider text-muted-foreground">Стоимость для клиента</h3>
        <Lines lines={pricing.clientLines} />
        <p className="mt-2 flex items-baseline justify-between gap-3 border-t border-border pt-2">
          <span className="text-sm font-medium">Итого</span>
          <span className="font-mono text-xl font-bold tabular-nums text-primary-text" data-testid="client-total">
            {formatRub(pricing.clientTotal)}
          </span>
        </p>
      </section>

      <section aria-label="Оплата" className="rounded-lg border border-border bg-background p-3">
        <div className="flex items-baseline justify-between gap-2 text-sm">
          <span className="text-muted-foreground">Аванс</span>
          <span className="font-mono tabular-nums">{formatRub(paid)}</span>
        </div>
        <Progress
          value={paidPercent}
          tone="success"
          size="lg"
          aria-label={`Оплачено ${paidPercent}%`}
          className="mt-2"
        />
        <div className="mt-1.5 flex items-center justify-between gap-2 text-xs">
          <span className="font-mono text-muted-foreground">Оплачено {paidPercent}%</span>
          <span className="font-medium" data-testid="remaining">
            Остаток к оплате: {formatNumber(remaining)} руб.
          </span>
        </div>
      </section>

      <section aria-label="Оплата мастеру" className="rounded-lg border border-border bg-background p-3">
        <h3 className="mb-2 font-mono text-xs uppercase tracking-wider text-muted-foreground">Оплата мастеру</h3>
        <Lines lines={pricing.masterLines} />
        <p className="mt-2 flex items-baseline justify-between gap-3 border-t border-border pt-2 text-sm">
          <span className="font-medium">ЗП мастера</span>
          <span className="font-mono font-semibold tabular-nums">{formatRub(pricing.masterTotal)}</span>
        </p>
        <p className="mt-1 flex items-baseline justify-between gap-3 text-sm">
          <span className="text-muted-foreground">Маржа студии</span>
          <span
            className={cn(
              'font-mono font-semibold tabular-nums',
              negative ? 'text-destructive-text' : 'text-success-text',
            )}
          >
            {formatRub(pricing.margin)} · {Math.round(pricing.marginFraction * 100)}%
          </span>
        </p>
        {negative ? (
          <p role="alert" className="mt-2 flex gap-2 rounded-md border border-destructive/50 bg-destructive/10 p-2 text-xs">
            <TriangleAlert className="mt-0.5 size-3.5 shrink-0 text-destructive-text" aria-hidden="true" />
            <span>
              Цена клиента не покрывает оплату мастеру: коэффициенты сложности и материала повышают ЗП, а цена клиента
              от них не зависит. Снизьте коэффициенты или поднимите цену услуги в «Настройках».
            </span>
          </p>
        ) : null}
      </section>

      <p className="font-mono text-xs text-muted-foreground">
        Норма времени: {pricing.hoursMin}–{pricing.hoursMax} ч
        {pricing.extraHours > 0 ? ` + ${formatNumber(pricing.extraHours, 1)} ч на опции` : ''} · в плане{' '}
        {formatNumber(normHours(pricing), 1)} ч
      </p>

      {shortages.length > 0 ? (
        <section
          aria-label="Нехватка материалов"
          className="rounded-lg border border-warning/40 bg-warning/10 p-3 text-xs"
        >
          <p className="font-medium text-warning-text">На складе не хватает расходников</p>
          <ul className="mt-1 space-y-0.5 text-muted-foreground">
            {shortages.map((item) => (
              <li key={item.name}>
                {item.name}: нужно {formatNumber(item.need, 1)} {item.unit}, есть {formatNumber(item.have, 1)} {item.unit}
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  )
}
