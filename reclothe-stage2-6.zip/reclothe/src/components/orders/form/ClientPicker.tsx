'use client'

import { useId, useMemo, useState } from 'react'
import { Search, UserPlus, X } from 'lucide-react'

import type { ClientDraft } from '@/components/orders/form/draft'
import { clientToDraft } from '@/components/orders/form/draft'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Field } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { MESSENGERS } from '@/lib/domain/catalog'
import { phoneDigits } from '@/lib/domain/client'
import type { ClientView } from '@/lib/domain/derive'
import type { MessengerId } from '@/lib/domain/types'
import { formatNumber } from '@/lib/format'
import { cn } from '@/lib/utils'

interface ClientPickerProps {
  clients: readonly ClientView[]
  newLeadClientIds: ReadonlySet<string>
  clientId: string | null
  draft: ClientDraft
  errors: Partial<Record<keyof ClientDraft, string>>
  /** В режиме редактирования заказа клиента менять нельзя. */
  locked?: boolean
  onSelect: (clientId: string | null, draft: ClientDraft) => void
  onChange: (draft: ClientDraft) => void
}

function matches(view: ClientView, query: string): boolean {
  const text = query.trim().toLowerCase()
  if (!text) return true
  const digits = phoneDigits(text)
  return (
    view.name.toLowerCase().includes(text) ||
    view.client.email.toLowerCase().includes(text) ||
    (digits.length >= 3 && phoneDigits(view.client.phone).includes(digits))
  )
}

/**
 * Поиск клиента: выбор существующего подставляет ФИО, телефон, e-mail и мессенджер.
 * Если клиента нет в базе — те же поля заполняются вручную, и клиент создаётся вместе с заказом.
 */
export function ClientPicker({
  clients,
  newLeadClientIds,
  clientId,
  draft,
  errors,
  locked = false,
  onSelect,
  onChange,
}: ClientPickerProps) {
  const listId = useId()
  const [query, setQuery] = useState('')
  const [open, setOpen] = useState(false)

  const results = useMemo(
    () =>
      clients
        .filter((view) => matches(view, query))
        // Свежие заявки с сайта показываем первыми — их чаще всего оформляют.
        .sort(
          (a, b) =>
            Number(newLeadClientIds.has(b.client.id)) - Number(newLeadClientIds.has(a.client.id)),
        )
        .slice(0, 8),
    [clients, query, newLeadClientIds],
  )
  const selected = clientId ? clients.find((view) => view.client.id === clientId) : undefined

  const set = <K extends keyof ClientDraft>(key: K, value: ClientDraft[K]): void =>
    onChange({ ...draft, [key]: value })

  return (
    <div className="space-y-3">
      {!locked ? (
        <div className="relative">
          <label htmlFor={`${listId}-search`} className="sr-only">
            Найти клиента
          </label>
          <Search
            className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <Input
            id={`${listId}-search`}
            role="combobox"
            aria-expanded={open}
            aria-controls={listId}
            aria-autocomplete="list"
            autoComplete="off"
            placeholder="Найти клиента по фамилии, телефону или e-mail…"
            className="pl-9"
            value={query}
            onChange={(event) => {
              setQuery(event.target.value)
              setOpen(true)
            }}
            onFocus={() => setOpen(true)}
            onBlur={() => window.setTimeout(() => setOpen(false), 150)}
          />
          {open ? (
            <ul
              id={listId}
              role="listbox"
              aria-label="Клиенты"
              className="absolute inset-x-0 top-full z-20 mt-1 max-h-64 overflow-y-auto rounded-lg border border-border bg-background shadow-xl scrollbar-thin"
            >
              {results.length === 0 ? (
                <li className="px-3 py-3 text-sm text-muted-foreground">
                  Клиент не найден — заполните поля ниже, он будет создан вместе с заказом.
                </li>
              ) : (
                results.map((view) => (
                  <li key={view.client.id} role="option" aria-selected={view.client.id === clientId}>
                    <button
                      type="button"
                      // onMouseDown: срабатывает раньше onBlur поля поиска.
                      onMouseDown={(event) => {
                        event.preventDefault()
                        onSelect(view.client.id, clientToDraft(view.client))
                        setQuery('')
                        setOpen(false)
                      }}
                      className="flex w-full items-center justify-between gap-2 px-3 py-2.5 text-left text-sm transition-colors hover:bg-muted"
                    >
                      <span className="min-w-0">
                        <span className="block truncate font-medium">{view.name}</span>
                        <span className="block truncate font-mono text-xs text-muted-foreground">
                          {view.client.phone} · {view.client.email || 'без e-mail'}
                        </span>
                      </span>
                      {newLeadClientIds.has(view.client.id) ? <Badge variant="default">Новый лид</Badge> : null}
                    </button>
                  </li>
                ))
              )}
            </ul>
          ) : null}
        </div>
      ) : null}

      {selected ? (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-success/40 bg-success/10 px-3 py-2 text-sm">
          <span className="min-w-0">
            <span className="font-medium">Выбран: {selected.name}</span>
            <span className="ml-2 text-xs text-muted-foreground">
              карта «{selected.tier.label}» · {formatNumber(selected.coins)} RE-coins
            </span>
          </span>
          {!locked ? (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                onSelect(null, { lastName: '', firstName: '', middleName: '', phone: '', email: '', contact: 'telegram' })
              }}
            >
              <X aria-hidden="true" />
              Сбросить
            </Button>
          ) : null}
        </div>
      ) : (
        <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <UserPlus className="size-3.5" aria-hidden="true" />
          Новый клиент: заполните данные — карточка создастся при сохранении заказа.
        </p>
      )}

      <div className="grid gap-3 sm:grid-cols-3">
        <Field label="Фамилия" htmlFor="oc-last" error={errors.lastName}>
          <Input
            id="oc-last"
            disabled={locked}
            value={draft.lastName}
            onChange={(event) => set('lastName', event.target.value)}
            aria-invalid={Boolean(errors.lastName) || undefined}
            aria-describedby={errors.lastName ? 'oc-last-error' : undefined}
          />
        </Field>
        <Field label="Имя" htmlFor="oc-first" error={errors.firstName}>
          <Input
            id="oc-first"
            disabled={locked}
            value={draft.firstName}
            onChange={(event) => set('firstName', event.target.value)}
            aria-invalid={Boolean(errors.firstName) || undefined}
            aria-describedby={errors.firstName ? 'oc-first-error' : undefined}
          />
        </Field>
        <Field label="Отчество" htmlFor="oc-middle">
          <Input id="oc-middle" disabled={locked} value={draft.middleName} onChange={(event) => set('middleName', event.target.value)} />
        </Field>
        <Field label="Телефон" htmlFor="oc-phone" error={errors.phone}>
          <Input
            id="oc-phone"
            disabled={locked}
            type="tel"
            inputMode="tel"
            placeholder="+7 900 000-00-00"
            value={draft.phone}
            onChange={(event) => set('phone', event.target.value)}
            aria-invalid={Boolean(errors.phone) || undefined}
            aria-describedby={errors.phone ? 'oc-phone-error' : undefined}
          />
        </Field>
        <Field label="Email" htmlFor="oc-email" error={errors.email}>
          <Input
            id="oc-email"
            disabled={locked}
            type="email"
            inputMode="email"
            value={draft.email}
            onChange={(event) => set('email', event.target.value)}
            aria-invalid={Boolean(errors.email) || undefined}
            aria-describedby={errors.email ? 'oc-email-error' : undefined}
          />
        </Field>
        <Field label="Мессенджер" htmlFor="oc-contact">
          <Select
            id="oc-contact"
            disabled={locked}
            value={draft.contact}
            onChange={(event) => set('contact', event.target.value as MessengerId)}
          >
            {MESSENGERS.map((messenger) => (
              <option key={messenger.id} value={messenger.id}>
                {messenger.label}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      {locked ? (
        <p className={cn('text-xs text-muted-foreground')}>Клиент закреплён за заказом. Изменить его контакты можно в разделе «Клиенты».</p>
      ) : null}
    </div>
  )
}
