'use client'

import { ChipToggle } from '@/components/ui/chip-toggle'
import { Stepper } from '@/components/ui/stepper'
import {
  ART_GROUPS,
  ART_OPTIONS,
  EXTRA_OPS,
  OP_GROUPS,
  SPECIAL_SURCHARGES,
  URGENCY_LEVELS,
  type ArtOption,
  type ExtraOption,
} from '@/lib/domain/catalog'
import type { OrderOptions, UrgencyId } from '@/lib/domain/types'
import { formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'

type CountOption = ExtraOption | ArtOption

function OptionRow({
  option,
  qty,
  onChange,
}: {
  option: CountOption
  qty: number
  onChange: (qty: number) => void
}) {
  const unitSuffix = option.unit === 'услуга' ? '' : ` / ${option.unit === 'шт.' ? 'шт.' : 'м'}`
  const price = `+${formatRub(option.price)}${unitSuffix}`

  if (option.unit === 'услуга') {
    return (
      <ChipToggle pressed={qty > 0} onPressedChange={(pressed) => onChange(pressed ? 1 : 0)}>
        <span className="flex items-baseline justify-between gap-2">
          <span className="leading-tight">{option.label}</span>
          <span className="shrink-0 font-mono text-xs text-muted-foreground">{price}</span>
        </span>
      </ChipToggle>
    )
  }

  return (
    <div
      className={cn(
        'flex min-h-10 items-center justify-between gap-2 rounded-md border px-3 py-1.5 text-sm',
        qty > 0 ? 'border-primary bg-primary/10' : 'border-input bg-background',
      )}
    >
      <span className="min-w-0 leading-tight">
        <span className="block">{option.label}</span>
        <span className="block font-mono text-xs text-muted-foreground">{price}</span>
      </span>
      <Stepper
        label={option.label}
        value={qty}
        onChange={onChange}
        step={option.unit === 'м' ? 0.5 : 1}
        max={option.unit === 'м' ? 50 : 99}
      />
    </div>
  )
}

function Group({
  title,
  options,
  quantities,
  onChange,
}: {
  title: string
  options: readonly CountOption[]
  quantities: Record<string, number>
  onChange: (id: string, qty: number) => void
}) {
  const selected = options.filter((option) => (quantities[option.id] ?? 0) > 0)
  return (
    <details className="group rounded-lg border border-border bg-background/40" open={selected.length > 0 || undefined}>
      <summary className="flex min-h-11 cursor-pointer list-none items-center justify-between gap-2 px-3 py-2 text-sm font-medium [&::-webkit-details-marker]:hidden">
        <span>{title}</span>
        <span className="flex items-center gap-2 font-mono text-2xs text-muted-foreground">
          {selected.length > 0 ? (
            <span className="rounded-full bg-primary px-1.5 font-semibold text-primary-foreground">{selected.length}</span>
          ) : null}
          <span aria-hidden="true" className="transition-transform group-open:rotate-90">
            ▸
          </span>
        </span>
      </summary>
      <div className="grid gap-1.5 p-2 pt-0 sm:grid-cols-2">
        {options.map((option) => (
          <OptionRow
            key={option.id}
            option={option}
            qty={quantities[option.id] ?? 0}
            onChange={(qty) => onChange(option.id, qty)}
          />
        ))}
      </div>
    </details>
  )
}

function withQty(map: Record<string, number>, id: string, qty: number): Record<string, number> {
  const next = { ...map }
  if (qty > 0) next[id] = qty
  else delete next[id]
  return next
}

interface OptionsPickerProps {
  options: OrderOptions
  onChange: (options: OrderOptions) => void
}

/** Доп. операции (табл. 7.6.1): утепление, фурнитура, карманы, декор, кромки. */
export function ExtraOpsPicker({ options, onChange }: OptionsPickerProps) {
  return (
    <div className="space-y-2">
      {OP_GROUPS.map((group) => (
        <Group
          key={group}
          title={group}
          options={EXTRA_OPS.filter((option) => option.group === group)}
          quantities={options.ops}
          onChange={(id, qty) => onChange({ ...options, ops: withQty(options.ops, id, qty) })}
        />
      ))}
    </div>
  )
}

/** Art-опции (табл. 7.6.2): роспись, вышивка, деструкция, аппликация. */
export function ArtPicker({ options, onChange }: OptionsPickerProps) {
  return (
    <div className="space-y-2">
      {ART_GROUPS.map((group) => (
        <Group
          key={group}
          title={group}
          options={ART_OPTIONS.filter((option) => option.group === group)}
          quantities={options.art}
          onChange={(id, qty) => onChange({ ...options, art: withQty(options.art, id, qty) })}
        />
      ))}
    </div>
  )
}

/** Спецдоплаты (табл. 7.6.3) и срочность. */
export function SpecialPicker({ options, onChange }: OptionsPickerProps) {
  return (
    <div className="space-y-4">
      <div className="grid gap-1.5 sm:grid-cols-2">
        <ChipToggle pressed={options.corset} onPressedChange={(corset) => onChange({ ...options, corset })}>
          <span className="flex items-baseline justify-between gap-2">
            <span>{SPECIAL_SURCHARGES.corset.label}</span>
            <span className="font-mono text-xs text-muted-foreground">+{formatRub(SPECIAL_SURCHARGES.corset.price)}</span>
          </span>
        </ChipToggle>
        <ChipToggle pressed={options.lining} onPressedChange={(lining) => onChange({ ...options, lining })}>
          <span className="flex items-baseline justify-between gap-2">
            <span>{SPECIAL_SURCHARGES.lining.label}</span>
            <span className="font-mono text-xs text-muted-foreground">+{formatRub(SPECIAL_SURCHARGES.lining.price)}</span>
          </span>
        </ChipToggle>
        <ChipToggle pressed={options.beads} onPressedChange={(beads) => onChange({ ...options, beads })}>
          <span className="flex items-baseline justify-between gap-2">
            <span>{SPECIAL_SURCHARGES.beads.label}</span>
            <span className="font-mono text-xs text-muted-foreground">+{formatRub(SPECIAL_SURCHARGES.beads.price)}</span>
          </span>
        </ChipToggle>
        <div
          className={cn(
            'flex min-h-10 items-center justify-between gap-2 rounded-md border px-3 py-1.5 text-sm',
            options.handSeamsMeters > 0 ? 'border-primary bg-primary/10' : 'border-input bg-background',
          )}
        >
          <span className="min-w-0 leading-tight">
            <span className="block">{SPECIAL_SURCHARGES.handSeamsPerMeter.label}</span>
            <span className="block font-mono text-xs text-muted-foreground">
              +{formatRub(SPECIAL_SURCHARGES.handSeamsPerMeter.price)} / м
            </span>
          </span>
          <Stepper
            label="Ручные швы, м"
            value={options.handSeamsMeters}
            onChange={(handSeamsMeters) => onChange({ ...options, handSeamsMeters })}
            step={0.5}
            max={50}
          />
        </div>
      </div>

      <fieldset>
        <legend className="mb-1.5 font-mono text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Срочность
        </legend>
        <div role="radiogroup" aria-label="Срочность" className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
          {URGENCY_LEVELS.map((level) => {
            const active = options.urgency === level.id
            return (
              <button
                key={level.id}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => onChange({ ...options, urgency: level.id as UrgencyId })}
                className={cn(
                  'min-h-10 rounded-md border px-2 py-2 text-center text-xs transition-colors',
                  active
                    ? 'border-primary bg-primary/10 font-medium text-foreground'
                    : 'border-input bg-background text-muted-foreground hover:bg-muted hover:text-foreground',
                )}
              >
                {level.label}
              </button>
            )
          })}
        </div>
      </fieldset>
    </div>
  )
}
