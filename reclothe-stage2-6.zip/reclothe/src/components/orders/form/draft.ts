import { MATERIALS } from '@/lib/domain/catalog'
import type {
  Client,
  ComplexityId,
  MaterialId,
  MessengerId,
  Order,
  OrderOptions,
  Service,
} from '@/lib/domain/types'

/** Строка вещи-донора в форме: вес хранится текстом, чтобы можно было печатать «1,5». */
export interface DonorDraft {
  key: string
  /** Id сохранённого донора (при редактировании заказа). */
  id?: string
  /** Складской код — есть только у уже сохранённых доноров. */
  code?: string
  title: string
  materialId: MaterialId
  weight: string
  note: string
}

export interface ClientDraft {
  lastName: string
  firstName: string
  middleName: string
  phone: string
  email: string
  contact: MessengerId
}

export interface OrderDraft {
  /** null — клиента ещё не выбрали (будет создан новый). */
  clientId: string | null
  client: ClientDraft
  leadId: string | undefined
  serviceId: string
  complexityId: ComplexityId
  materialId: MaterialId
  options: OrderOptions
  donors: DonorDraft[]
  masterId: string
  requestedDeadline: string
  advance: string
  comment: string
  /** Что администратор поправил вручную — автоподстановки это не перетирают. */
  touched: { master: boolean; deadline: boolean; donors: boolean; material: boolean }
}

export const EMPTY_CLIENT: ClientDraft = {
  lastName: '',
  firstName: '',
  middleName: '',
  phone: '',
  email: '',
  contact: 'telegram',
}

export function clientToDraft(client: Client): ClientDraft {
  return {
    lastName: client.lastName,
    firstName: client.firstName,
    middleName: client.middleName,
    phone: client.phone,
    email: client.email,
    contact: client.contact,
  }
}

let donorKeySeed = 0
export function nextDonorKey(): string {
  donorKeySeed += 1
  return `donor-${donorKeySeed}`
}

export function donorFromService(service: Service): DonorDraft {
  return {
    key: nextDonorKey(),
    title: service.donor.title,
    materialId: service.donor.materialId,
    weight: String(service.donor.weightKg).replace('.', ','),
    note: '',
  }
}

export function donorsFromOrder(order: Order): DonorDraft[] {
  return order.donors.map((donor) => ({
    key: nextDonorKey(),
    id: donor.id,
    code: donor.code,
    title: donor.title,
    materialId: donor.materialId,
    weight: String(donor.weightKg).replace('.', ','),
    note: donor.note,
  }))
}

/** «1,5» / «1.5» → 1.5; мусор → 0. */
export function parseDecimal(text: string): number {
  const value = Number.parseFloat(text.replace(',', '.').replace(/\s/g, ''))
  return Number.isFinite(value) && value > 0 ? Math.round(value * 1000) / 1000 : 0
}

export function parseMoney(text: string): number {
  const digits = text.replace(/[^\d]/g, '')
  return digits ? Number.parseInt(digits, 10) : 0
}

export function materialLabel(id: MaterialId): string {
  return MATERIALS.find((item) => item.id === id)?.label ?? id
}
