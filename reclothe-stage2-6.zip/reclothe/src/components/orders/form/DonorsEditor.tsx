'use client'

import { Droplets, Leaf, Plus, Trash2, Wind } from 'lucide-react'

import { nextDonorKey, parseDecimal, type DonorDraft } from '@/components/orders/form/draft'
import { Button } from '@/components/ui/button'
import { Field } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { MATERIALS } from '@/lib/domain/catalog'
import { calcEcoMetrics } from '@/lib/domain/eco'
import type { MaterialId } from '@/lib/domain/types'
import { formatNumber } from '@/lib/format'

interface DonorsEditorProps {
  donors: readonly DonorDraft[]
  onChange: (donors: DonorDraft[]) => void
  errors?: Record<string, string> | undefined
}

/** Вещи-доноры заказа: после сохранения попадают на склад («Склад → Вещи-доноры»). */
export function DonorsEditor({ donors, onChange, errors = {} }: DonorsEditorProps) {
  const update = (key: string, patch: Partial<DonorDraft>): void =>
    onChange(donors.map((donor) => (donor.key === key ? { ...donor, ...patch } : donor)))

  const totalKg = donors.reduce((total, donor) => total + parseDecimal(donor.weight), 0)
  const eco = calcEcoMetrics(Math.round(totalKg * 1000) / 1000)

  return (
    <div className="space-y-3">
      {donors.length === 0 ? (
        <p className="rounded-lg border border-dashed border-border px-3 py-4 text-center text-sm text-muted-foreground">
          Вещей-доноров нет. Добавьте то, что клиент приносит на переделку.
        </p>
      ) : null}

      <ul className="space-y-2">
        {donors.map((donor, index) => (
          <li key={donor.key} className="rounded-lg border border-border bg-background p-3">
            <div className="mb-2 flex items-center justify-between gap-2">
              <span className="font-mono text-2xs uppercase tracking-widest text-muted-foreground">
                Донор {index + 1}
                {donor.code ? ` · ${donor.code}` : ''}
              </span>
              <Button
                variant="ghost"
                size="sm"
                aria-label={`Удалить донора ${index + 1}`}
                onClick={() => onChange(donors.filter((item) => item.key !== donor.key))}
              >
                <Trash2 aria-hidden="true" />
              </Button>
            </div>
            <div className="grid gap-2 sm:grid-cols-[1fr_12rem_6rem]">
              <Field label="Что за вещь" htmlFor={`${donor.key}-title`} error={errors[donor.key]}>
                <Input
                  id={`${donor.key}-title`}
                  value={donor.title}
                  onChange={(event) => update(donor.key, { title: event.target.value })}
                  placeholder="Например: джинсовая куртка, мужская"
                  aria-invalid={Boolean(errors[donor.key]) || undefined}
                  aria-describedby={errors[donor.key] ? `${donor.key}-title-error` : undefined}
                />
              </Field>
              <Field label="Материал" htmlFor={`${donor.key}-material`}>
                <Select
                  id={`${donor.key}-material`}
                  value={donor.materialId}
                  onChange={(event) => update(donor.key, { materialId: event.target.value as MaterialId })}
                >
                  {MATERIALS.map((material) => (
                    <option key={material.id} value={material.id}>
                      {material.label}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Вес, кг" htmlFor={`${donor.key}-weight`}>
                <Input
                  id={`${donor.key}-weight`}
                  inputMode="decimal"
                  value={donor.weight}
                  onChange={(event) => update(donor.key, { weight: event.target.value })}
                />
              </Field>
            </div>
            <div className="mt-2">
              <Field label="Заметка" htmlFor={`${donor.key}-note`}>
                <Input
                  id={`${donor.key}-note`}
                  value={donor.note}
                  onChange={(event) => update(donor.key, { note: event.target.value })}
                  placeholder="Состояние, пятна, особенности"
                />
              </Field>
            </div>
          </li>
        ))}
      </ul>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() =>
            onChange([
              ...donors,
              { key: nextDonorKey(), title: '', materialId: 'cotton', weight: '', note: '' },
            ])
          }
        >
          <Plus aria-hidden="true" />
          Добавить вещь
        </Button>
        <p className="flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <Leaf className="size-3.5 text-success-text" aria-hidden="true" />
            {formatNumber(eco.textileSavedKg, 1)} кг
          </span>
          <span className="inline-flex items-center gap-1">
            <Droplets className="size-3.5 text-success-text" aria-hidden="true" />
            {formatNumber(eco.waterSavedLiters)} л воды
          </span>
          <span className="inline-flex items-center gap-1">
            <Wind className="size-3.5 text-success-text" aria-hidden="true" />
            {formatNumber(eco.co2PreventedKg, 1)} кг CO₂
          </span>
        </p>
      </div>
    </div>
  )
}
