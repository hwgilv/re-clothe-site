'use client'

import { useMemo, useState } from 'react'
import { Clock, Search } from 'lucide-react'

import { Input } from '@/components/ui/input'
import { CATEGORIES } from '@/lib/domain/catalog'
import type { CategoryId, Service } from '@/lib/domain/types'
import { formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'

interface ServicePickerProps {
  /** Услуги с учётом правок тарифов из «Настроек». */
  services: readonly Service[]
  value: string
  onChange: (serviceId: string) => void
  error?: string | undefined
}

/**
 * Выбор из 56 услуг тарифной сетки: 8 категорий + поиск по названию и номеру.
 * Выбор подставляет базовую стоимость и норму времени (они видны в карточке и в расчёте).
 */
export function ServicePicker({ services, value, onChange, error }: ServicePickerProps) {
  const selected = services.find((service) => service.id === value)
  const [category, setCategory] = useState<CategoryId>(selected?.categoryId ?? 'outerwear')
  const [query, setQuery] = useState('')

  const counts = useMemo(() => {
    const map = new Map<CategoryId, number>()
    for (const service of services) map.set(service.categoryId, (map.get(service.categoryId) ?? 0) + 1)
    return map
  }, [services])

  const text = query.trim().toLowerCase()
  const list = useMemo(
    () =>
      text
        ? services.filter(
            (service) =>
              service.name.toLowerCase().includes(text) ||
              service.id.includes(text) ||
              service.description.toLowerCase().includes(text),
          )
        : services.filter((service) => service.categoryId === category),
    [services, text, category],
  )

  return (
    <div className="space-y-3">
      <div className="relative">
        <label htmlFor="service-search" className="sr-only">
          Поиск услуги
        </label>
        <Search
          className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
          aria-hidden="true"
        />
        <Input
          id="service-search"
          type="search"
          placeholder="Поиск по всем 56 услугам: «куртка», «корсет», «1.2»…"
          className="pl-9"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
        />
      </div>

      {!text ? (
        <div role="tablist" aria-label="Категории услуг" className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1 scrollbar-thin">
          {CATEGORIES.map((item) => {
            const active = item.id === category
            return (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setCategory(item.id)}
                className={cn(
                  'inline-flex h-9 shrink-0 items-center gap-1.5 rounded-md border px-3 text-xs transition-colors',
                  active
                    ? 'border-primary bg-primary/10 text-primary-text'
                    : 'border-border text-muted-foreground hover:bg-muted hover:text-foreground',
                )}
              >
                {item.title}
                <span className="font-mono text-2xs opacity-70">{counts.get(item.id) ?? 0}</span>
              </button>
            )
          })}
        </div>
      ) : null}

      <ul
        role="radiogroup"
        aria-label="Услуги"
        aria-invalid={Boolean(error) || undefined}
        className="grid max-h-72 gap-1.5 overflow-y-auto pr-1 scrollbar-thin sm:grid-cols-2"
      >
        {list.length === 0 ? (
          <li className="col-span-full py-6 text-center text-sm text-muted-foreground">Ничего не найдено</li>
        ) : null}
        {list.map((service) => {
          const active = service.id === value
          return (
            <li key={service.id}>
              <button
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => onChange(service.id)}
                className={cn(
                  'flex h-full w-full flex-col gap-1 rounded-lg border p-2.5 text-left transition-colors',
                  active ? 'border-primary bg-primary/10' : 'border-border bg-background hover:bg-muted',
                )}
              >
                <span className="flex items-start justify-between gap-2">
                  <span className="text-sm font-medium leading-tight">
                    <span className="mr-1.5 font-mono text-2xs text-muted-foreground">{service.id}</span>
                    {service.name}
                  </span>
                  <span className="shrink-0 font-mono text-sm font-semibold tabular-nums">
                    {formatRub(service.clientPrice)}
                  </span>
                </span>
                <span className="flex items-center justify-between gap-2 font-mono text-2xs text-muted-foreground">
                  <span>ставка мастера {formatRub(service.masterRate)}</span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="size-3" aria-hidden="true" />
                    {service.hoursMin}–{service.hoursMax} ч
                  </span>
                </span>
              </button>
            </li>
          )
        })}
      </ul>

      {error ? (
        <p role="alert" className="text-xs text-destructive-text">
          {error}
        </p>
      ) : null}

      {selected ? (
        <div className="rounded-lg border border-border bg-background p-3 text-sm">
          <p className="font-medium">
            {selected.id} · {selected.name}
          </p>
          <p className="mt-0.5 text-xs text-muted-foreground">{selected.description}</p>
          <dl className="mt-2 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-md bg-surface p-2">
              <dt className="font-mono text-2xs uppercase tracking-wider text-muted-foreground">Цена клиента</dt>
              <dd className="font-mono text-sm font-semibold tabular-nums">{formatRub(selected.clientPrice)}</dd>
            </div>
            <div className="rounded-md bg-surface p-2">
              <dt className="font-mono text-2xs uppercase tracking-wider text-muted-foreground">Ставка мастера</dt>
              <dd className="font-mono text-sm font-semibold tabular-nums">{formatRub(selected.masterRate)}</dd>
            </div>
            <div className="rounded-md bg-surface p-2">
              <dt className="font-mono text-2xs uppercase tracking-wider text-muted-foreground">Норма времени</dt>
              <dd className="font-mono text-sm font-semibold tabular-nums">
                {selected.hoursMin}–{selected.hoursMax} ч
              </dd>
            </div>
          </dl>
        </div>
      ) : null}
    </div>
  )
}
