import type { BadgeProps } from '@/components/ui/badge'
import type { OrderStatus, PaymentStatus } from '@/lib/domain/orders'

type BadgeVariant = NonNullable<BadgeProps['variant']>

/** Цвет значка статуса оплаты: аванс — предупреждение, оплачен — изумруд. */
export const PAYMENT_BADGE: Record<PaymentStatus, BadgeVariant> = {
  unpaid: 'muted',
  advance: 'warning',
  paid: 'success',
}

/** Цвет значка статуса заказа: просрочка — приглушённый красный, готов — изумруд. */
export const ORDER_STATUS_BADGE: Record<OrderStatus, BadgeVariant> = {
  'in-progress': 'denim',
  ready: 'success',
  overdue: 'destructive',
  cancelled: 'muted',
}
