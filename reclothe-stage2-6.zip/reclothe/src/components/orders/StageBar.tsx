import { Progress } from '@/components/ui/progress'
import { STAGE_TEXT_CLASS, stageTone } from '@/components/orders/stage-ui'
import type { OrderView } from '@/lib/domain/derive'
import { cn } from '@/lib/utils'

/**
 * Живая полоса производства: «В процессе: [Этап 4. Раскрой] — 44%».
 * Процент — готовность всего заказа (завершённые этапы по весу + доля текущего).
 */
export function StageBar({ view, className }: { view: OrderView; className?: string }) {
  const { order, progress, stage } = view

  if (order.state === 'cancelled') {
    return (
      <div className={className}>
        <p className="text-xs text-destructive-text">Заказ отменён</p>
        <Progress value={0} tone="destructive" aria-label="Заказ отменён" className="mt-1.5" />
      </div>
    )
  }

  const done = order.completedAt !== null
  const tone = done ? 'success' : stageTone(order.stage)

  return (
    <div className={className}>
      <p className="flex flex-wrap items-center gap-x-1.5 gap-y-1 text-xs">
        {done ? (
          <span className={cn('font-medium', STAGE_TEXT_CLASS.success)}>Готово — 100%</span>
        ) : (
          <>
            <span className="text-muted-foreground">В процессе:</span>
            <span
              className={cn(
                'rounded-sm border px-1.5 py-0.5 font-mono font-medium',
                tone === 'denim'
                  ? 'border-denim/50 bg-denim/15'
                  : tone === 'success'
                    ? 'border-success/40 bg-success/10'
                    : 'border-primary/40 bg-primary/10',
                STAGE_TEXT_CLASS[tone],
              )}
            >
              Этап {stage.n}. {stage.title}
            </span>
            <span className="font-mono font-semibold text-foreground">— {progress}%</span>
          </>
        )}
      </p>
      <Progress
        value={progress}
        tone={tone}
        aria-label={`Готовность заказа ${order.number}: ${progress}%`}
        className="mt-1.5"
      />
    </div>
  )
}
