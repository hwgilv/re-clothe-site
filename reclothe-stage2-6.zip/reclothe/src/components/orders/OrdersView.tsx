'use client'

import { useMemo, useState } from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { Inbox, Plus, Search } from 'lucide-react'

import { PageHeader } from '@/components/common/PageHeader'
import { LeadCard } from '@/components/orders/LeadCard'
import { ORDER_STATUS_BADGE, PAYMENT_BADGE } from '@/components/orders/order-ui'
import { StageBar } from '@/components/orders/StageBar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { DataTable, type Column } from '@/components/ui/data-table'
import { EmptyState } from '@/components/ui/empty-state'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Select } from '@/components/ui/select'
import { Tabs } from '@/components/ui/tabs'
import type { OrderView } from '@/lib/domain/derive'
import { ORDER_STATUS_LABELS, PAYMENT_STATUS_LABELS, type OrderStatus, type PaymentStatus } from '@/lib/domain/orders'
import { formatDateString } from '@/lib/date'
import { formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'
import { useApp } from '@/store/AppProvider'
import { useUI } from '@/store/ui'

type TabId = 'orders' | 'leads'
type LeadFilter = 'open' | 'all'

export function DeadlineCell({ view }: { view: OrderView }) {
  const done = view.order.completedAt !== null || view.order.state === 'cancelled'
  const tone =
    done ? 'text-muted-foreground' : view.daysLeft < 0 ? 'text-destructive-text' : view.daysLeft <= 3 ? 'text-warning-text' : ''
  return (
    <span className={cn('whitespace-nowrap font-mono text-xs tabular-nums', tone)}>
      {formatDateString(view.order.deadline)}
      {!done && view.daysLeft < 0 ? <span className="block text-2xs">просрочка {-view.daysLeft} дн.</span> : null}
      {!done && view.daysLeft >= 0 && view.daysLeft <= 3 ? (
        <span className="block text-2xs">{view.daysLeft === 0 ? 'сегодня' : `через ${view.daysLeft} дн.`}</span>
      ) : null}
    </span>
  )
}

export function OrdersView() {
  const { derived, now } = useApp()
  const { openOrderModal } = useUI()
  const router = useRouter()
  const params = useSearchParams()

  const [tab, setTab] = useState<TabId>(params.get('tab') === 'leads' ? 'leads' : 'orders')
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState<OrderStatus | 'all'>('all')
  const [masterId, setMasterId] = useState('all')
  const [payment, setPayment] = useState<PaymentStatus | 'all'>('all')
  const [leadFilter, setLeadFilter] = useState<LeadFilter>('open')

  const rows = useMemo(() => {
    const text = query.trim().toLowerCase()
    return derived.orders.filter((view) => {
      if (status !== 'all' && view.status !== status) return false
      if (masterId !== 'all' && view.order.masterId !== masterId) return false
      if (payment !== 'all' && view.paymentStatus !== payment) return false
      if (!text) return true
      return (
        view.order.number.toLowerCase().includes(text) ||
        view.clientName.toLowerCase().includes(text) ||
        view.service.name.toLowerCase().includes(text) ||
        (view.client?.phone ?? '').includes(text)
      )
    })
  }, [derived.orders, query, status, masterId, payment])

  const leads = useMemo(
    () =>
      derived.leads.filter((item) =>
        leadFilter === 'all' ? true : item.lead.status === 'new' || item.lead.status === 'contacted',
      ),
    [derived.leads, leadFilter],
  )

  const active = derived.orders.filter((view) => view.order.state === 'active' && view.order.completedAt === null).length
  const total = rows.reduce((sum, view) => (view.order.state === 'cancelled' ? sum : sum + view.pricing.clientTotal), 0)

  const columns: Column<OrderView>[] = [
    {
      key: 'order',
      header: 'Заказ',
      mobileTitle: true,
      cell: (view) => (
        <div className="min-w-0">
          <Link
            href={`/orders/${view.order.id}`}
            onClick={(event) => event.stopPropagation()}
            className="font-mono text-sm font-semibold hover:text-primary-text hover:underline"
          >
            {view.order.number}
          </Link>
          <p className="max-w-[16rem] truncate text-xs text-muted-foreground">{view.service.name}</p>
        </div>
      ),
    },
    { key: 'client', header: 'Клиент', cell: (view) => <span className="line-clamp-2">{view.clientName}</span> },
    {
      key: 'master',
      header: 'Мастер',
      cell: (view) => <span className="whitespace-nowrap text-xs">{view.master?.name ?? '—'}</span>,
    },
    { key: 'deadline', header: 'Срок', cell: (view) => <DeadlineCell view={view} /> },
    {
      key: 'stage',
      header: 'Этап',
      className: 'min-w-[15rem]',
      cell: (view) => <StageBar view={view} />,
    },
    {
      key: 'sum',
      header: 'Стоимость',
      align: 'right',
      cell: (view) => (
        <span className="whitespace-nowrap font-mono text-sm font-semibold tabular-nums">{formatRub(view.pricing.clientTotal)}</span>
      ),
    },
    {
      key: 'pay',
      header: 'Оплата',
      className: 'min-w-[8rem]',
      cell: (view) => (
        <div className="space-y-1">
          <Badge variant={view.order.state === 'cancelled' ? 'muted' : PAYMENT_BADGE[view.paymentStatus]}>
            {view.order.state === 'cancelled' ? 'Возврат' : PAYMENT_STATUS_LABELS[view.paymentStatus]}
          </Badge>
          {view.order.state === 'active' ? (
            <Progress value={view.paidPercent} tone="success" aria-label={`Оплачено ${view.paidPercent}%`} />
          ) : null}
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Статус',
      cell: (view) => <Badge variant={ORDER_STATUS_BADGE[view.status]}>{ORDER_STATUS_LABELS[view.status]}</Badge>,
    },
  ]

  return (
    <div>
      <PageHeader
        title="Заказы"
        description="Все заказы студии и новые заявки с сайта — всё считается из единого состояния."
        actions={
          <Button onClick={() => openOrderModal()}>
            <Plus aria-hidden="true" />
            Новый заказ
          </Button>
        }
      />

      <Tabs<TabId>
        aria-label="Раздел заказов"
        value={tab}
        onChange={(next) => {
          setTab(next)
          router.replace(next === 'leads' ? '/orders?tab=leads' : '/orders', { scroll: false })
        }}
        className="mb-4"
        tabs={[
          { value: 'orders', label: 'Заказы', count: active },
          { value: 'leads', label: 'Новые лиды', count: derived.newLeads.length },
        ]}
      />

      {tab === 'orders' ? (
        <div className="space-y-4">
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-[1fr_11rem_13rem_12rem]">
            <div className="relative sm:col-span-2 lg:col-span-1">
              <label htmlFor="orders-search" className="sr-only">
                Поиск заказов
              </label>
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
              <Input
                id="orders-search"
                type="search"
                placeholder="Номер, клиент, услуга, телефон…"
                className="pl-9"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
            </div>
            <Select aria-label="Статус" value={status} onChange={(event) => setStatus(event.target.value as OrderStatus | 'all')}>
              <option value="all">Все статусы</option>
              {(Object.keys(ORDER_STATUS_LABELS) as OrderStatus[]).map((key) => (
                <option key={key} value={key}>
                  {ORDER_STATUS_LABELS[key]}
                </option>
              ))}
            </Select>
            <Select aria-label="Мастер" value={masterId} onChange={(event) => setMasterId(event.target.value)}>
              <option value="all">Все мастера</option>
              {derived.masters.map((item) => (
                <option key={item.master.id} value={item.master.id}>
                  {item.master.name}
                </option>
              ))}
            </Select>
            <Select aria-label="Оплата" value={payment} onChange={(event) => setPayment(event.target.value as PaymentStatus | 'all')}>
              <option value="all">Любая оплата</option>
              {(Object.keys(PAYMENT_STATUS_LABELS) as PaymentStatus[]).map((key) => (
                <option key={key} value={key}>
                  {PAYMENT_STATUS_LABELS[key]}
                </option>
              ))}
            </Select>
          </div>

          <p className="font-mono text-xs text-muted-foreground">
            Показано: {rows.length} из {derived.orders.length} · на сумму{' '}
            <span className="font-semibold text-foreground">{formatRub(total)}</span>
          </p>

          <DataTable
            caption="Заказы студии"
            columns={columns}
            rows={rows}
            rowKey={(view) => view.order.id}
            onRowClick={(view) => router.push(`/orders/${view.order.id}`)}
            rowClassName={(view) => (view.order.state === 'cancelled' ? 'opacity-60' : undefined)}
            empty={
              <EmptyState
                icon={<Inbox className="size-6" aria-hidden="true" />}
                title="Заказов не найдено"
                description="Измените фильтры или создайте первый заказ."
                action={<Button onClick={() => openOrderModal()}>Новый заказ</Button>}
              />
            }
            mobileCard={(view) => (
              <div className="space-y-2.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-mono text-sm font-semibold">{view.order.number}</p>
                    <p className="text-sm">{view.service.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {view.clientName} · {view.master?.name ?? '—'}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="font-mono text-sm font-semibold tabular-nums">{formatRub(view.pricing.clientTotal)}</p>
                    <Badge className="mt-1" variant={ORDER_STATUS_BADGE[view.status]}>
                      {ORDER_STATUS_LABELS[view.status]}
                    </Badge>
                  </div>
                </div>
                <StageBar view={view} />
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="text-muted-foreground">Срок</span>
                  <DeadlineCell view={view} />
                </div>
                <div className="flex items-center justify-between gap-2 text-xs">
                  <Badge variant={view.order.state === 'cancelled' ? 'muted' : PAYMENT_BADGE[view.paymentStatus]}>
                    {view.order.state === 'cancelled' ? 'Возврат' : PAYMENT_STATUS_LABELS[view.paymentStatus]}
                  </Badge>
                  {view.order.state === 'active' ? (
                    <span className="font-mono text-muted-foreground">остаток {formatRub(view.remaining)}</span>
                  ) : null}
                </div>
              </div>
            )}
          />
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-sm text-muted-foreground">
              Клиенты, которые оставили данные на сайте. Свяжитесь, согласуйте консультацию и оформите заказ.
            </p>
            <Tabs<LeadFilter>
              aria-label="Фильтр заявок"
              value={leadFilter}
              onChange={setLeadFilter}
              tabs={[
                { value: 'open', label: 'Активные' },
                { value: 'all', label: 'Все' },
              ]}
            />
          </div>
          {leads.length === 0 ? (
            <EmptyState
              icon={<Inbox className="size-6" aria-hidden="true" />}
              title="Новых заявок нет"
              description="Когда клиент зарегистрируется на сайте, его заявка появится здесь."
            />
          ) : (
            <div className="grid gap-4 xl:grid-cols-2">
              {leads.map((item) => (
                <LeadCard key={item.lead.id} item={item} now={now} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
