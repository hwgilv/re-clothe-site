'use client'

import { OrderForm } from '@/components/orders/OrderForm'
import { useUI } from '@/store/ui'

/** Глобальное окно «+ Новый заказ» / «Изменить заказ». Открывается из любого места через useUI(). */
export function OrderModal() {
  const { orderModal, closeOrderModal } = useUI()
  if (!orderModal) return null
  return (
    <OrderForm
      key={`${orderModal.editOrderId ?? 'new'}:${orderModal.clientId ?? ''}:${orderModal.leadId ?? ''}`}
      request={orderModal}
      onClose={closeOrderModal}
    />
  )
}
