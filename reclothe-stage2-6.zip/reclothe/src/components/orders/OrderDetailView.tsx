'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, ArrowRight, Ban, FileText, Pencil, RotateCcw, Trash2, Wallet } from 'lucide-react'

import { PageHeader } from '@/components/common/PageHeader'
import { AdjustmentsPanel } from '@/components/orders/AdjustmentsPanel'
import { ORDER_STATUS_BADGE, PAYMENT_BADGE } from '@/components/orders/order-ui'
import { StageBar } from '@/components/orders/StageBar'
import { StageTrack } from '@/components/orders/StageTrack'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { EmptyState } from '@/components/ui/empty-state'
import { Input } from '@/components/ui/input'
import { Modal } from '@/components/ui/modal'
import { Progress } from '@/components/ui/progress'
import { useToast } from '@/components/ui/toast'
import { FINAL_STAGE, getStockItem } from '@/lib/domain/catalog'
import { ORDER_STATUS_LABELS, PAYMENT_STATUS_LABELS } from '@/lib/domain/orders'
import { NPD_RATES } from '@/lib/domain/npd'
import { formatDateString } from '@/lib/date'
import { formatIsoDate, formatIsoDateTime, formatNumber, formatRub, pluralDays } from '@/lib/format'
import { useActions, useDerived } from '@/store/AppProvider'
import { useUI } from '@/store/ui'
import { cn } from '@/lib/utils'

function Row({ label, value, tone }: { label: string; value: React.ReactNode; tone?: 'success' | 'destructive' }) {
  return (
    <div className="flex items-baseline justify-between gap-3 py-1 text-sm">
      <dt className="text-muted-foreground">{label}</dt>
      <dd
        className={cn(
          'text-right font-mono tabular-nums',
          tone === 'success' && 'text-success-text',
          tone === 'destructive' && 'text-destructive-text',
        )}
      >
        {value}
      </dd>
    </div>
  )
}

export function OrderDetailView({ orderKey }: { orderKey: string }) {
  const derived = useDerived()
  const actions = useActions()
  const toast = useToast()
  const { openOrderModal } = useUI()
  const [payment, setPayment] = useState('')
  const [confirmCancel, setConfirmCancel] = useState(false)

  const view =
    derived.orderById.get(orderKey) ?? derived.orders.find((item) => item.order.number === decodeURIComponent(orderKey))

  if (!view) {
    return (
      <EmptyState
        title="Заказ не найден"
        description="Возможно, данные были сброшены или ссылка устарела."
        action={
          <Button asChild>
            <Link href="/orders">К списку заказов</Link>
          </Button>
        }
      />
    )
  }

  const { order } = view
  const cancelled = order.state === 'cancelled'
  const tax = Math.round(view.pricing.clientTotal * NPD_RATES.individual)
  const consumptionRows = Object.entries(view.consumption)
    .map(([itemId, qty]) => ({ info: getStockItem(itemId), qty }))
    .filter((row): row is { info: NonNullable<typeof row.info>; qty: number } => row.info !== undefined)

  const goToStage = (stage: number): void => {
    if (cancelled) return
    actions.setStage(order.id, stage, 0)
    if (stage === FINAL_STAGE) {
      toast({
        title: `${order.number}: заказ готов`,
        description: `ЗП мастера ${formatRub(view.payroll.total)} добавлена к выплате в «Бухгалтерии».`,
      })
    }
  }

  const pay = (amount: number): void => {
    if (!Number.isFinite(amount) || amount <= 0) return
    const wasFirst = order.payments.length === 0
    actions.addPayment(order.id, amount)
    setPayment('')
    toast({
      title: wasFirst ? 'Аванс проведён' : 'Платёж принят',
      description: `${formatRub(amount)} · ${order.number}. Выручка и карта клиента пересчитаны.`,
    })
  }

  return (
    <div>
      <div className="mb-3">
        <Button asChild variant="ghost" size="sm" className="-ml-2">
          <Link href="/orders">
            <ArrowLeft aria-hidden="true" />
            Все заказы
          </Link>
        </Button>
      </div>

      <PageHeader
        eyebrow={`Создан ${formatIsoDate(order.createdAt)}`}
        title={`${order.number} · ${view.service.name}`}
        description={`${view.clientName}${view.master ? ` · мастер ${view.master.name}` : ''}`}
        actions={
          <>
            <Badge variant={ORDER_STATUS_BADGE[view.status]}>{ORDER_STATUS_LABELS[view.status]}</Badge>
            <Button variant="outline" size="sm" disabled={view.payrollLocked || cancelled} onClick={() => openOrderModal({ editOrderId: order.id })}>
              <Pencil aria-hidden="true" />
              Изменить
            </Button>
            <Button asChild variant="outline" size="sm">
              <Link href={`/documents?order=${order.id}`}>
                <FileText aria-hidden="true" />
                Документы
              </Link>
            </Button>
            {cancelled ? (
              <Button variant="outline" size="sm" onClick={() => actions.restoreOrder(order.id)}>
                <RotateCcw aria-hidden="true" />
                Восстановить
              </Button>
            ) : (
              <Button variant="outline" size="sm" disabled={view.payrollLocked} onClick={() => setConfirmCancel(true)}>
                <Ban aria-hidden="true" />
                Отменить
              </Button>
            )}
          </>
        }
      />

      {cancelled ? (
        <p role="status" className="mb-4 rounded-lg border border-destructive/50 bg-destructive/10 p-3 text-sm">
          Заказ отменён: оплаты считаются возвращёнными клиенту, расходники вернулись на склад, ЗП не начисляется.
        </p>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_22rem]">
        <div className="min-w-0 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Производство</CardTitle>
              <span className="font-mono text-2xl font-bold tabular-nums" data-testid="order-progress">
                {view.progress}%
              </span>
            </CardHeader>
            <CardContent className="space-y-4">
              <StageBar view={view} />
              <StageTrack view={view} onSelect={goToStage} disabled={cancelled} />

              {!cancelled && order.completedAt === null ? (
                <div className="rounded-lg border border-border bg-background p-3">
                  <label htmlFor="stage-progress" className="flex items-baseline justify-between gap-2 text-sm">
                    <span>
                      Прогресс внутри этапа «{view.stage.title}»
                    </span>
                    <span className="font-mono tabular-nums">{order.stageProgress}%</span>
                  </label>
                  <input
                    id="stage-progress"
                    type="range"
                    min={0}
                    max={100}
                    step={5}
                    value={order.stageProgress}
                    onChange={(event) => actions.setStageProgress(order.id, Number(event.target.value))}
                    className="mt-2 h-8 w-full cursor-pointer accent-primary"
                  />
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Button variant="outline" size="sm" disabled={order.stage <= 1 || view.payrollLocked} onClick={() => goToStage(order.stage - 1)}>
                      <ArrowLeft aria-hidden="true" />
                      Предыдущий этап
                    </Button>
                    <Button size="sm" onClick={() => goToStage(order.stage + 1)}>
                      {order.stage + 1 === FINAL_STAGE ? 'Заказ готов' : 'Следующий этап'}
                      <ArrowRight aria-hidden="true" />
                    </Button>
                  </div>
                </div>
              ) : null}

              {order.completedAt !== null ? (
                <p className="text-xs text-muted-foreground">
                  Завершён {formatIsoDateTime(order.completedAt)}.{' '}
                  {view.payrollLocked ? 'ЗП выплачена.' : 'ЗП мастера ожидает выплаты в «Бухгалтерии».'}
                </p>
              ) : null}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Премии и штрафы мастера</CardTitle>
            </CardHeader>
            <CardContent>
              <AdjustmentsPanel view={view} />
            </CardContent>
          </Card>
        </div>

        <div className="min-w-0 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Оплата</CardTitle>
              <Badge variant={cancelled ? 'muted' : PAYMENT_BADGE[view.paymentStatus]}>
                {cancelled ? 'Возврат' : PAYMENT_STATUS_LABELS[view.paymentStatus]}
              </Badge>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="font-mono text-2xl font-bold tabular-nums">{formatRub(view.pricing.clientTotal)}</p>
                <Progress value={view.paidPercent} tone="success" size="lg" aria-label={`Оплачено ${view.paidPercent}%`} className="mt-2" />
                <p className="mt-1.5 flex justify-between gap-2 text-xs">
                  <span className="text-muted-foreground">Оплачено: {formatRub(view.paid)}</span>
                  <span className="font-medium" data-testid="remaining">
                    Остаток к оплате: {formatNumber(view.remaining)} руб.
                  </span>
                </p>
              </div>

              {!cancelled ? (
                <form
                  className="space-y-2"
                  onSubmit={(event) => {
                    event.preventDefault()
                    pay(Number.parseInt(payment.replace(/\D/g, ''), 10))
                  }}
                >
                  <label htmlFor="payment-amount" className="block font-mono text-xs uppercase tracking-wider text-muted-foreground">
                    {order.payments.length === 0 ? 'Провести аванс, ₽' : 'Принять платёж, ₽'}
                  </label>
                  <div className="flex gap-2">
                    <Input
                      id="payment-amount"
                      inputMode="numeric"
                      placeholder="0"
                      value={payment}
                      onChange={(event) => setPayment(event.target.value.replace(/[^\d]/g, ''))}
                    />
                    <Button type="submit" variant="success" disabled={!payment}>
                      <Wallet aria-hidden="true" />
                      Принять
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {[30, 50].map((percent) => (
                      <Button
                        key={percent}
                        variant="outline"
                        size="sm"
                        onClick={() => setPayment(String(Math.round((view.pricing.clientTotal * percent) / 100)))}
                      >
                        {percent}% от суммы
                      </Button>
                    ))}
                    <Button variant="outline" size="sm" disabled={view.remaining <= 0} onClick={() => pay(view.remaining)}>
                      Оплатить остаток
                    </Button>
                  </div>
                </form>
              ) : null}

              {order.payments.length > 0 ? (
                <ul className="divide-y divide-border rounded-lg border border-border">
                  {order.payments.map((item) => (
                    <li key={item.id} className="flex items-center justify-between gap-2 px-3 py-2 text-sm">
                      <span className="min-w-0">
                        <span className="block">{item.kind === 'advance' ? 'Аванс' : 'Оплата'}</span>
                        <span className="block text-xs text-muted-foreground">{formatIsoDateTime(item.at)}</span>
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="font-mono tabular-nums text-success-text">+{formatRub(item.amount)}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          aria-label="Удалить платёж"
                          onClick={() => actions.removePayment(order.id, item.id)}
                        >
                          <Trash2 aria-hidden="true" />
                        </Button>
                      </span>
                    </li>
                  ))}
                </ul>
              ) : null}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Экономика заказа</CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="divide-y divide-border/60">
                <Row label="Цена клиента" value={formatRub(view.pricing.clientTotal)} />
                <Row label="ЗП мастера (база)" value={`− ${formatRub(view.payroll.base)}`} />
                <Row label="Премии" value={`− ${formatRub(view.payroll.bonusTotal)}`} />
                <Row label="Штрафы (удержано)" value={`+ ${formatRub(view.payroll.penaltyTotal)}`} tone="success" />
                <Row label="Материалы" value={`− ${formatRub(view.materialsCost)}`} />
                <Row label={`Налог НПД ${Math.round(NPD_RATES.individual * 100)}%`} value={`− ${formatRub(tax)}`} />
                <Row
                  label="Ожидаемая прибыль"
                  value={<strong data-testid="expected-profit">{formatRub(view.expectedProfit)}</strong>}
                  tone={view.expectedProfit >= 0 ? 'success' : 'destructive'}
                />
              </dl>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Детали</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <dl className="divide-y divide-border/60">
                <Row label="Срок" value={formatDateString(order.deadline)} />
                {order.apsShiftDays > 0 ? (
                  <Row label="Сдвиг APS" value={`+${pluralDays(order.apsShiftDays)}`} tone="destructive" />
                ) : null}
                <Row
                  label="Клиент"
                  value={
                    <Link href={`/clients?client=${order.clientId}`} className="hover:text-primary-text hover:underline">
                      {view.clientName}
                    </Link>
                  }
                />
                <Row label="Мастер" value={view.master?.name ?? '—'} />
                <Row label="Вес доноров" value={`${formatNumber(view.weightKg, 2)} кг`} />
              </dl>

              {order.donors.length > 0 ? (
                <div>
                  <p className="mb-1.5 font-mono text-2xs uppercase tracking-widest text-muted-foreground">Вещи-доноры</p>
                  <ul className="space-y-1">
                    {order.donors.map((donor) => (
                      <li key={donor.id} className="flex items-center justify-between gap-2 rounded-md bg-background px-2.5 py-1.5 text-xs">
                        <span className="min-w-0 truncate">{donor.title}</span>
                        <span className="shrink-0 font-mono text-muted-foreground">
                          {donor.code} · {donor.weightKg} кг
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}

              {consumptionRows.length > 0 ? (
                <div>
                  <p className="mb-1.5 font-mono text-2xs uppercase tracking-widest text-muted-foreground">Расход материалов</p>
                  <ul className="space-y-1">
                    {consumptionRows.map((row) => (
                      <li key={row.info.id} className="flex justify-between gap-2 text-xs">
                        <span className="text-muted-foreground">{row.info.name}</span>
                        <span className="font-mono">
                          {formatNumber(row.qty, 1)} {row.info.unit}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}

              {order.comment ? (
                <div>
                  <p className="mb-1 font-mono text-2xs uppercase tracking-widest text-muted-foreground">Комментарий заказчика</p>
                  <p className="rounded-md bg-background p-2.5 text-xs">{order.comment}</p>
                </div>
              ) : null}
            </CardContent>
          </Card>
        </div>
      </div>

      <Modal
        open={confirmCancel}
        onOpenChange={setConfirmCancel}
        size="sm"
        title={`Отменить заказ ${order.number}?`}
        description="Оплаты будут считаться возвращёнными, материалы вернутся на склад, ЗП начисляться не будет."
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirmCancel(false)}>
              Не отменять
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                actions.cancelOrder(order.id)
                setConfirmCancel(false)
                toast({ title: `${order.number} отменён`, tone: 'info' })
              }}
            >
              Отменить заказ
            </Button>
          </>
        }
      >
        <p className="text-sm text-muted-foreground">Заказ можно будет восстановить из этой же карточки.</p>
      </Modal>
    </div>
  )
}
