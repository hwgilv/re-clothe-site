'use client'

import { Suspense, useMemo, useState } from 'react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { ArrowDownToLine, ArrowUpFromLine, Droplets, Leaf, Search } from 'lucide-react'

import { PageHeader } from '@/components/common/PageHeader'
import { PageSkeleton } from '@/components/common/PageSkeleton'
import { StatTile } from '@/components/finance/StatTile'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { DataTable, type Column } from '@/components/ui/data-table'
import { EmptyState } from '@/components/ui/empty-state'
import { Field } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Modal } from '@/components/ui/modal'
import { Progress } from '@/components/ui/progress'
import { Tabs } from '@/components/ui/tabs'
import { useToast } from '@/components/ui/toast'
import { ORDER_STATUS_BADGE } from '@/components/orders/order-ui'
import { MATERIALS, STOCK_ITEMS, getStockItem } from '@/lib/domain/catalog'
import { calcEcoMetrics } from '@/lib/domain/eco'
import type { OrderView, StockView } from '@/lib/domain/derive'
import type { OrderDonor } from '@/lib/domain/types'
import { formatIsoDate, formatNumber, formatRub } from '@/lib/format'
import { useActions, useApp } from '@/store/AppProvider'

type TabId = 'donors' | 'materials'

interface DonorRow {
  donor: OrderDonor
  view: OrderView
}

const STOCK_STATUS = {
  ok: { label: 'В наличии', variant: 'success' },
  low: { label: 'Заканчивается', variant: 'warning' },
  out: { label: 'Нет', variant: 'destructive' },
} as const

type MovementMode = 'receive' | 'writeoff'

function MovementModal({
  itemId,
  mode,
  onClose,
}: {
  itemId: string | null
  mode: MovementMode
  onClose: () => void
}) {
  const actions = useActions()
  const toast = useToast()
  const item = itemId ? getStockItem(itemId) : undefined
  const [qty, setQty] = useState('')
  const [cost, setCost] = useState('')
  const [note, setNote] = useState('')
  const [error, setError] = useState<string | null>(null)

  const submit = (event: React.FormEvent): void => {
    event.preventDefault()
    if (!item) return
    const amount = Number.parseFloat(qty.replace(',', '.'))
    if (!Number.isFinite(amount) || amount <= 0) {
      setError('Введите количество больше нуля')
      return
    }
    if (mode === 'receive') {
      const total = Number.parseInt(cost.replace(/\D/g, ''), 10)
      actions.receiveStock({ itemId: item.id, qty: amount, cost: Number.isFinite(total) ? total : Math.round(amount * item.unitCost), note })
    } else {
      actions.writeOffStock({ itemId: item.id, qty: amount, note })
    }
    toast({
      title: mode === 'receive' ? 'Приход оформлен' : 'Списание проведено',
      description: `${item.name}: ${mode === 'receive' ? '+' : '−'}${formatNumber(amount, 2)} ${item.unit}. Остаток пересчитан.`,
    })
    setQty('')
    setCost('')
    setNote('')
    setError(null)
    onClose()
  }

  return (
    <Modal
      open={item !== undefined}
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      size="sm"
      title={item ? `${mode === 'receive' ? 'Приход' : 'Списание'}: ${item.name}` : 'Движение'}
      description={mode === 'receive' ? 'Закупка попадёт в расходы и уменьшит прибыль.' : 'Брак, потери, использование вне заказов.'}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Отмена
          </Button>
          <Button type="submit" form="movement-form" variant={mode === 'receive' ? 'success' : 'destructive'}>
            {mode === 'receive' ? 'Оформить приход' : 'Списать'}
          </Button>
        </>
      }
    >
      <form id="movement-form" onSubmit={submit} noValidate className="space-y-3">
        <Field label={`Количество, ${item?.unit ?? ''}`} htmlFor="mv-qty" error={error ?? undefined}>
          <Input
            id="mv-qty"
            inputMode="decimal"
            value={qty}
            onChange={(event) => {
              setQty(event.target.value)
              setError(null)
            }}
            aria-invalid={Boolean(error) || undefined}
            aria-describedby={error ? 'mv-qty-error' : undefined}
            autoFocus
          />
        </Field>
        {mode === 'receive' ? (
          <Field
            label="Стоимость закупки, ₽"
            htmlFor="mv-cost"
            hint={item ? `Если оставить пустым — по справочной цене ${formatRub(item.unitCost)} за ${item.unit}` : undefined}
          >
            <Input id="mv-cost" inputMode="numeric" value={cost} onChange={(event) => setCost(event.target.value.replace(/[^\d]/g, ''))} />
          </Field>
        ) : null}
        <Field label="Комментарий" htmlFor="mv-note">
          <Input id="mv-note" value={note} onChange={(event) => setNote(event.target.value)} />
        </Field>
      </form>
    </Modal>
  )
}

function InventoryInner() {
  const { state, derived } = useApp()
  const params = useSearchParams()
  const [tab, setTab] = useState<TabId>(params.get('tab') === 'materials' ? 'materials' : 'donors')
  const [query, setQuery] = useState('')
  const [movement, setMovement] = useState<{ itemId: string; mode: MovementMode } | null>(null)

  const donorRows = useMemo<DonorRow[]>(
    () =>
      derived.orders
        .filter((view) => view.order.state === 'active')
        .flatMap((view) => view.order.donors.map((donor) => ({ donor, view }))),
    [derived.orders],
  )
  const donors = useMemo(() => {
    const text = query.trim().toLowerCase()
    return donorRows.filter(
      (row) =>
        !text ||
        row.donor.title.toLowerCase().includes(text) ||
        row.donor.code.toLowerCase().includes(text) ||
        row.view.order.number.toLowerCase().includes(text) ||
        row.view.clientName.toLowerCase().includes(text),
    )
  }, [donorRows, query])

  const totalKg = donorRows.reduce((sum, row) => sum + row.donor.weightKg, 0)
  const eco = calcEcoMetrics(Math.round(totalKg * 1000) / 1000)
  const inWork = donorRows.filter((row) => row.view.order.completedAt === null).length

  const stock = useMemo(() => {
    const text = query.trim().toLowerCase()
    return derived.stock.filter((item) => !text || item.info.name.toLowerCase().includes(text))
  }, [derived.stock, query])
  const lowCount = derived.stock.filter((item) => item.balance.status !== 'ok').length

  const donorColumns: Column<DonorRow>[] = [
    { key: 'code', header: 'Код', mobileTitle: true, cell: (row) => <span className="font-mono font-semibold">{row.donor.code}</span> },
    {
      key: 'title',
      header: 'Вещь',
      cell: (row) => (
        <div className="min-w-0">
          <p>{row.donor.title}</p>
          {row.donor.note ? <p className="text-xs text-muted-foreground">{row.donor.note}</p> : null}
        </div>
      ),
    },
    {
      key: 'material',
      header: 'Материал',
      cell: (row) => <span className="text-xs">{MATERIALS.find((item) => item.id === row.donor.materialId)?.label ?? row.donor.materialId}</span>,
    },
    { key: 'weight', header: 'Вес', align: 'right', cell: (row) => <span className="font-mono tabular-nums">{formatNumber(row.donor.weightKg, 2)} кг</span> },
    {
      key: 'order',
      header: 'Заказ',
      cell: (row) => (
        <Link href={`/orders/${row.view.order.id}`} className="font-mono text-xs hover:text-primary-text hover:underline">
          {row.view.order.number}
        </Link>
      ),
    },
    { key: 'client', header: 'Клиент', cell: (row) => <span className="text-xs">{row.view.clientName}</span> },
    {
      key: 'status',
      header: 'Статус',
      cell: (row) => (
        <Badge variant={ORDER_STATUS_BADGE[row.view.status]}>
          {row.view.order.completedAt !== null ? 'Переработан' : row.view.status === 'overdue' ? 'В работе · срок' : 'В работе'}
        </Badge>
      ),
    },
  ]

  const stockColumns: Column<StockView>[] = [
    {
      key: 'name',
      header: 'Позиция',
      mobileTitle: true,
      cell: (item) => (
        <div className="min-w-0">
          <p className="font-medium">{item.info.name}</p>
          <p className="text-xs text-muted-foreground">{item.info.group}</p>
        </div>
      ),
    },
    {
      key: 'balance',
      header: 'Остаток',
      className: 'min-w-[10rem]',
      cell: (item) => {
        const target = Math.max(item.info.min * 2, item.balance.balance, 1)
        return (
          <div>
            <p className="font-mono text-sm font-semibold tabular-nums" data-testid={`stock-${item.info.id}`}>
              {formatNumber(item.balance.balance, 1)} {item.info.unit}
            </p>
            <Progress
              value={Math.max(0, item.balance.balance)}
              max={target}
              tone={item.balance.status === 'ok' ? 'success' : item.balance.status === 'low' ? 'warning' : 'destructive'}
              aria-label={`Остаток: ${item.info.name}`}
              className="mt-1"
            />
          </div>
        )
      },
    },
    { key: 'min', header: 'Минимум', align: 'right', cell: (item) => <span className="font-mono text-xs tabular-nums">{item.info.min} {item.info.unit}</span> },
    {
      key: 'flow',
      header: 'Приход / расход',
      align: 'right',
      cell: (item) => (
        <span className="font-mono text-xs tabular-nums">
          <span className="text-success-text">+{formatNumber(item.balance.received, 1)}</span>{' '}
          <span className="text-destructive-text">−{formatNumber(item.balance.consumed + item.balance.writtenOff, 1)}</span>
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Статус',
      cell: (item) => <Badge variant={STOCK_STATUS[item.balance.status].variant}>{STOCK_STATUS[item.balance.status].label}</Badge>,
    },
    {
      key: 'actions',
      header: '',
      align: 'right',
      cell: (item) => (
        <div className="flex justify-end gap-1.5">
          <Button size="sm" variant="success" onClick={() => setMovement({ itemId: item.info.id, mode: 'receive' })}>
            <ArrowDownToLine aria-hidden="true" />
            Приход
          </Button>
          <Button size="sm" variant="outline" onClick={() => setMovement({ itemId: item.info.id, mode: 'writeoff' })}>
            <ArrowUpFromLine aria-hidden="true" />
            Списать
          </Button>
        </div>
      ),
    },
  ]

  const movements = [...state.stockMovements].sort((a, b) => (a.at < b.at ? 1 : -1)).slice(0, 12)

  return (
    <div>
      <PageHeader
        title="Склад"
        description="Вещи-доноры из заказов и расходные материалы. Остатки сами уменьшаются при создании заказа и возвращаются при его отмене."
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="Вещей-доноров на складе" value={formatNumber(donorRows.length)} hint={`в работе: ${inWork}`} />
        <StatTile label="Вес текстиля" value={`${formatNumber(totalKg, 1)} кг`} hint="спасено от свалки" />
        <StatTile
          label="Вода сэкономлена"
          value={`${formatNumber(eco.waterSavedLiters)} л`}
          hint={`CO₂ не выброшено: ${formatNumber(eco.co2PreventedKg, 1)} кг`}
        />
        <StatTile
          label="Расходники: нужно докупить"
          value={String(lowCount)}
          hint={lowCount > 0 ? 'позиции ниже минимума' : 'всё в достатке'}
        />
      </div>

      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <Tabs<TabId>
          aria-label="Раздел склада"
          value={tab}
          onChange={setTab}
          tabs={[
            { value: 'donors', label: 'Вещи-доноры', count: donorRows.length },
            { value: 'materials', label: 'Расходники', count: lowCount },
          ]}
        />
        <div className="relative w-full sm:w-64">
          <label htmlFor="inv-search" className="sr-only">
            Поиск по складу
          </label>
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <Input id="inv-search" type="search" placeholder="Поиск…" className="pl-9" value={query} onChange={(event) => setQuery(event.target.value)} />
        </div>
      </div>

      {tab === 'donors' ? (
        <DataTable
          caption="Вещи-доноры"
          columns={donorColumns}
          rows={donors}
          rowKey={(row) => row.donor.id}
          empty={<EmptyState icon={<Leaf className="size-6" aria-hidden="true" />} title="Вещей-доноров нет" description="Они появляются здесь после сохранения заказа." />}
        />
      ) : (
        <div className="space-y-6">
          <DataTable
            caption="Расходные материалы"
            columns={stockColumns}
            rows={stock}
            rowKey={(item) => item.info.id}
            empty={<EmptyState icon={<Droplets className="size-6" aria-hidden="true" />} title="Позиций не найдено" />}
          />

          <section aria-labelledby="mv-heading">
            <h2 id="mv-heading" className="mb-2 text-lg font-semibold">
              Последние движения
            </h2>
            {movements.length === 0 ? (
              <p className="text-sm text-muted-foreground">Движений пока нет.</p>
            ) : (
              <ul className="divide-y divide-border rounded-lg border border-border bg-surface">
                {movements.map((item) => {
                  const info = STOCK_ITEMS.find((entry) => entry.id === item.itemId)
                  return (
                    <li key={item.id} className="flex items-center justify-between gap-3 px-3 py-2.5 text-sm">
                      <span className="min-w-0">
                        <span className="block truncate">{info?.name ?? item.itemId}</span>
                        <span className="block text-xs text-muted-foreground">
                          {formatIsoDate(item.at)} · {item.note}
                        </span>
                      </span>
                      <span className={item.qty > 0 ? 'font-mono text-success-text' : 'font-mono text-destructive-text'}>
                        {item.qty > 0 ? '+' : '−'}
                        {formatNumber(Math.abs(item.qty), 1)} {info?.unit}
                        {item.qty > 0 && item.cost > 0 ? <span className="ml-2 text-xs text-muted-foreground">{formatRub(item.cost)}</span> : null}
                      </span>
                    </li>
                  )
                })}
              </ul>
            )}
          </section>
        </div>
      )}

      <MovementModal
        itemId={movement?.itemId ?? null}
        mode={movement?.mode ?? 'receive'}
        onClose={() => setMovement(null)}
      />
    </div>
  )
}

export function InventoryView() {
  return (
    <Suspense fallback={<PageSkeleton />}>
      <InventoryInner />
    </Suspense>
  )
}
