'use client'

import { Printer } from 'lucide-react'

import { GphAct } from '@/components/payroll/GphAct'
import { Button } from '@/components/ui/button'
import { Modal } from '@/components/ui/modal'
import type { Payout } from '@/lib/domain/types'
import { useApp } from '@/store/AppProvider'

/** Акт ГПХ в окне: можно распечатать или сохранить в PDF через диалог печати браузера. */
export function PayoutActModal({ payout, onClose }: { payout: Payout | null; onClose: () => void }) {
  const { state } = useApp()
  const master = payout ? state.masters.find((item) => item.id === payout.masterId) : undefined

  return (
    <Modal
      open={payout !== null}
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      size="lg"
      title={payout ? `Акт выполненных работ № ${payout.actNo}` : 'Акт'}
      description="Акт по договору ГПХ сформирован автоматически. Для PDF выберите «Сохранить как PDF» в окне печати."
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Закрыть
          </Button>
          <Button onClick={() => window.print()}>
            <Printer aria-hidden="true" />
            Печать / PDF
          </Button>
        </>
      }
    >
      {payout ? <GphAct payout={payout} master={master} orders={state.orders} /> : null}
    </Modal>
  )
}
