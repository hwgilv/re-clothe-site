'use client'

import { useMemo, useState } from 'react'
import Link from 'next/link'
import { BadgeCheck, Banknote, FileText, HandCoins, ShieldMinus, SlidersHorizontal, Wallet } from 'lucide-react'

import { PageHeader } from '@/components/common/PageHeader'
import { AdjustmentsPanel } from '@/components/orders/AdjustmentsPanel'
import { PayoutActModal } from '@/components/payroll/PayoutActModal'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { DataTable, type Column } from '@/components/ui/data-table'
import { EmptyState } from '@/components/ui/empty-state'
import { Modal } from '@/components/ui/modal'
import { SegmentedControl } from '@/components/ui/segmented-control'
import { useToast } from '@/components/ui/toast'
import { initialsOf } from '@/lib/domain/client'
import { buildPayoutDraft, computePayrollSummary, type MasterView } from '@/lib/domain/derive'
import type { Payout } from '@/lib/domain/types'
import { addMonthsToKey, formatMonthKey, monthKey } from '@/lib/date'
import { formatIsoDate, formatRub } from '@/lib/format'
import { cn } from '@/lib/utils'
import { useActions, useApp } from '@/store/AppProvider'

type PeriodId = 'all' | 'current' | 'previous'

function StatCard({
  title,
  value,
  hint,
  icon: Icon,
  tone,
  testId,
}: {
  title: string
  value: string
  hint: string
  icon: React.ComponentType<{ className?: string }>
  tone: 'primary' | 'success' | 'destructive' | 'denim'
  testId: string
}) {
  const toneClass = {
    primary: 'text-primary-text bg-primary/10',
    success: 'text-success-text bg-success/10',
    destructive: 'text-destructive-text bg-destructive/10',
    denim: 'text-denim-text bg-denim/15',
  }[tone]
  return (
    <Card>
      <CardContent className="flex items-start gap-3 p-4">
        <span className={cn('flex size-10 shrink-0 items-center justify-center rounded-lg', toneClass)}>
          <Icon className="size-5" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <p className="font-mono text-2xs uppercase tracking-widest text-muted-foreground">{title}</p>
          <p className="mt-1 font-mono text-xl font-bold tabular-nums sm:text-2xl" data-testid={testId}>
            {value}
          </p>
          <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>
        </div>
      </CardContent>
    </Card>
  )
}

/**
 * Кнопка выплаты. Есть что платить — «Выплатить ЗП»; баланс обнулён — «Выплачено»
 * (у мастера есть закрытые заказы) или «Нет к выплате» (закрытых заказов ещё нет).
 */
function PayButton({
  item,
  onPay,
  size,
  className,
}: {
  item: MasterView
  onPay: () => void
  size?: 'sm'
  className?: string
}) {
  const nothingToPay = item.unpaid.length === 0 || item.balance <= 0
  if (nothingToPay) {
    const settled = item.closed.length > 0
    return (
      <Button
        size={size}
        variant="outline"
        disabled
        className={cn(settled && 'border-success/40 text-success-text disabled:opacity-100', className)}
      >
        {settled ? <BadgeCheck aria-hidden="true" /> : null}
        {settled ? 'Выплачено' : 'Нет к выплате'}
      </Button>
    )
  }
  return (
    <Button size={size} variant="success" onClick={onPay} className={className}>
      <HandCoins aria-hidden="true" />
      Выплатить ЗП
    </Button>
  )
}

function MasterAvatar({ item }: { item: MasterView }) {
  return (
    <span className="flex items-center gap-3">
      <span
        aria-hidden="true"
        className="flex size-10 shrink-0 items-center justify-center rounded-full font-mono text-sm font-bold"
        style={{ background: `${item.master.color}33`, color: item.master.color, boxShadow: `inset 0 0 0 1px ${item.master.color}88` }}
      >
        {initialsOf(item.master.name)}
      </span>
      <span className="min-w-0">
        <span className="block font-medium leading-tight">{item.master.name}</span>
        <span className="block text-xs text-muted-foreground">{item.master.role}</span>
      </span>
    </span>
  )
}

export function PayrollView() {
  const { state, derived } = useApp()
  const actions = useActions()
  const toast = useToast()

  const [period, setPeriod] = useState<PeriodId>('current')
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const [actId, setActId] = useState<string | null>(null)
  const [adjustOrderId, setAdjustOrderId] = useState<string | null>(null)

  const currentKey = derived.currentMonth
  const periodKey = period === 'all' ? null : period === 'current' ? currentKey : addMonthsToKey(currentKey, -1)
  const periodLabel =
    period === 'all' ? 'за всё время' : `за ${formatMonthKey(periodKey ?? currentKey, 'long')}`

  const summary = useMemo(
    () => computePayrollSummary(derived.masters, state.payouts, periodKey),
    [derived.masters, state.payouts, periodKey],
  )

  const inPeriod = (iso: string | null): boolean => iso !== null && (periodKey === null || monthKey(iso) === periodKey)

  const payouts = useMemo(
    () =>
      state.payouts
        .filter((payout) => periodKey === null || monthKey(payout.at) === periodKey)
        .sort((a, b) => (a.at < b.at ? 1 : a.at > b.at ? -1 : b.actNo - a.actNo)),
    [state.payouts, periodKey],
  )

  const confirmMaster = confirmId ? derived.masterById.get(confirmId) : undefined
  const confirmDraft = confirmMaster ? buildPayoutDraft(confirmMaster.master.id, confirmMaster.unpaid) : null
  const actPayout = actId ? state.payouts.find((payout) => payout.id === actId) ?? null : null
  const adjustView = adjustOrderId ? derived.orderById.get(adjustOrderId) : undefined

  const pay = (): void => {
    if (!confirmMaster) return
    const result = actions.payMaster(confirmMaster.master.id)
    setConfirmId(null)
    if (result) {
      setActId(result.id)
      toast({
        title: `Выплачено: ${confirmMaster.master.name}`,
        description: `${formatRub(result.total)} · акт № ${result.actNo}. Баланс обнулён, сумма перенесена в «Выплачено».`,
      })
    }
  }

  const columns: Column<MasterView>[] = [
    { key: 'master', header: 'Мастер', mobileTitle: true, cell: (item) => <MasterAvatar item={item} /> },
    {
      key: 'closed',
      header: 'Закрыто заказов',
      align: 'right',
      cell: (item) => {
        const count = item.closed.filter((view) => inPeriod(view.order.completedAt)).length
        return (
          <span className="font-mono tabular-nums">
            {count}
            <span className="block text-2xs text-muted-foreground">к выплате: {item.unpaid.length}</span>
          </span>
        )
      },
    },
    {
      key: 'base',
      header: 'Базовый заработок',
      align: 'right',
      cell: (item) => <span className="font-mono tabular-nums">{formatRub(item.unpaidBase)}</span>,
    },
    {
      key: 'bonus',
      header: 'Премии',
      align: 'right',
      cell: (item) => <span className="font-mono tabular-nums text-success-text">+ {formatRub(item.unpaidBonuses)}</span>,
    },
    {
      key: 'penalty',
      header: 'Штрафы',
      align: 'right',
      cell: (item) => (
        <span className="font-mono tabular-nums text-destructive-text">− {formatRub(item.unpaidPenalties)}</span>
      ),
    },
    {
      key: 'total',
      header: 'Итого к выплате',
      align: 'right',
      cell: (item) => (
        <span className="font-mono text-base font-bold tabular-nums" data-testid={`balance-${item.master.id}`}>
          {formatRub(item.balance)}
        </span>
      ),
    },
    {
      key: 'action',
      header: '',
      align: 'right',
      cell: (item) => (
        <PayButton item={item} onPay={() => setConfirmId(item.master.id)} size="sm" />
      ),
    },
  ]

  const payoutColumns: Column<Payout>[] = [
    {
      key: 'act',
      header: 'Акт',
      mobileTitle: true,
      cell: (payout) => <span className="font-mono font-semibold">№ {payout.actNo}</span>,
    },
    { key: 'date', header: 'Дата', cell: (payout) => formatIsoDate(payout.at) },
    {
      key: 'master',
      header: 'Мастер',
      cell: (payout) => state.masters.find((item) => item.id === payout.masterId)?.name ?? '—',
    },
    {
      key: 'orders',
      header: 'Заказов',
      align: 'right',
      cell: (payout) => <span className="font-mono">{payout.lines.length}</span>,
    },
    { key: 'base', header: 'База', align: 'right', cell: (payout) => <span className="font-mono tabular-nums">{formatRub(payout.base)}</span> },
    {
      key: 'bonus',
      header: 'Премии',
      align: 'right',
      cell: (payout) => <span className="font-mono tabular-nums text-success-text">+ {formatRub(payout.bonuses)}</span>,
    },
    {
      key: 'penalty',
      header: 'Штрафы',
      align: 'right',
      cell: (payout) => <span className="font-mono tabular-nums text-destructive-text">− {formatRub(payout.penalties)}</span>,
    },
    {
      key: 'total',
      header: 'Выплачено',
      align: 'right',
      cell: (payout) => <span className="font-mono font-bold tabular-nums">{formatRub(payout.total)}</span>,
    },
    {
      key: 'doc',
      header: '',
      align: 'right',
      cell: () => (
        <span className="inline-flex items-center gap-1 text-xs text-primary-text">
          <FileText className="size-3.5" aria-hidden="true" />
          Акт
        </span>
      ),
    },
  ]

  const periodOptions = [
    { value: 'current', label: formatMonthKey(currentKey) },
    { value: 'previous', label: formatMonthKey(addMonthsToKey(currentKey, -1)) },
    { value: 'all', label: 'Всё время' },
  ] as const

  const withOrders = derived.masters.filter((item) => item.unpaid.length > 0)

  return (
    <div>
      <PageHeader
        title="Бухгалтерия и расчёт зарплат"
        description="ЗП портных считается автоматически из закрытых заказов, премий и штрафов. Любое изменение в заказе мгновенно меняет баланс."
        actions={
          <SegmentedControl<PeriodId>
            aria-label="Период"
            value={period}
            onChange={setPeriod}
            options={periodOptions}
          />
        }
      />

      <div className="mb-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          testId="sum-accrued"
          title="Всего начислено ЗП портным"
          value={formatRub(summary.accrued)}
          hint={`Закрытые заказы ${periodLabel}`}
          icon={Banknote}
          tone="denim"
        />
        <StatCard
          testId="sum-paid"
          title="Выплачено за период"
          value={formatRub(summary.paid)}
          hint={`По актам ГПХ ${periodLabel}`}
          icon={BadgeCheck}
          tone="success"
        />
        <StatCard
          testId="sum-withheld"
          title="Удержано за брак"
          value={formatRub(summary.withheld)}
          hint="Штрафы и удержания"
          icon={ShieldMinus}
          tone="destructive"
        />
        <StatCard
          testId="sum-balance"
          title="Текущий баланс к выплате"
          value={formatRub(summary.balance)}
          hint="Что нужно выплатить прямо сейчас"
          icon={Wallet}
          tone="primary"
        />
      </div>

      <section aria-labelledby="masters-heading" className="mb-6">
        <h2 id="masters-heading" className="mb-3 text-lg font-semibold">
          Портные
        </h2>
        <DataTable
          caption="Расчёт зарплат по портным"
          columns={columns}
          rows={derived.masters}
          rowKey={(item) => item.master.id}
          mobileCard={(item) => (
            <div className="space-y-3">
              <MasterAvatar item={item} />
              <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-sm">
                <dt className="text-muted-foreground">Закрыто заказов</dt>
                <dd className="text-right font-mono">
                  {item.closed.filter((view) => inPeriod(view.order.completedAt)).length} · к выплате {item.unpaid.length}
                </dd>
                <dt className="text-muted-foreground">Базовый заработок</dt>
                <dd className="text-right font-mono">{formatRub(item.unpaidBase)}</dd>
                <dt className="text-muted-foreground">Премии</dt>
                <dd className="text-right font-mono text-success-text">+ {formatRub(item.unpaidBonuses)}</dd>
                <dt className="text-muted-foreground">Штрафы</dt>
                <dd className="text-right font-mono text-destructive-text">− {formatRub(item.unpaidPenalties)}</dd>
                <dt className="font-medium">Итого к выплате</dt>
                <dd className="text-right font-mono text-base font-bold">{formatRub(item.balance)}</dd>
              </dl>
              <PayButton item={item} onPay={() => setConfirmId(item.master.id)} className="w-full" />
            </div>
          )}
        />
      </section>

      <section aria-labelledby="unpaid-heading" className="mb-6">
        <h2 id="unpaid-heading" className="mb-3 text-lg font-semibold">
          Заказы к выплате
        </h2>
        {withOrders.length === 0 ? (
          <EmptyState
            title="Выплачивать нечего"
            description="Когда мастер переведёт заказ на этап «Готово», он появится здесь вместе с ЗП."
          />
        ) : (
          <div className="grid gap-4 xl:grid-cols-2">
            {withOrders.map((item) => (
              <Card key={item.master.id}>
                <CardHeader>
                  <CardTitle>{item.master.name}</CardTitle>
                  <span className="font-mono text-sm font-bold tabular-nums">{formatRub(item.balance)}</span>
                </CardHeader>
                <CardContent className="space-y-2">
                  {item.unpaid.map((view) => (
                    <div key={view.order.id} className="rounded-lg border border-border bg-background p-3">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div className="min-w-0">
                          <Link
                            href={`/orders/${view.order.id}`}
                            className="font-mono text-sm font-semibold hover:text-primary-text hover:underline"
                          >
                            {view.order.number}
                          </Link>
                          <p className="text-xs text-muted-foreground">
                            {view.service.name} · закрыт {view.order.completedAt ? formatIsoDate(view.order.completedAt) : '—'}
                          </p>
                        </div>
                        <p className="font-mono text-sm font-bold tabular-nums">{formatRub(view.payroll.total)}</p>
                      </div>
                      <p className="mt-1 flex flex-wrap gap-x-3 font-mono text-xs tabular-nums">
                        <span>база {formatRub(view.payroll.base)}</span>
                        <span className="text-success-text">+{formatRub(view.payroll.bonusTotal)}</span>
                        <span className="text-destructive-text">−{formatRub(view.payroll.penaltyTotal)}</span>
                      </p>
                      {view.payroll.bonuses.length + view.payroll.penalties.length > 0 ? (
                        <ul className="mt-1.5 flex flex-wrap gap-1">
                          {view.payroll.bonuses.map((line) => (
                            <li key={line.id}>
                              <Badge variant="success">{line.label}</Badge>
                            </li>
                          ))}
                          {view.payroll.penalties.map((line) => (
                            <li key={line.id}>
                              <Badge variant="destructive">{line.label}</Badge>
                            </li>
                          ))}
                        </ul>
                      ) : null}
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-2"
                        onClick={() => setAdjustOrderId(view.order.id)}
                      >
                        <SlidersHorizontal aria-hidden="true" />
                        Премии и штрафы
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      <section aria-labelledby="payouts-heading">
        <h2 id="payouts-heading" className="mb-3 text-lg font-semibold">
          Выплачено {periodLabel}
        </h2>
        <DataTable
          caption="История выплат"
          columns={payoutColumns}
          rows={payouts}
          rowKey={(payout) => payout.id}
          onRowClick={(payout) => setActId(payout.id)}
          empty={<EmptyState title="Выплат за период нет" description="После нажатия «Выплатить ЗП» здесь появится акт ГПХ." />}
        />
      </section>

      <Modal
        open={confirmMaster !== undefined && confirmDraft !== null}
        onOpenChange={(open) => {
          if (!open) setConfirmId(null)
        }}
        title={confirmMaster ? `Выплатить ЗП: ${confirmMaster.master.name}` : 'Выплата'}
        description="Баланс мастера обнулится, сумма уйдёт в «Выплачено», будет сформирован акт ГПХ."
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirmId(null)}>
              Отмена
            </Button>
            <Button variant="success" onClick={pay}>
              <HandCoins aria-hidden="true" />
              Выплатить {confirmDraft ? formatRub(confirmDraft.total) : ''}
            </Button>
          </>
        }
      >
        {confirmDraft ? (
          <div className="space-y-3">
            <ul className="divide-y divide-border rounded-lg border border-border">
              {confirmDraft.lines.map((line) => (
                <li key={line.orderId} className="flex items-center justify-between gap-3 px-3 py-2 text-sm">
                  <span className="min-w-0">
                    <span className="block font-mono font-semibold">{line.orderNumber}</span>
                    <span className="block truncate text-xs text-muted-foreground">{line.serviceName}</span>
                  </span>
                  <span className="font-mono tabular-nums">
                    {formatRub(
                      line.base +
                        line.bonuses.reduce((sum, item) => sum + item.amount, 0) -
                        line.penalties.reduce((sum, item) => sum + item.amount, 0),
                    )}
                  </span>
                </li>
              ))}
            </ul>
            <dl className="space-y-1 text-sm">
              <div className="flex justify-between"><dt className="text-muted-foreground">База</dt><dd className="font-mono">{formatRub(confirmDraft.base)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Премии</dt><dd className="font-mono text-success-text">+ {formatRub(confirmDraft.bonuses)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Штрафы</dt><dd className="font-mono text-destructive-text">− {formatRub(confirmDraft.penalties)}</dd></div>
              <div className="flex justify-between border-t border-border pt-1 text-base font-bold"><dt>Итого к выплате</dt><dd className="font-mono">{formatRub(confirmDraft.total)}</dd></div>
            </dl>
            <p className="text-xs text-muted-foreground">
              После выплаты премии и штрафы по этим заказам фиксируются — менять их уже нельзя (акт подписан).
            </p>
          </div>
        ) : null}
      </Modal>

      <PayoutActModal payout={actPayout} onClose={() => setActId(null)} />

      <Modal
        open={adjustView !== undefined}
        onOpenChange={(open) => {
          if (!open) setAdjustOrderId(null)
        }}
        size="xl"
        title={adjustView ? `Премии и штрафы: ${adjustView.order.number}` : 'Премии и штрафы'}
        description={adjustView ? `${adjustView.service.name} · мастер ${adjustView.master?.name ?? '—'}` : undefined}
        footer={<Button onClick={() => setAdjustOrderId(null)}>Готово</Button>}
      >
        {adjustView ? <AdjustmentsPanel view={adjustView} /> : null}
      </Modal>
    </div>
  )
}
