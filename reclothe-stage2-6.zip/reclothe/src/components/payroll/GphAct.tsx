import { STUDIO } from '@/lib/domain/catalog'
import { initialsOf } from '@/lib/domain/client'
import type { Master, Order, Payout } from '@/lib/domain/types'
import { formatDateString, toDateString } from '@/lib/date'
import { formatRub } from '@/lib/format'

/** «Лозовой Роман Тарасович» → «Лозовой Р.Т.» */
function signatureName(full: string): string {
  const [last = '', ...rest] = full.trim().split(/\s+/)
  return `${last} ${rest.map((part) => `${part.charAt(0)}.`).join('')}`.trim()
}

/**
 * Акт выполненных работ по договору ГПХ — по образцу из раздела 7.9 бизнес-плана.
 * Берёт данные из снимка выплаты (payout), поэтому после выплаты акт не меняется,
 * даже если потом изменятся тарифы или заказы.
 */
export function GphAct({
  payout,
  master,
  orders,
  className,
}: {
  payout: Payout
  master: Master | undefined
  orders: readonly Order[]
  className?: string
}) {
  const completed = payout.lines
    .map((line) => orders.find((order) => order.id === line.orderId)?.completedAt)
    .filter((value): value is string => typeof value === 'string')
    .map((iso) => toDateString(new Date(iso)))
    .sort()
  const periodFrom = completed[0] ?? toDateString(new Date(payout.at))
  const periodTo = completed[completed.length - 1] ?? periodFrom

  const bonuses = payout.lines.flatMap((line) =>
    line.bonuses.map((item) => ({ text: `${item.label} (заказ ${line.orderNumber})`, amount: item.amount })),
  )
  const penalties = payout.lines.flatMap((line) =>
    line.penalties.map((item) => ({ text: `${item.label} (заказ ${line.orderNumber})`, amount: item.amount })),
  )
  const performer = master?.name ?? 'Исполнитель'

  return (
    <article
      aria-label={`Акт выполненных работ № ${payout.actNo}`}
      className={`print-area rounded-lg bg-white p-6 font-serif text-[13px] leading-relaxed text-black sm:p-8 ${className ?? ''}`}
    >
      <h2 className="text-center font-serif text-base font-bold uppercase tracking-wide !text-black">
        Акт выполненных работ № {payout.actNo}
      </h2>
      <p className="mt-1 text-center font-semibold">
        по договору {master?.contractNo ?? 'ГПХ'}
        {master ? ` от ${formatDateString(master.contractDate)}` : ''}
      </p>
      <p className="mt-1 text-center text-xs">г. {STUDIO.city}, {formatDateString(toDateString(new Date(payout.at)))}</p>

      <p className="mt-5">
        <strong>Заказчик:</strong> {STUDIO.owner} (студия {STUDIO.name})
      </p>
      <p>
        <strong>Исполнитель:</strong> {performer}
        {master ? ` (${master.role})` : ''}
      </p>
      <p>
        <strong>Период:</strong> {formatDateString(periodFrom)} — {formatDateString(periodTo)}
      </p>

      <h3 className="mt-5 font-serif text-sm font-bold !text-black">Выполненные работы:</h3>
      <ol className="mt-1 list-decimal space-y-0.5 pl-6">
        {payout.lines.map((line) => (
          <li key={line.orderId}>
            {line.serviceName} (заказ {line.orderNumber}) — <span className="whitespace-nowrap">{formatRub(line.base)}</span>
          </li>
        ))}
      </ol>
      <p className="mt-1 text-right">
        Итого по работам: <strong>{formatRub(payout.base)}</strong>
      </p>

      <h3 className="mt-4 font-serif text-sm font-bold !text-black">Бонусы:</h3>
      {bonuses.length === 0 ? (
        <p className="pl-6">—</p>
      ) : (
        <ul className="mt-1 list-disc space-y-0.5 pl-6">
          {bonuses.map((item, index) => (
            <li key={`b-${index}`}>
              {item.text} — <span className="whitespace-nowrap">{formatRub(item.amount)}</span>
            </li>
          ))}
        </ul>
      )}

      <h3 className="mt-4 font-serif text-sm font-bold !text-black">Штрафы:</h3>
      {penalties.length === 0 ? (
        <p className="pl-6">—</p>
      ) : (
        <ul className="mt-1 list-disc space-y-0.5 pl-6">
          {penalties.map((item, index) => (
            <li key={`p-${index}`}>
              {item.text} — <span className="whitespace-nowrap">−{formatRub(item.amount)}</span>
            </li>
          ))}
        </ul>
      )}

      <p className="mt-5 border-t border-black pt-3 text-base font-bold">
        Итого к выплате: {formatRub(payout.total)}
      </p>
      <p className="mt-2 text-xs">
        Работы выполнены в полном объёме и в срок, результат принят Заказчиком, претензий по объёму, качеству и срокам
        нет. Вознаграждение определено по результату работ и выплачивается по факту сдачи.
      </p>

      <div className="mt-8 grid gap-6 sm:grid-cols-2">
        <p>
          Заказчик: ________________ /{signatureName(STUDIO.owner)}/
        </p>
        <p>
          Исполнитель: ________________ /{signatureName(performer || initialsOf(performer))}/
        </p>
      </div>
    </article>
  )
}
