'use client'

import { CommandPalette } from '@/components/common/CommandPalette'
import { EcoFooter } from '@/components/common/EcoFooter'
import { HotkeysProvider } from '@/components/common/HotkeysProvider'
import { MobileNav } from '@/components/common/MobileNav'
import { Sidebar } from '@/components/common/Sidebar'
import { Topbar } from '@/components/common/Topbar'
import { OrderModal } from '@/components/orders/OrderModal'

/**
 * Оболочка администратора: сайдбар на компьютере, бургер-меню на телефоне и планшете,
 * верхняя панель, контент, эко-футер и глобальное окно «+ Новый заказ».
 */
export function AdminShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-dvh">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[60] focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-foreground"
      >
        Перейти к содержимому
      </a>

      <Sidebar />
      <MobileNav />

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar />
        <main id="main-content" tabIndex={-1} className="flex-1 px-3 py-5 focus-visible:ring-0 sm:px-4 lg:px-6">
          <div className="mx-auto w-full max-w-[1600px]">{children}</div>
        </main>
        <EcoFooter />
      </div>

      <CommandPalette />
      <HotkeysProvider />
      <OrderModal />
    </div>
  )
}
