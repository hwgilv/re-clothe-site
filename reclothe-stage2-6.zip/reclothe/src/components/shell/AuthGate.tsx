'use client'

import { useEffect } from 'react'

import { useSession } from '@/components/auth/SessionProvider'
import { WelcomeScreen } from '@/components/auth/WelcomeScreen'
import { ClientCabinet } from '@/components/client/ClientCabinet'
import { AdminShell } from '@/components/shell/AdminShell'
import { Logo } from '@/components/common/Logo'
import { useApp } from '@/store/AppProvider'

function Splash() {
  return (
    <div
      role="status"
      aria-live="polite"
      className="flex min-h-dvh flex-col items-center justify-center gap-3"
    >
      <Logo className="text-2xl" />
      <span className="sr-only">Загрузка…</span>
      <div className="h-1 w-24 overflow-hidden rounded-full bg-muted" aria-hidden="true">
        <div className="h-full w-1/2 animate-pulse rounded-full bg-primary" />
      </div>
    </div>
  )
}

/**
 * Шлюз по ролям: гость видит выбор роли, администратор — полную панель,
 * клиент — личный кабинет (на любом адресе).
 */
export function AuthGate({ children }: { children: React.ReactNode }) {
  const { status, clientId, logout } = useSession()
  const { ready, derived } = useApp()

  // Клиента, которого стёрли из базы (сброс данных), возвращаем на экран входа.
  const clientMissing =
    status === 'client' && ready && (clientId === null || !derived.clientById.has(clientId))
  useEffect(() => {
    if (clientMissing) logout()
  }, [clientMissing, logout])

  if (status === 'booting' || !ready || clientMissing) return <Splash />
  if (status === 'guest') return <WelcomeScreen />
  if (status === 'client' && clientId) return <ClientCabinet clientId={clientId} />
  return <AdminShell>{children}</AdminShell>
}
