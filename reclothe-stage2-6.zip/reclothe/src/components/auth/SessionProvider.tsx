'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react'

import {
  hasAdminPassword,
  setAdminPassword,
  verifyAdminPassword,
} from '@/lib/auth/password'
import { readSession, writeSession, type Session } from '@/lib/auth/session'
import {
  LOCK_HEARTBEAT_MS,
  LOCK_STORAGE_KEY,
  acquireAdminLock,
  isAdminLockTaken,
  refreshAdminLock,
  releaseAdminLock,
} from '@/lib/auth/tab-lock'

/**
 * Сессия этой вкладки: гость → администратор / клиент.
 *
 * Правила модуля 1:
 *  - первый визит: администратор задаёт мастер-пароль, он навсегда остаётся в localStorage;
 *  - дальше вход только по паролю;
 *  - пока администратор авторизован в одной вкладке, вход администратора в других
 *    вкладках блокируется («Доступ ограничен, сессия активна»).
 */

export type SessionStatus = 'booting' | 'guest' | 'admin' | 'client'

export type AdminAuthResult = 'ok' | 'wrong-password' | 'locked' | 'storage-error'

interface SessionContextValue {
  status: SessionStatus
  clientId: string | null
  /** Мастер-пароль уже задан (определяется на клиенте после загрузки). */
  passwordSet: boolean
  /** Админ уже работает в другой вкладке. */
  adminLocked: boolean
  /** Вкладку выбросило из админки: замок перехватила другая вкладка. */
  evicted: boolean
  setupAdmin: (password: string) => Promise<AdminAuthResult>
  loginAdmin: (password: string) => Promise<AdminAuthResult>
  loginClient: (clientId: string) => void
  logout: () => void
  dismissEviction: () => void
}

const SessionContext = createContext<SessionContextValue | null>(null)

/** Сколько ждём освобождения замка после перезагрузки вкладки администратора. */
const BOOT_LOCK_RETRY_MS = 6_000
const BOOT_LOCK_STEP_MS = 400

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<SessionStatus>('booting')
  const [clientId, setClientId] = useState<string | null>(null)
  const [passwordSet, setPasswordSet] = useState(false)
  const [adminLocked, setAdminLocked] = useState(false)
  const [evicted, setEvicted] = useState(false)
  const statusRef = useRef<SessionStatus>('booting')
  statusRef.current = status

  /* ------------------------------------------------------------------ запуск */

  useEffect(() => {
    let cancelled = false
    let timer: number | undefined
    setPasswordSet(hasAdminPassword())

    const stored = readSession()
    if (!stored) {
      setStatus('guest')
      return
    }
    if (stored.role === 'client') {
      setClientId(stored.clientId)
      setStatus('client')
      return
    }

    // Вкладка уже была админской (перезагрузка страницы). Замок прежней загрузки
    // освобождается при выгрузке страницы; если нет — ждём, пока он протухнет.
    const startedAt = Date.now()
    const attempt = (): void => {
      if (cancelled) return
      if (acquireAdminLock()) {
        setStatus('admin')
        return
      }
      if (Date.now() - startedAt >= BOOT_LOCK_RETRY_MS) {
        writeSession(null)
        setAdminLocked(true)
        setStatus('guest')
        return
      }
      timer = window.setTimeout(attempt, BOOT_LOCK_STEP_MS)
    }
    attempt()

    return () => {
      cancelled = true
      if (timer !== undefined) window.clearTimeout(timer)
    }
  }, [])

  /* ------------------------------------------- пульс замка и слежение за ним */

  useEffect(() => {
    if (status !== 'admin') return

    const beat = window.setInterval(() => {
      if (!refreshAdminLock()) {
        writeSession(null)
        setEvicted(true)
        setClientId(null)
        setStatus('guest')
      }
    }, LOCK_HEARTBEAT_MS)

    const release = (): void => releaseAdminLock()
    window.addEventListener('pagehide', release)
    window.addEventListener('beforeunload', release)

    return () => {
      window.clearInterval(beat)
      window.removeEventListener('pagehide', release)
      window.removeEventListener('beforeunload', release)
    }
  }, [status])

  // Гостевой экран следит, не занят ли вход администратора другой вкладкой.
  useEffect(() => {
    if (status !== 'guest') return
    const check = (): void => setAdminLocked(isAdminLockTaken())
    check()
    const timer = window.setInterval(check, LOCK_HEARTBEAT_MS)
    const onStorage = (event: StorageEvent): void => {
      if (event.key === LOCK_STORAGE_KEY || event.key === null) check()
    }
    window.addEventListener('storage', onStorage)
    return () => {
      window.clearInterval(timer)
      window.removeEventListener('storage', onStorage)
    }
  }, [status])

  /* ---------------------------------------------------------------- действия */

  const enterAdmin = useCallback((): AdminAuthResult => {
    if (!acquireAdminLock()) {
      setAdminLocked(true)
      return 'locked'
    }
    writeSession({ role: 'admin' } satisfies Session)
    setAdminLocked(false)
    setEvicted(false)
    setPasswordSet(true)
    setStatus('admin')
    return 'ok'
  }, [])

  const setupAdmin = useCallback(
    async (password: string): Promise<AdminAuthResult> => {
      if (isAdminLockTaken()) {
        setAdminLocked(true)
        return 'locked'
      }
      const saved = await setAdminPassword(password)
      if (!saved) return 'storage-error'
      return enterAdmin()
    },
    [enterAdmin],
  )

  const loginAdmin = useCallback(
    async (password: string): Promise<AdminAuthResult> => {
      // Сначала замок: пока админ в другой вкладке, даже верный пароль не пустит.
      if (isAdminLockTaken()) {
        setAdminLocked(true)
        return 'locked'
      }
      const valid = await verifyAdminPassword(password)
      if (!valid) return 'wrong-password'
      return enterAdmin()
    },
    [enterAdmin],
  )

  const loginClient = useCallback((id: string): void => {
    writeSession({ role: 'client', clientId: id } satisfies Session)
    setClientId(id)
    setStatus('client')
  }, [])

  const logout = useCallback((): void => {
    if (statusRef.current === 'admin') releaseAdminLock()
    writeSession(null)
    setClientId(null)
    setStatus('guest')
  }, [])

  const dismissEviction = useCallback(() => setEvicted(false), [])

  const value = useMemo<SessionContextValue>(
    () => ({
      status,
      clientId,
      passwordSet,
      adminLocked,
      evicted,
      setupAdmin,
      loginAdmin,
      loginClient,
      logout,
      dismissEviction,
    }),
    [
      status,
      clientId,
      passwordSet,
      adminLocked,
      evicted,
      setupAdmin,
      loginAdmin,
      loginClient,
      logout,
      dismissEviction,
    ],
  )

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>
}

export function useSession(): SessionContextValue {
  const value = useContext(SessionContext)
  if (!value) throw new Error('useSession должен вызываться внутри <SessionProvider>')
  return value
}
