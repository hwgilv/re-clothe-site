'use client'

import { useEffect, useRef, useState } from 'react'
import {
  ArrowLeft,
  Eye,
  EyeOff,
  Lock,
  LogIn,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  UserRound,
} from 'lucide-react'

import { useSession } from '@/components/auth/SessionProvider'
import { Logo } from '@/components/common/Logo'
import { Button } from '@/components/ui/button'
import { Field } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { APP_TAGLINE } from '@/config/app'
import { MESSENGERS } from '@/lib/domain/catalog'
import type { MessengerId } from '@/lib/domain/types'
import { MIN_PASSWORD_LENGTH } from '@/lib/auth/password'
import {
  validateClientForm,
  type ClientFormErrors,
  type ClientFormValues,
} from '@/lib/validation/client-form'
import { cn } from '@/lib/utils'
import { useActions } from '@/store/AppProvider'

type Step = 'choose' | 'admin' | 'client'

const MAX_ATTEMPTS = 3
const COOLDOWN_SECONDS = 30

/** Первый экран: выбор роли → вход администратора или регистрация клиента. */
export function WelcomeScreen() {
  const session = useSession()
  const [step, setStep] = useState<Step>('choose')

  return (
    <main className="relative flex min-h-dvh flex-col items-center justify-center bg-vignette px-4 py-10">
      <div className="absolute inset-x-0 top-0 h-1.5 bg-hazard" aria-hidden="true" />

      <div className="w-full max-w-md animate-fade-up">
        <div className="mb-6 text-center">
          <Logo className="text-3xl" />
          <p className="mt-2 font-mono text-2xs uppercase tracking-widest text-muted-foreground">
            {APP_TAGLINE}
          </p>
        </div>

        <div className="rounded-xl border border-border bg-surface p-5 shadow-2xl sm:p-6">
          {session.evicted && step === 'choose' ? (
            <div
              role="alert"
              className="mb-4 flex gap-2.5 rounded-lg border border-warning/40 bg-warning/10 p-3 text-sm"
            >
              <ShieldAlert className="mt-0.5 size-4 shrink-0 text-warning-text" aria-hidden="true" />
              <div className="min-w-0">
                <p className="font-medium text-warning-text">Сессия администратора завершена</p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Вход администратора выполнен в другой вкладке этого браузера.
                </p>
                <button
                  type="button"
                  onClick={session.dismissEviction}
                  className="mt-1 text-xs text-primary-text underline-offset-2 hover:underline"
                >
                  Понятно
                </button>
              </div>
            </div>
          ) : null}

          {step === 'choose' && <ChooseRole onPick={setStep} />}
          {step === 'admin' && <AdminAccess onBack={() => setStep('choose')} />}
          {step === 'client' && <ClientRegistration onBack={() => setStep('choose')} />}
        </div>

        <p className="mt-4 text-center text-xs text-muted-foreground">
          Апсайклинг-студия · Новокузнецк · вторая жизнь вашей одежды
        </p>
      </div>
    </main>
  )
}

/* ----------------------------------------------------------------- выбор роли */

function ChooseRole({ onPick }: { onPick: (step: Step) => void }) {
  return (
    <div>
      <h1 className="text-center text-lg font-semibold">Добро пожаловать!</h1>
      <p className="mt-1 text-center text-sm text-muted-foreground">Выберите, как вы хотите войти.</p>

      <div className="mt-5 space-y-3">
        <button
          type="button"
          onClick={() => onPick('admin')}
          className="group flex w-full items-center gap-3 rounded-lg border border-primary/50 bg-primary/10 p-4 text-left transition-colors hover:bg-primary/20"
        >
          <span className="flex size-11 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <ShieldCheck className="size-5" aria-hidden="true" />
          </span>
          <span className="min-w-0">
            <span className="block font-mono text-base font-semibold">Я — Администратор</span>
            <span className="block text-xs text-muted-foreground">
              Заказы, производство, склад, зарплаты и финансы
            </span>
          </span>
        </button>

        <button
          type="button"
          onClick={() => onPick('client')}
          className="group flex w-full items-center gap-3 rounded-lg border border-border bg-background p-4 text-left transition-colors hover:border-denim hover:bg-muted"
        >
          <span className="flex size-11 shrink-0 items-center justify-center rounded-md bg-denim text-white">
            <UserRound className="size-5" aria-hidden="true" />
          </span>
          <span className="min-w-0">
            <span className="block font-mono text-base font-semibold">Я — Клиент</span>
            <span className="block text-xs text-muted-foreground">
              Мои заказы, карта лояльности и вклад в очистку планеты
            </span>
          </span>
        </button>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------ вход администратора */

function BackButton({ onBack }: { onBack: () => void }) {
  return (
    <button
      type="button"
      onClick={onBack}
      className="mb-3 inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
    >
      <ArrowLeft className="size-3.5" aria-hidden="true" />
      Назад к выбору роли
    </button>
  )
}

function PasswordInput({
  id,
  value,
  onChange,
  disabled,
  invalid,
  autoFocus,
  autoComplete,
  describedBy,
}: {
  id: string
  value: string
  onChange: (value: string) => void
  disabled?: boolean
  invalid?: boolean
  autoFocus?: boolean
  autoComplete: string
  describedBy?: string
}) {
  const [visible, setVisible] = useState(false)
  return (
    <div className="relative">
      <Input
        id={id}
        type={visible ? 'text' : 'password'}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        disabled={disabled}
        aria-invalid={invalid || undefined}
        aria-describedby={describedBy}
        autoFocus={autoFocus}
        autoComplete={autoComplete}
        className="pr-10"
      />
      <button
        type="button"
        onClick={() => setVisible((current) => !current)}
        aria-label={visible ? 'Скрыть пароль' : 'Показать пароль'}
        className="absolute right-1 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground transition-colors hover:text-foreground"
      >
        {visible ? <EyeOff className="size-4" aria-hidden="true" /> : <Eye className="size-4" aria-hidden="true" />}
      </button>
    </div>
  )
}

function AdminAccess({ onBack }: { onBack: () => void }) {
  const { passwordSet, adminLocked, setupAdmin, loginAdmin } = useSession()

  if (adminLocked) {
    return (
      <div>
        <BackButton onBack={onBack} />
        <div
          role="alert"
          className="rounded-lg border border-warning/40 bg-warning/10 p-4 text-center"
        >
          <Lock className="mx-auto size-7 text-warning-text" aria-hidden="true" />
          <h2 className="mt-2 text-lg font-semibold text-warning-text">Доступ ограничен, сессия активна</h2>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Администратор уже авторизован в другой вкладке этого браузера. Одновременно в админ-панели
            может работать только один человек.
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            Закройте ту вкладку или выйдите из неё — вход откроется здесь автоматически.
          </p>
        </div>
      </div>
    )
  }

  return passwordSet ? (
    <AdminLogin onBack={onBack} login={loginAdmin} />
  ) : (
    <AdminSetup onBack={onBack} setup={setupAdmin} />
  )
}

function AdminSetup({
  onBack,
  setup,
}: {
  onBack: () => void
  setup: (password: string) => Promise<'ok' | 'wrong-password' | 'locked' | 'storage-error'>
}) {
  const [password, setPassword] = useState('')
  const [repeat, setRepeat] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (event: React.FormEvent): Promise<void> => {
    event.preventDefault()
    if (password.length < MIN_PASSWORD_LENGTH) {
      setError(`Пароль должен быть не короче ${MIN_PASSWORD_LENGTH} символов.`)
      return
    }
    if (password !== repeat) {
      setError('Пароли не совпадают.')
      return
    }
    setError(null)
    setBusy(true)
    const result = await setup(password)
    setBusy(false)
    if (result === 'storage-error') {
      setError('Браузер не дал сохранить пароль. Проверьте, что хранилище сайта не отключено.')
    }
  }

  return (
    <form onSubmit={submit} noValidate>
      <BackButton onBack={onBack} />
      <div className="mb-4 flex items-start gap-3">
        <span className="flex size-10 shrink-0 items-center justify-center rounded-md bg-primary/15 text-primary-text">
          <Sparkles className="size-5" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <h2 className="text-lg font-semibold">Задайте мастер-пароль для администрирования</h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Пароль сохранится в этом браузере навсегда и потребуется при каждом следующем входе.
          </p>
        </div>
      </div>

      <div className="space-y-3">
        <Field label="Мастер-пароль" htmlFor="setup-password">
          <PasswordInput
            id="setup-password"
            value={password}
            onChange={setPassword}
            autoFocus
            autoComplete="new-password"
          />
        </Field>
        <Field label="Повторите пароль" htmlFor="setup-repeat" error={error ?? undefined}>
          <PasswordInput
            id="setup-repeat"
            value={repeat}
            onChange={setRepeat}
            invalid={Boolean(error)}
            autoComplete="new-password"
            describedBy={error ? 'setup-repeat-error' : undefined}
          />
        </Field>
      </div>

      <Button type="submit" size="lg" className="mt-5 w-full" disabled={busy}>
        <ShieldCheck aria-hidden="true" />
        Сохранить и войти
      </Button>
    </form>
  )
}

function AdminLogin({
  onBack,
  login,
}: {
  onBack: () => void
  login: (password: string) => Promise<'ok' | 'wrong-password' | 'locked' | 'storage-error'>
}) {
  const [password, setPassword] = useState('')
  const [attempts, setAttempts] = useState(0)
  const [denied, setDenied] = useState(false)
  const [shakeKey, setShakeKey] = useState(0)
  const [cooldown, setCooldown] = useState(0)
  const [busy, setBusy] = useState(false)
  const inputRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (cooldown <= 0) return
    const timer = window.setTimeout(() => setCooldown((value) => value - 1), 1000)
    return () => window.clearTimeout(timer)
  }, [cooldown])

  const submit = async (event: React.FormEvent): Promise<void> => {
    event.preventDefault()
    if (busy || cooldown > 0 || password.length === 0) return
    setBusy(true)
    const result = await login(password)
    setBusy(false)
    if (result === 'wrong-password') {
      const used = attempts + 1
      setAttempts(used)
      setDenied(true)
      setShakeKey((key) => key + 1)
      setPassword('')
      if (used >= MAX_ATTEMPTS) {
        setCooldown(COOLDOWN_SECONDS)
        setAttempts(0)
      }
    }
  }

  const blocked = cooldown > 0
  const left = MAX_ATTEMPTS - attempts

  return (
    <form onSubmit={submit} noValidate>
      <BackButton onBack={onBack} />
      <div className="mb-4 flex items-start gap-3">
        <span className="flex size-10 shrink-0 items-center justify-center rounded-md bg-primary/15 text-primary-text">
          <Lock className="size-5" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <h2 className="text-lg font-semibold">Вход администратора</h2>
          <p className="mt-1 text-xs text-muted-foreground">Введите мастер-пароль, заданный при первом входе.</p>
        </div>
      </div>

      <div key={shakeKey} ref={inputRef} className={cn(denied && 'animate-shake')}>
        <Field label="Мастер-пароль" htmlFor="login-password">
          <PasswordInput
            id="login-password"
            value={password}
            onChange={(value) => {
              setPassword(value)
              if (denied && !blocked) setDenied(false)
            }}
            autoFocus
            disabled={blocked}
            invalid={denied}
            autoComplete="current-password"
          />
        </Field>
      </div>

      {denied ? (
        <div
          role="alert"
          className="mt-3 flex gap-2.5 rounded-lg border border-destructive/50 bg-destructive/10 p-3"
        >
          <ShieldAlert className="mt-0.5 size-5 shrink-0 text-destructive-text" aria-hidden="true" />
          <div className="min-w-0">
            <p className="font-mono text-sm font-semibold text-destructive-text">Доступ заблокирован</p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {blocked
                ? `Слишком много попыток. Повторите через ${cooldown} с.`
                : `Неверный мастер-пароль. Осталось попыток: ${left}.`}
            </p>
          </div>
        </div>
      ) : null}

      <Button type="submit" size="lg" className="mt-5 w-full" disabled={busy || blocked || password.length === 0}>
        <LogIn aria-hidden="true" />
        {blocked ? `Подождите ${cooldown} с` : 'Войти'}
      </Button>
    </form>
  )
}

/* --------------------------------------------------------------- вход клиента */

type ClientDraft = Record<keyof ClientFormValues, string>

const EMPTY_DRAFT: ClientDraft = {
  lastName: '',
  firstName: '',
  middleName: '',
  phone: '',
  email: '',
  contact: 'telegram',
}

function ClientRegistration({ onBack }: { onBack: () => void }) {
  const { registerClient } = useActions()
  const { loginClient } = useSession()
  const [draft, setDraft] = useState<ClientDraft>(EMPTY_DRAFT)
  const [errors, setErrors] = useState<ClientFormErrors>({})

  const set = (key: keyof ClientDraft) => (value: string) => {
    setDraft((current) => ({ ...current, [key]: value }))
    if (errors[key]) setErrors((current) => ({ ...current, [key]: undefined }))
  }

  const submit = (event: React.FormEvent): void => {
    event.preventDefault()
    const result = validateClientForm(draft)
    if (!result.ok) {
      setErrors(result.errors)
      return
    }
    const { clientId } = registerClient(result.values)
    loginClient(clientId)
  }

  return (
    <form onSubmit={submit} noValidate>
      <BackButton onBack={onBack} />
      <h2 className="text-lg font-semibold">Войти как клиент</h2>
      <p className="mt-1 text-xs text-muted-foreground">
        Заполните данные — мы создадим личный кабинет и свяжемся с вами. Если вы уже заказывали у нас,
        введите тот же телефон или e-mail — вы попадёте в свой кабинет.
      </p>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <Field label="Фамилия" htmlFor="c-last" error={errors.lastName} className="sm:col-span-2">
          <Input
            id="c-last"
            value={draft.lastName}
            onChange={(event) => set('lastName')(event.target.value)}
            autoComplete="family-name"
            aria-invalid={Boolean(errors.lastName) || undefined}
            aria-describedby={errors.lastName ? 'c-last-error' : undefined}
          />
        </Field>
        <Field label="Имя" htmlFor="c-first" error={errors.firstName}>
          <Input
            id="c-first"
            value={draft.firstName}
            onChange={(event) => set('firstName')(event.target.value)}
            autoComplete="given-name"
            aria-invalid={Boolean(errors.firstName) || undefined}
            aria-describedby={errors.firstName ? 'c-first-error' : undefined}
          />
        </Field>
        <Field label="Отчество" htmlFor="c-middle" error={errors.middleName}>
          <Input
            id="c-middle"
            value={draft.middleName}
            onChange={(event) => set('middleName')(event.target.value)}
            autoComplete="additional-name"
            aria-invalid={Boolean(errors.middleName) || undefined}
            aria-describedby={errors.middleName ? 'c-middle-error' : undefined}
          />
        </Field>
        <Field label="Номер телефона" htmlFor="c-phone" error={errors.phone}>
          <Input
            id="c-phone"
            type="tel"
            inputMode="tel"
            placeholder="+7 900 000-00-00"
            value={draft.phone}
            onChange={(event) => set('phone')(event.target.value)}
            autoComplete="tel"
            aria-invalid={Boolean(errors.phone) || undefined}
            aria-describedby={errors.phone ? 'c-phone-error' : undefined}
          />
        </Field>
        <Field label="Email" htmlFor="c-email" error={errors.email}>
          <Input
            id="c-email"
            type="email"
            inputMode="email"
            placeholder="name@mail.ru"
            value={draft.email}
            onChange={(event) => set('email')(event.target.value)}
            autoComplete="email"
            aria-invalid={Boolean(errors.email) || undefined}
            aria-describedby={errors.email ? 'c-email-error' : undefined}
          />
        </Field>
        <Field label="Как с вами связаться?" htmlFor="c-contact" className="sm:col-span-2">
          <Select
            id="c-contact"
            value={draft.contact}
            onChange={(event) => set('contact')(event.target.value as MessengerId)}
          >
            {MESSENGERS.map((messenger) => (
              <option key={messenger.id} value={messenger.id}>
                {messenger.label}
              </option>
            ))}
          </Select>
        </Field>
      </div>

      <Button type="submit" size="lg" className="mt-5 w-full">
        <LogIn aria-hidden="true" />
        Войти
      </Button>
    </form>
  )
}
