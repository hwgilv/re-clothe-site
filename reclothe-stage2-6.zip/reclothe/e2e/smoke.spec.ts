import { expect, test, type Page } from '@playwright/test'

/*
 * Сквозные сценарии: роли и вход, калькулятор заказа, пересчёт после действий,
 * бухгалтерия и выплата ЗП, личный кабинет клиента.
 * Каждый тест стартует с чистым браузерным контекстом (пустой localStorage) —
 * при первом запуске приложение само подставляет демо-данные.
 * Работают и в desktop-, и в tablet-проекте (на планшете меню — за кнопкой-бургером).
 */

const PASSWORD = '123'

async function setupAdmin(page: Page): Promise<void> {
  await page.goto('/')
  await page.getByRole('button', { name: /Я — Администратор/ }).click()
  await expect(page.getByText('Задайте мастер-пароль для администрирования')).toBeVisible()
  await page.getByLabel('Мастер-пароль', { exact: true }).fill(PASSWORD)
  await page.getByLabel('Повторите пароль').fill(PASSWORD)
  await page.getByRole('button', { name: /Сохранить и войти/ }).click()
  await expect(page.getByRole('heading', { level: 1, name: 'Дашборд' })).toBeVisible()
}

async function money(page: Page, testId: string): Promise<number> {
  const text = await page.getByTestId(testId).innerText()
  return Number.parseInt(text.replace(/\D/g, ''), 10)
}

test.describe('вход по ролям', () => {
  test('первый вход администратора задаёт мастер-пароль и открывает дашборд', async ({ page }) => {
    await setupAdmin(page)
    await expect(page.getByRole('heading', { name: 'Воронка производства' })).toBeVisible()
    const stored = await page.evaluate(() => localStorage.getItem('reclothe.admin.pw.v1'))
    expect(stored).not.toBeNull()
    expect(stored).not.toContain(PASSWORD) // хранится хэш, не пароль
  })

  test('неверный пароль → «Доступ заблокирован», верный — вход', async ({ page }) => {
    await setupAdmin(page)
    await page.getByRole('button', { name: 'Выйти' }).first().click()
    await page.getByRole('button', { name: /Я — Администратор/ }).click()
    await expect(page.getByLabel('Повторите пароль')).toHaveCount(0) // теперь только ввод пароля

    await page.getByLabel('Мастер-пароль', { exact: true }).fill('wrong')
    await page.getByRole('button', { name: /^Войти/ }).click()
    await expect(page.getByText('Доступ заблокирован')).toBeVisible()

    await page.getByLabel('Мастер-пароль', { exact: true }).fill(PASSWORD)
    await page.getByRole('button', { name: /^Войти/ }).click()
    await expect(page.getByRole('heading', { level: 1, name: 'Дашборд' })).toBeVisible()
  })

  test('вторая вкладка администратора: «Доступ ограничен, сессия активна»', async ({ page, context }) => {
    await setupAdmin(page)
    const second = await context.newPage()
    await second.goto('/')
    await second.getByRole('button', { name: /Я — Администратор/ }).click()
    await expect(second.getByText('Доступ ограничен, сессия активна')).toBeVisible()
  })

  test('клиент заполняет форму и попадает в «Личный кабинет Клиента»', async ({ page }) => {
    await page.goto('/')
    await page.getByRole('button', { name: /Я — Клиент/ }).click()

    // пустая форма — ошибки, кабинет не открывается
    await page.getByRole('button', { name: /^Войти/ }).click()
    await expect(page.getByText('Личный кабинет Клиента')).toHaveCount(0)

    await page.getByLabel('Фамилия').fill('Тестов')
    await page.getByLabel('Имя', { exact: true }).fill('Иван')
    await page.getByLabel('Отчество').fill('Петрович')
    await page.getByLabel('Номер телефона').fill('9131112233')
    await page.getByLabel('Email').fill('ivan@example.com')
    await page.getByLabel('Как с вами связаться?').selectOption({ label: 'Telegram' })
    await page.getByRole('button', { name: /^Войти/ }).click()

    await expect(page.getByText('Личный кабинет Клиента').first()).toBeVisible()
    await expect(page.getByText('Бронзовая', { exact: false }).first()).toBeVisible()
    await expect(page.getByText('Мой вклад в очистку планеты', { exact: false }).first()).toBeVisible()
  })
})

test.describe('заказы и пересчёт', () => {
  test('новый заказ из калькулятора: цена, остаток, KPI и карточка заказа', async ({ page }) => {
    await setupAdmin(page)
    const activeBefore = await money(page, 'kpi-active')

    await page.getByRole('button', { name: /Новый заказ/ }).first().click()
    const dialog = page.getByRole('dialog')
    await dialog.getByLabel('Найти клиента').fill('Морозов')
    await dialog.getByRole('option').first().click()
    await dialog.getByRole('radio', { name: /Куртка джинсовая сложная/ }).click()
    await dialog.getByRole('radio', { name: /Очень высокая/ }).click() // К сложности 2.0
    await dialog.getByLabel('Мастер', { exact: true }).selectOption({ index: 1 })
    await dialog.getByRole('button', { name: '50%' }).click()

    // клиенту — 6 500 ₽ (цена не зависит от К сложности); аванс 50% → остаток 3 250 ₽
    await expect(dialog).toContainText('Остаток к оплате: 3 250 руб.')
    await dialog.getByRole('button', { name: 'Создать заказ' }).click()

    await expect(page).toHaveURL(/\/orders\//)
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Куртка джинсовая сложная')

    await page.getByRole('link', { name: /^Дашборд/ }).first().click()
    expect(await money(page, 'kpi-active')).toBe(activeBefore + 1)
  })

  test('клик по этапу, премия и штраф мгновенно пересчитывают ЗП мастера', async ({ page }) => {
    await setupAdmin(page)
    await page.getByRole('link', { name: /^Заказы/ }).first().click()
    await page.locator('main a[href^="/orders/"]').first().click()

    await page.getByRole('button', { name: /Перевести на этап 4/ }).click()
    await expect(page.getByText(/Этап 4\. Раскрой/).first()).toBeVisible()

    const total = page.getByText(/ЗП мастера по заказу/i).locator('..')
    const before = await total.innerText()
    await page.getByRole('checkbox', { name: /ОТК без замечаний/ }).click()
    await expect(total).not.toHaveText(before)
  })
})

test.describe('бухгалтерия', () => {
  test('«Выплатить ЗП» обнуляет баланс мастера и формирует акт ГПХ', async ({ page }) => {
    await setupAdmin(page)
    await page.getByRole('link', { name: /Бухгалтерия и ЗП/ }).first().click()
    await expect(page.getByRole('heading', { level: 1, name: /Бухгалтерия/ })).toBeVisible()

    const row = page.locator('tr', { hasText: 'Тимофей Аркадьевич' }).first()
    await row.getByRole('button', { name: 'Выплатить ЗП' }).click()
    await page.getByRole('dialog').getByRole('button', { name: /^Выплатить \d/ }).click()

    await expect(page.getByText('Акт выполненных работ').first()).toBeVisible()
    await page.getByRole('dialog').getByRole('button', { name: 'Закрыть', exact: true }).click()
    await expect(row.getByRole('button', { name: 'Выплачено' })).toBeDisabled()
  })
})

test.describe('навигация и адаптивность', () => {
  test('командная палитра открывается по Ctrl+K и ведёт в раздел', async ({ page }) => {
    await setupAdmin(page)
    await page.keyboard.press('Control+K')
    const dialog = page.getByRole('dialog', { name: 'Командная палитра' })
    await expect(dialog).toBeVisible()
    await dialog.getByRole('combobox').fill('Склад')
    await page.keyboard.press('Enter')
    await expect(page).toHaveURL(/\/inventory$/)
  })

  test('на планшете меню открывается кнопкой-бургером', async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== 'tablet', 'Боковое меню на десктопе всегда видно')
    await setupAdmin(page)
    await page.getByRole('button', { name: 'Открыть меню навигации' }).click()
    await page.getByRole('dialog').getByRole('link', { name: 'Заказы' }).click()
    await expect(page).toHaveURL(/\/orders$/)
  })

  test('несуществующий адрес показывает страницу 404', async ({ page }) => {
    await setupAdmin(page)
    await page.goto('/no-such-page')
    await expect(page.getByRole('heading', { name: 'Страница не найдена' })).toBeVisible()
  })
})
