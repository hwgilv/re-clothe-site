import type { Config } from 'tailwindcss'
import defaultTheme from 'tailwindcss/defaultTheme'

/**
 * Цвета — через CSS-переменные (см. src/app/globals.css), чтобы тёмная/светлая
 * темы переключались без пересборки. `<alpha-value>` позволяет писать bg-primary/15.
 */
const color = (name: string) => `hsl(var(--${name}) / <alpha-value>)`

const config: Config = {
  // Интерфейс один — тёмный «матовый графит»; переключателя тем нет.
  darkMode: 'class',
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    container: {
      center: true,
      padding: '1rem',
      screens: { '2xl': '1600px' },
    },
    extend: {
      colors: {
        background: color('background'),
        foreground: color('foreground'),
        surface: color('surface'),
        border: color('border'),
        input: color('input'),
        ring: color('ring'),
        muted: {
          DEFAULT: color('muted'),
          foreground: color('muted-foreground'),
        },
        primary: {
          DEFAULT: color('primary'),
          foreground: color('primary-foreground'),
          text: color('primary-text'),
        },
        success: {
          DEFAULT: color('success'),
          text: color('success-text'),
        },
        warning: {
          DEFAULT: color('warning'),
          text: color('warning-text'),
        },
        destructive: {
          DEFAULT: color('destructive'),
          text: color('destructive-text'),
        },
        // Джинсовый синий — элементы раскроя (этап «Раскрой», деним).
        denim: {
          DEFAULT: color('denim'),
          text: color('denim-text'),
        },
      },
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 3px)',
      },
      fontFamily: {
        sans: ['"Inter Variable"', 'Inter', ...defaultTheme.fontFamily.sans],
        // Заголовки и данные — JetBrains Mono: в отличие от Space Grotesk, содержит кириллицу.
        mono: ['"JetBrains Mono Variable"', '"JetBrains Mono"', ...defaultTheme.fontFamily.mono],
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem' }],
      },
      keyframes: {
        'fade-up': {
          from: { opacity: '0', transform: 'translateY(6px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        shake: {
          '0%, 100%': { transform: 'translateX(0)' },
          '20%, 60%': { transform: 'translateX(-6px)' },
          '40%, 80%': { transform: 'translateX(6px)' },
        },
        'glow-pulse': {
          '0%, 100%': { opacity: '0.55' },
          '50%': { opacity: '0.9' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.35s ease-out both',
        shake: 'shake 0.4s ease-in-out',
        'glow-pulse': 'glow-pulse 3.5s ease-in-out infinite',
      },
    },
  },
  // require, а не import: пакет отдаёт CommonJS, и так конфиг не зависит от наличия его типов.
  plugins: [require('tailwindcss-animate')],
}

export default config
